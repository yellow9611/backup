#include <stdio.h>
#include "uthread.h"

void *uthread1_routine(void *arg) {
    int i = 0;
    for (i = 0; i < 0x7FFF; ++i) {
        printf("uthread1\n");
    }
    return 0;
}

void *uthread2_routine(void *arg) {
    int i = 0;
    for (i = 0; i < 0x7FFF; ++i) {
        printf("uthread2\n");
    }
    return 0;
}

int main(int argc, char *argv[]) {
    uthread_t uthread1;
    uthread_t uthread2;

    uthread_create(&uthread1, 1024 * 1024, uthread1_routine, 0);
    uthread_create(&uthread2, 1024 * 1024, uthread2_routine, 0);

    uthread_join(uthread1, 0);
    uthread_join(uthread2, 0);

    return 0;
}

