#ifndef UTHREAD_H
#define UTHREAD_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct uthread_imp_t uthread_imp_t;

typedef uthread_imp_t *uthread_t;

int uthread_create(uthread_t *, size_t, void *(*)(void *), void *);
void uthread_exit(void *);
int uthread_join(uthread_t, void **);
uthread_t uthread_self(void);
void uthread_yield(void);
void uthread_enable_schedule_interruption(void);
void uthread_disable_schedule_interruption(void);

#ifdef __cplusplus
}
#endif

#endif

