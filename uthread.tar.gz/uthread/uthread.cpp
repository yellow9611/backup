#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include <list>
#include "uthread.h"

#define SCHEDULE_INTERRUPTION SIGPROF

typedef std::list<uthread_imp_t *> uthread_list_t;
typedef uthread_list_t::iterator uthread_iterator_t;

typedef void (*makecontext_func_arg_t)();

typedef enum uthread_status_t {
    ACTIVE,
    INACTIVE,
    DEAD
} uthread_status_t;

struct uthread_imp_t {
    uthread_status_t status;
    int err;
    uthread_imp_t *prev;
    uthread_imp_t *next;
    stack_t stack;
    ucontext_t context;
    uthread_list_t waiting;
    void *ret;
};

struct uthread_library_initializer_t {
    uthread_library_initializer_t(void);
    ~uthread_library_initializer_t(void);
};

static int number_of_running_interruption_handler(void);

static int uthread_join_immediately(uthread_t, void **);

static void start_schedule_timer(void);
static void stop_schedule_timer(void);

static void enable_schedule_interruption_handler(void);
static void disable_schedule_interruption_handler(void);
static void schedule_interruption_handler(int, siginfo_t *, void *);

static void update_global(uthread_imp_t *, uthread_imp_t *);
static void switch_uthread(uthread_imp_t *, uthread_imp_t *);

static void start_uthread(void *(*)(void *), void *);

static uthread_imp_t *get_current_active(void);
static void update_current_active(void);

static void add_active_uthread(uthread_imp_t *);
static void remove_active_uthread(uthread_imp_t *);

static void add_inactive_uthread(uthread_imp_t *);
static void remove_inactive_thread(uthread_imp_t *);

static void add_dead_uthread(uthread_imp_t *);
static void remove_dead_uthread(uthread_imp_t *);

static void *stack_pointer(ucontext_t *);
static int sp_belong_to_stack(void *, stack_t *);

static void destroy_uthread(uthread_imp_t *);
static void destroy_uthreads(uthread_imp_t *);

static void init_sentinel(uthread_imp_t *);

static char g_stack_buf[8192 + SIGSTKSZ];
/* When switching uthread, this stack is used. */
static stack_t g_switch_stack = {
    g_stack_buf,
    0,
    sizeof(g_stack_buf)
};

static uthread_imp_t *g_main_uthread;

static uthread_imp_t g_active_sentinel;
static uthread_imp_t g_inactive_sentinel;
static uthread_imp_t g_dead_sentinel;

static void add_uthread(uthread_imp_t *sentinel, uthread_imp_t *uthread) {
    uthread->prev = sentinel->prev;
    sentinel->prev->next = uthread;
    uthread->next = sentinel;
    sentinel->prev = uthread;
}

static void remove_uthread(uthread_imp_t *uthread) {
    uthread->prev->next = uthread->next;
    uthread->next->prev = uthread->prev;
}

static void add_active_uthread(uthread_imp_t *uthread) {
    add_uthread(&g_active_sentinel, uthread);
    uthread->status = ACTIVE;
}

static void remove_active_uthread(uthread_imp_t *uthread) {
    assert(uthread->status == ACTIVE);
    remove_uthread(uthread);
}

static void add_inactive_uthread(uthread_imp_t *uthread) {
    add_uthread(&g_inactive_sentinel, uthread);
    uthread->status = INACTIVE;
}

static void remove_inactive_uthread(uthread_imp_t *uthread) {
    assert(uthread->status == INACTIVE);
    remove_uthread(uthread);
}

static void add_dead_uthread(uthread_imp_t *uthread) {
    add_uthread(&g_dead_sentinel, uthread);
    uthread->status = DEAD;
}

static void remove_dead_uthread(uthread_imp_t *uthread) {
    assert(uthread->status == DEAD);
    remove_uthread(uthread);
}

int uthread_create(uthread_t *uthread,
        size_t stack_size, void *(*entry)(void *), void *arg) {
    uthread_imp_t *imp = new uthread_imp_t();
    if (stack_size < SIGSTKSZ) {
        stack_size = 8192 + SIGSTKSZ;
    }

    getcontext(&imp->context);
    imp->context.uc_link = 0;
    imp->context.uc_stack.ss_size = stack_size;
    imp->context.uc_stack.ss_sp = new char[stack_size];
    imp->stack = imp->context.uc_stack;
    makecontext(&imp->context,
            (makecontext_func_arg_t)(start_uthread), 2, entry, arg);

    disable_schedule_interruption_handler();
    do {
        add_active_uthread(imp);
    } while (0);
    enable_schedule_interruption_handler();

    *uthread = imp;
    return 0;
}

/* no return */
void uthread_exit(void *value) {
    ucontext_t context;
    uthread_imp_t *current;
    uthread_imp_t *next;

    disable_schedule_interruption_handler();

    current = get_current_active();
    current->ret = value;
    if (current == g_main_uthread) {
        exit((int)(value));
    }
    do { /* wake up uthread */
        uthread_iterator_t first = current->waiting.begin();
        uthread_iterator_t last = current->waiting.end();
        uthread_iterator_t iter;
        for (iter = first; iter != last; ++iter) {
            uthread_imp_t *uthread = *iter;
            remove_inactive_uthread(uthread);
            add_active_uthread(uthread);
        }
        current->waiting.clear();
    } while (0);
    remove_active_uthread(current);
    add_dead_uthread(current);
    update_current_active();
    next = get_current_active();

    getcontext(&context);
    context.uc_link = 0;
    context.uc_stack.ss_sp = g_switch_stack.ss_sp;
    context.uc_stack.ss_size = g_switch_stack.ss_size;
    makecontext(&context,
            (makecontext_func_arg_t)(switch_uthread), 2, current, next);
    setcontext(&context);
}

static int uthread_join_immediately(uthread_t uthread, void **value) {
    /* schedule interruption won't touch any dead uthread */
    assert(uthread->status == DEAD);
    if (value) {
        *value = uthread->ret;
    }
    remove_dead_uthread(uthread);
    destroy_uthread(uthread);
    return 0;
}

int uthread_join(uthread_t uthread, void **value) {
    ucontext_t context;
    uthread_imp_t *current;
    uthread_imp_t *next;

    /* schedule interruption won't change uthread's status. */
    if (uthread->status == DEAD) {
        return uthread_join_immediately(uthread, value);
    }

    disable_schedule_interruption_handler();

    current = get_current_active();
    if (current == uthread) { /* too bad, dead lock */
        enable_schedule_interruption_handler();
        return -1;
    }

    remove_active_uthread(current);
    add_inactive_uthread(current);
    uthread->waiting.push_back(current);
    update_current_active();
    next = get_current_active();

    getcontext(&context);
    context.uc_link = 0;
    context.uc_stack.ss_sp = g_switch_stack.ss_sp;
    context.uc_stack.ss_size = g_switch_stack.ss_size;
    makecontext(&context,
            (makecontext_func_arg_t)(switch_uthread), 2, current, next);
    swapcontext(&current->context, &context);

    /* When @a thread is dead, @a current is waken up and active.
     * Once @a current is running, it is arriving here.
     * So, uthread_join is ready to return.
     */
    return uthread_join_immediately(uthread, value);
}

uthread_t uthread_self(void) {
    uthread_imp_t *current;
    disable_schedule_interruption_handler();
    current = get_current_active();
    enable_schedule_interruption_handler();
    return current;
}

void uthread_yield(void) {
    ucontext_t context;
    uthread_imp_t *current;
    uthread_imp_t *next;

    disable_schedule_interruption_handler();

    current = get_current_active();
    remove_active_uthread(current);
    update_current_active();
    next = get_current_active();
    add_active_uthread(current);
    if (!next) {
        update_current_active();
        enable_schedule_interruption_handler();
        return;
    }

    getcontext(&context);
    context.uc_link = 0;
    context.uc_stack.ss_sp = g_switch_stack.ss_sp;
    context.uc_stack.ss_size = g_switch_stack.ss_size;
    makecontext(&context,
            (makecontext_func_arg_t)(switch_uthread), 2, current, next);

    swapcontext(&current->context, &context);
}

void uthread_enable_schedule_interruption(void) {
    start_schedule_timer();
}

void uthread_disable_schedule_interruption(void) {
    stop_schedule_timer();
}

static void start_schedule_timer(void) {
    int frequency = 100;
    struct itimerval timer;
    timer.it_interval.tv_sec = 0;
    timer.it_interval.tv_usec = 1000000 / frequency;
    timer.it_value = timer.it_interval;
    setitimer(ITIMER_PROF, &timer, 0);
}

static itimerval get_schedule_timer(void) {
    itimerval ret;
    getitimer(ITIMER_PROF, &ret);
    return ret;
}

static void stop_schedule_timer(void) {
    struct itimerval timer;
    timer.it_interval.tv_sec = 0;
    timer.it_interval.tv_usec = 0;
    timer.it_value = timer.it_interval;
    setitimer(ITIMER_PROF, &timer, 0);
}

#if 0
static volatile sig_atomic_t g_schedule_interruption_handler_status = 0; // enabled or disabled
#endif
static void enable_schedule_interruption_handler(void) {
    struct sigaction sa;
    sa.sa_sigaction = schedule_interruption_handler;
    sa.sa_flags = SA_RESTART | SA_SIGINFO;
    sigfillset(&sa.sa_mask);
    sigaction(SCHEDULE_INTERRUPTION, &sa, 0);
}

static void disable_schedule_interruption_handler(void) {
    struct sigaction sa;
    sa.sa_handler = SIG_IGN;
    sa.sa_flags = SA_RESTART;
    sigemptyset(&sa.sa_mask);
    sigaction(SCHEDULE_INTERRUPTION, &sa, 0);
}

static void update_global(uthread_imp_t *current, uthread_imp_t *next) {
    current->err = errno;
    errno = next->err;
}

/* It runs in g_switch_stack. */
static void switch_uthread(uthread_imp_t *current, uthread_imp_t *next) {
    assert(current != next);
    assert(current);

    if (!next) {
        /* FIXME:what to do next */
        abort();
    }

    update_global(current, next);

    /* Ideally, enable_schedule_interruption_handler and setcontext
     * shall be completed atomically. */
    enable_schedule_interruption_handler();

    /* Assume that any signal handler doesn't run in an alternative stack.
     * If schedule interruption kicks in, it will find that it happens in
     * g_switch_stack context.
     * */

    setcontext(&next->context);
}

static int number_of_running_interruption_handler(void) {
    /* FIXME: how to know the number */
    return 1;
}

static void schedule_interruption_handler(int sig, siginfo_t *info, void *ctx) {
    void *sp;
    uthread_imp_t *current;
    uthread_imp_t *next;
    ucontext_t *context = (ucontext_t *)(ctx);

    if (number_of_running_interruption_handler() > 1) {
        /* While handling other signals, schedule interruption happens */
        return;
    }

    sp = stack_pointer(context);
    if (sp_belong_to_stack(sp, &g_switch_stack)) {
        /* schedule interruption happens exactly during uthread switch. */
        return;
    }

    current = get_current_active();
    if (!current) {
        /* FIXME: what to do next? */
        abort();
    }

    remove_active_uthread(current);
    update_current_active();
    next = get_current_active();
    add_active_uthread(current);
    if (!next) {
        update_current_active();
        assert(get_current_active() == current);
        return;
    }

    current->context = *context;
    update_global(current, next);
    setcontext(&next->context);
}

static void start_uthread(void *(*entry)(void *), void *arg) {
    void *ret;
    ret = entry(arg);
    uthread_exit(ret);
}

void *stack_pointer(ucontext_t *context) {
    int sp;
#if __WORDSIZE == 32
    sp = REG_ESP;
#elif __WORDSIZE == 64
    sp = REG_RSP;
#else
    abort();
    return 0;
#endif
    return (void *)(context->uc_mcontext.gregs[sp]);
}

static int sp_belong_to_stack(void *sp, stack_t *stack) {
    /* FIXME: Is it right? */
    return sp >= stack->ss_sp && sp < (char *)(stack->ss_sp) + stack->ss_size;
}

static uthread_imp_t *get_current_active(void) {
    uthread_imp_t *current = g_active_sentinel.next;
    if (current != &g_active_sentinel) {
        return current;
    }
    return 0;
}

static void update_current_active(void) {
    /* do nothing. Active head is current */
}

static void destroy_uthread(uthread_imp_t *uthread) {
    delete [] (char *)(uthread->stack.ss_sp);
    delete uthread;
}

static void destroy_uthreads(uthread_imp_t *sentinel) {
    uthread_imp_t *curr = sentinel->next;
    while (curr != sentinel) {
        uthread_imp_t *next = curr->next;
        destroy_uthread(curr);
        curr = next;
    }
}

static void init_sentinel(uthread_imp_t *sentinel) {
    sentinel->prev = sentinel;
    sentinel->next = sentinel;
}

uthread_library_initializer_t::uthread_library_initializer_t(void) {
    init_sentinel(&g_active_sentinel);
    init_sentinel(&g_inactive_sentinel);
    init_sentinel(&g_dead_sentinel);

    g_main_uthread = new uthread_imp_t();
    getcontext(&g_main_uthread->context);
    g_main_uthread->stack.ss_sp = 0;
    g_main_uthread->stack.ss_size = 0;
    add_active_uthread(g_main_uthread);

    start_schedule_timer();
    enable_schedule_interruption_handler();
}

uthread_library_initializer_t::~uthread_library_initializer_t(void) {
    disable_schedule_interruption_handler();
    stop_schedule_timer();
    destroy_uthreads(&g_active_sentinel);
    destroy_uthreads(&g_inactive_sentinel);
    destroy_uthreads(&g_dead_sentinel);
}

static uthread_library_initializer_t g_initializer;

