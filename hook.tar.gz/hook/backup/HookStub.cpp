//#define _GUN_SOURCE
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <signal.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>
#include <limits.h>
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <algorithm>
#include <fstream>
#include "bfd.h"
#include "dis-asm.h"
#include "HookStub.h"
#include "HookLib.h"

/* Limitation
 * 0. multi-threading.
 * Much more complexity in multi-threading environment.
 * At least, HookManager::prolog/epilog/ora should be thread safe.
 * But what is the thread model?
 *
 * Each thread has an independent stack, so CFA (Canonical Frame Address)
 * can be still used in multi-threading environ, but we need to do more work
 * when target function returns in one thread, especially in case of tail call.
 * At least HookManager::m_context_list is not suitable.
 * Also, I guess terminated thread should not leave any invalid CFA in
 * internal data structure because newly created thread may "reuse" the stack
 * space. If there is any invalid CFA, any operation that may refer the
 * invalid CFA would be undefined.
 *
 * In summary:
 * Hook stub is not thread safe.
 * Target function shall not be executed simultaneously in multiple threads.
 */

/* Assumption:
 * 0. x86_64
 * 1. Linux
 * 2. GCC
 * 3. size_t can hold any address
 */

/* Key Issues:
 * 0. recursive call and tail call
 * In case of tail call, several function activation records may have same CFA.
 *
 * Context (cfa and original return address) is saved and new return address
 * is set to epilog thunk as long as prolog thunk is executed.
 * So, hook stub intrinsically supports recursive call and tail call.
 * But self-recursive tail call most likely jumps inside target function and
 * triggers only one prolog thunk execution.
 *
 * 1. fork notify
 *
 * 2. no return function, such as exit/abort.
 * execve is special. Yes, we can intercept it. But before calling the
 * underlying execve, we can't decide what to do. If underlying execve succeeds,
 * it doesn't return, the process image is refreshed. In this case, hookLibFini
 * should be invoked before replacing process image. If underlying execve fails,
 * it does return, the process image keeps unchanged. In this case, hookLibFini
 * shouldn't be invoked.
 * Fortunately, in most cases, execve is immediatelly called after fork.
 * It's meaningless to call hookLibFini before replacing process image.
 * So, we doesn't intercept execve.
 *
 * 3. exception handling
 *  Prolog thunk makes target funcion return to epilog thunk first.
 *  If one exception is escaping away from target function,
 *  Unwinding library will search exception handler in its pseudo caller,
 *  epilog thunk.
 *  We need to register an exception handling frame for epilog thunk.
 *  Otherwise, unwinding library can't find FDE (Frame Descriptor Element)
 *  for epilog thunk, regards it reaches end of stack, then terminates.
 *
 *  Effectively, in epilog thunk, there is one catch any exception handler
 *  that rethrows the exception after restoring the original return address
 *  of target function and running each epilog.
 *
 *  The side effect is that cleanup actions (from throwing exception to epilog
 *  thunk) have been done once epilog thunk catches the exception.
 */

extern "C" {
    // The declarations are inaccurate, but we just want to let compiler
    // know they are external functions.
    void __gxx_personality_v0();
    // void __cxa_begin_catch(void *);
    void __cxa_rethrow();
    void __cxa_end_catch();
    void _Unwind_Resume();
    void __register_frame(void *first_fde);
    void __deregister_frame(void *first_fde);
    // __register_frame and __deregister_frame shall be in .dynsym section of
    // exe. Otherwise, exception handling may not work, especially if exe is
    // linked against static libstdc++.
}

// auxiliary data structue declaration
namespace {
struct FunctionSymbol {
    char *function_address;
    size_t function_size;
};

struct ModuleDescriptor {
    dev_t dev;
    ino_t ino;
};
}

// WrapperManager declaration
namespace {
struct WrapperManager {
    typedef void *(*dlopen_fp_t)(const char *, int);
    typedef int (*dlclose_fp_t)(void *);
    typedef pid_t (*fork_fp_t)(void);
    typedef void (*exit_fp_t)(int);
    typedef void (*abort_fp_t)(void);
    typedef void (*(*signal_fp_t)(int, void (*)(int)))(int);
    typedef int (*sigaction_fp_t)(int sig,
            const struct sigaction *, struct sigaction *);
#if 0
    typedef int (*execve_fp_t)(const char *, char *const[], char *const[]);
    typedef int (*execv_fp_t)(const char *, char *const[]);
    typedef int (*execvp_fp_t)(const char *, char *const[]);
    typedef int (*execl_fp_t)(const char *, const char *, ...);
    typedef int (*execlp_fp_t)(const char *, const char *, ...);
#endif
    dlopen_fp_t dlopen;
    dlclose_fp_t dlclose;
    fork_fp_t fork;
    exit_fp_t exit;
    abort_fp_t abort;
    signal_fp_t signal;
    sigaction_fp_t sigaction;
#if 0
    execve_fp_t execve;
    execv_fp_t execv;
    execvp_fp_t execvp;
    execl_fp_t execl;
    execlp_fp_t execlp;
#endif

    size_t dlSymbol(const char *name);
    WrapperManager();
};
}

// HookLibManager declaration 
namespace {
struct HookLib {
    std::string name;
    void *handle;
    HookLibInitRoutine init;
    HookLibFiniRoutine fini;
    HookLibAtForkRoutine atfork;
    HookLibAtUnloadRoutine atunload;
};

typedef std::vector<HookLib> HookLibVector;
typedef HookLibVector::iterator HookLibIterator;

struct LibConfig {
    std::string lib;
    std::string config;
};

typedef std::vector<LibConfig> LibConfigVector;
typedef LibConfigVector::iterator LibConfigIterator;

struct ExeConfig {
    std::string exe;
    LibConfigVector lcv;
};

typedef std::vector<ExeConfig> ExeConfigVector;
typedef ExeConfigVector::iterator ExeConfigIterator;

struct HookLibManager {
private:
    HookStub m_hook_stub;
    HookLibVector m_hook_lib_vector;
    ExeConfigVector m_exe_config_vector;

private:
    void parseConfigFile();
    ExeConfigIterator findExeConfig();

public:
    HookLibManager();
    ~HookLibManager();

public:
    void hookLibInit();
    void hookLibFini();
    void hookLibAtFork();
    void hookLibAtUnload(const char *name);

public:
    void noReturn();
    void soResolvePendingTarget(void *handle);
    void soMarkPendingTarget(void *handle);
};
}

// HookLibInitFini declaration
namespace {
struct HookLibInitFini {
    HookLibInitFini();
    ~HookLibInitFini();
};
}

// exception handling data structure
namespace {
// Language Specific Data
#ifdef HOOK_STUB_64
struct LSD {
    char LPStart_encoding;
    char ttype_encoding;
    char advance; // uleb128
    char call_site_encoding;
    char call_site_table_size; // uleb128

    // call site table, in ascending order of call site
    char rethrow_cs_start[2]; // uleb128, __cxa_rethrow
    char rethrow_cs_len; // uleb128
    char rethrow_cs_lp[2]; // uleb128
    char rethrow_cs_action; // uleb128
    char resume_cs_start[2]; // uleb128, _Unwind_Resume
    char resume_cs_len; // uleb128
    char resume_cs_lp; // uleb128
    char resume_cs_action; // uleb128
    char target_cs_start[2]; // uleb128, target call
    char target_cs_len; // uleb128
    char target_cs_lp; // uleb128
    char target_cs_action; // uleb128

    // action record table
    char ar_filter; // sleb128
    char ar_disp; // sleb128

    // ttype table
    void *ttype; // align
    char dummy[]; // place holder, but no align requirement
};
#else
struct LSD {
    char LPStart_encoding;
    char ttype_encoding;
    char advance; // uleb128
    char call_site_encoding;
    char call_site_table_size; // uleb128

    // call site table, in ascending order of call site
    char rethrow_cs_start; // uleb128, __cxa_rethrow
    char rethrow_cs_len; // uleb128
    char rethrow_cs_lp; // uleb128
    char rethrow_cs_action; // uleb128
    char resume_cs_start; // uleb128, _Unwind_Resume
    char resume_cs_len; // uleb128
    char resume_cs_lp; // uleb128
    char resume_cs_action; // uleb128
    char target_cs_start; // uleb128, target call
    char target_cs_len; // uleb128
    char target_cs_lp; // uleb128
    char target_cs_action; // uleb128

    // action record table
    char ar_filter; // sleb128
    char ar_disp; // sleb128

    // ttype table
    void *ttype; // align
    char dummy[]; // place holder, but no align requirement
};
#endif

// Common Interface Element
#ifdef HOOK_STUB_64
struct CIE {
    int length;
    int CIE_id;
    char version;
    char augmentation[4];

    char code_align; // uleb128
    char data_align; // sleb128
    char retaddr_column;

    char advance;
    char personality_encoding;
    char personality[sizeof(size_t)]; // function address 
    char lsda_encoding;

    char dw_cfa_def_cfa;
    char cfa_reg; // uleb128
    char cfa_offset; //uleb128

    char dw_cfa_offset_rip;
    char rip_offset; // uleb128

    char dw_cfa_offset_rbp;
    char rbp_offset; // uleb128

    char dw_cfa_offset_rax;
    char rax_offset; // uleb128
    
    char dw_cfa_offset_rcx;
    char rcx_offset; // uleb128

    char dw_cfa_offset_rdx;
    char rdx_offset; // uleb128

    char dw_cfa_offset_rbx;
    char rbx_offset; // uleb128

    char dw_cfa_offset_rsi;
    char rsi_offset; // uleb128

    char dw_cfa_offset_rdi;
    char rdi_offset; // uleb128

    char dw_cfa_offset_r8;
    char r8_offset; // uleb128

    char dw_cfa_offset_r9;
    char r9_offset; // uleb128

    char dw_cfa_offset_r10;
    char r10_offset; // uleb128

    char dw_cfa_offset_r11;
    char r11_offset; // uleb128

    char dw_cfa_offset_r12;
    char r12_offset; // uleb128

    char dw_cfa_offset_r13;
    char r13_offset; // uleb128

    char dw_cfa_offset_r14;
    char r14_offset; // uleb128

    char dw_cfa_offset_r15;
    char r15_offset; // uleb128

    void *dummy[]; // place holder and align memory
};
#else
struct CIE {
    int length;
    int CIE_id;
    char version;
    char augmentation[4];

    char code_align; // uleb128
    char data_align; // sleb128
    char retaddr_column;

    char advance;
    char personality_encoding;
    char personality[sizeof(size_t)]; // function address
    char lsda_encoding;

    char dw_cfa_def_cfa;
    char cfa_reg; // uleb128
    char cfa_offset; //uleb128

    char dw_cfa_offset_eip;
    char eip_offset; // uleb128

    char dw_cfa_offset_ebp;
    char ebp_offset; // uleb128

    char dw_cfa_offset_eax;
    char eax_offset; // uleb128
    
    char dw_cfa_offset_ecx;
    char ecx_offset; // uleb128

    char dw_cfa_offset_edx;
    char edx_offset; // uleb128

    char dw_cfa_offset_ebx;
    char ebx_offset; // uleb128

    char dw_cfa_offset_esi;
    char esi_offset; // uleb128

    char dw_cfa_offset_edi;
    char edi_offset; // uleb128

    void *dummy[]; // place holder and align memory
};
#endif

// Frame Descriptor Element
struct FDE {
    int length;
    int CIE_delta;
    void *pc_begin;
    long function_size;
    char advance; // uleb128
    char lsda[sizeof(void *)]; // void *
    void *dummy[]; // place holder and align memory
};

// Exception Handling Frame
struct EHFrame {
    CIE cie;
    FDE fde;
    FDE last;
};
}

// HookManager declaration
namespace {
struct Hook {
    PrologRoutine prolog_routine;
    void *prolog_arg;
    EpilogRoutine epilog_routine;
    void *epilog_arg;
};

typedef std::list<Hook> HookList;
typedef HookList::iterator HookIterator;

struct PrologThunk {
    char *thunk_buf;
    size_t thunk_size;
};

struct EpilogThunk {
    char *thunk_buf;
    size_t thunk_size;
    EHFrame *eh_frame;
};

struct Target {
    size_t target_id;
    HookList hook_list;
    ModuleDescriptor module_descriptor;
    std::string target_name;
    std::string module_name;
    char *target_code;
    size_t target_vma;
    size_t target_size;
    PrologThunk *prolog_thunk;
    EpilogThunk *epilog_thunk;
    int pending;
};

// The index of target in target vector is its identifier.
typedef std::vector<Target> TargetVector;
typedef TargetVector::iterator TargetIterator;

// Identify one function activation record on the stack
struct Context {
    size_t *cfa; // Canonical Frame Address
    void *ra; // Return Address
    size_t ti; // Target Identifier
};

typedef std::list<Context> ContextList;
typedef ContextList::iterator ContextIterator;

struct HookManager {
private:
    TargetVector m_target_vector;
    ContextList m_context_list;
    size_t m_page_size;
    size_t m_rel_jmp_size; // size of relative jump instruction
    char m_exe_name[PATH_MAX + 1];
    ModuleDescriptor m_exe_descriptor;
    char *m_exe_address;
    void *m_exe_handle;
    struct link_map *m_exe_lm;
    char *m_prolog_free;
    char *m_epilog_free;
    size_t m_personality;
    size_t m_begin_catch;
    size_t m_end_catch;
    size_t m_rethrow;
    size_t m_unwind_resume;
    void (*m_register_frame)(void *);
    void (*m_deregister_frame)(void *);
    LSD m_lsd; // shared by each epilog thunk
    std::map<const void *, size_t> m_addr_id_map;
    disassembler_ftype m_disassembler;
    disassemble_info m_disassemble_info;
    static char m_asm_code[128];

private: // hard coding depends on HookManager::createEpilogThunk
#ifdef HOOK_STUB_64
    enum {
        RETHROW_CS_START = 144, // call site of __cxa_rethrow
        RETHROW_CS_LEN = 2,
        RETHROW_CS_LP = 146, // landing pad of _cxa_rethrow
        RESUME_CS_START = 179, // call site of _Unwind_Resume
        RESUME_CS_LEN = 2,
        TARGET_CS_START = 181, // call site of target function
        TARGET_CS_LEN = 4,
        TARGET_CS_LP = 1, // landing pad of target call
    };
#else
    enum {
        RETHROW_CS_START = 72, // call site of __cxa_rethrow
        RETHROW_CS_LEN = 2,
        RETHROW_CS_LP = 74, // landing pad of _cxa_rethrow
        RESUME_CS_START = 89, // call site of _Unwind_Resume
        RESUME_CS_LEN = 2,
        TARGET_CS_START = 91, // imaginary call site of target function
        TARGET_CS_LEN = 4,
        TARGET_CS_LP = 1, // landing pad of target call
    };
#endif

private:
    HookManager();

public:
    ~HookManager();

public:
    static HookManager *getInstance();

private:
    static int disassemblerPrintf(void *stream, const char *format, ...);

public:
    int exeRegisterHook(const char *target_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int soRegisterHook(const char *target_name, const char *module_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int exeRegisterHook_(size_t target_vma, size_t target_size,
            const char *target_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int soRegisterHook_(size_t target_vma, size_t target_size,
            const char *target_name, const char *module_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);
private:
    TargetIterator addPendingTarget(size_t target_vma, size_t target_size,
            const char *target_name, const char *module_name,
            const ModuleDescriptor &module_descriptor,
            const Hook &hook);

    int resolveTarget(TargetIterator iter,
            const FunctionSymbol &function_symbol, char *module_address);

private:
    TargetIterator findTarget(const char *target_name,
            const ModuleDescriptor &module_descriptor);

public:
    Target *findTarget(const void *entry);

private:
    int dynResolveFunction(void *handle,
            const char *function_name, const char *module_name,
            FunctionSymbol *function_symbol);

    struct link_map *soLinkMap(const ModuleDescriptor &module_descriptor);

public:
    int exeAddress(void **module_address);

    int soAddress(const char *module_name, void **module_address);

private:
    PrologThunk *createPrologThunk(size_t target_id, char *target_code,
            char *remaining_code, EpilogThunk *epilog_thunk,
            const char *target_name, const char *module_name);

    EpilogThunk *createEpilogThunk(size_t target_id,
            char *target_code, size_t target_size,
            const char *target_name, const char *module_name);

    void destroyPrologThunk(PrologThunk *prolog_thunk);

    void destroyEpilogThunk(EpilogThunk *epilog_thunk);

private:
    void buildAbsoluteJumpToRemainingCode(char *curr_pc, char *target_pc);

    void buildRelativeJump(char *curr_pc, char *target_pc);

private:
    char *findRemainingCode(char *target_code, size_t target_size,
            const char *target_name, const char *module_name);

    int hackTarget(char *target_code, char *remaining_code,
            const char *target_name, const char *module_name);

private:
    void initLSD(LSD *lsd);
    void initCIE(CIE *cie);
    void initFDE(FDE *fde, long CIE_delta,
            void *pc_begin, size_t function_size);
    void initEHFrame(EHFrame *eh_frame, void *pc_begin, size_t function_size);
    EHFrame *createEHFrame(void *pc_begin, size_t function_size);
    void destroyEHFrame(EHFrame *eh_frame);

public:
    void noReturn();
    void soResolvePendingTarget(void *handle);
    void soMarkPendingTarget(void *handle);

public:
    void *ora(size_t target_id, size_t *cfa);
    void prolog(size_t target_id, size_t *cfa, size_t *reg, void *target_ra);
    void epilog(size_t target_id, size_t *cfa, size_t *reg, int ret);
};
}

// utility function declaration
namespace {
void *oraGet(size_t target_id, size_t *cfa);
void prologChain(size_t target_id, size_t *cfa, size_t *reg, void *target_ra);
void epilogChain(size_t target_id, size_t *cfa, size_t *reg, int ret);
void hookStubLog(const char *format, ...);
WrapperManager *getWrapperManager();
HookLibManager *getHookLibManager();
void handleSigTrap(int sig, siginfo_t *info, void *data);
}

// global variables
// _init and _fini
namespace {
// The order of global variable is VERY important.
WrapperManager g_wrapper_manager;
HookLibManager g_hook_lib_manager;
HookLibInitFini g_hook_lib_init_fini;
}

// auxiliary data structue implementation
namespace {
int initModuleDescriptor(const char *name, ModuleDescriptor *descriptor,
        int quiet = 0) {
    struct stat buf;
    if (stat(name, &buf)) {
        if (!quiet) {
            hookStubLog("%s: %s: %s",
                "init module descriptor", name, strerror(errno));
        }
        return -1;
    }
    descriptor->dev = buf.st_dev;
    descriptor->ino = buf.st_ino;
    return 0;
}

inline bool operator<(const ModuleDescriptor &lhs,
        const ModuleDescriptor &rhs) {
    return (lhs.dev < rhs.dev) || (lhs.dev == rhs.dev && lhs.ino < rhs.ino);
}

inline bool operator==(const ModuleDescriptor &lhs,
        const ModuleDescriptor &rhs) {
    return lhs.dev == rhs.dev && lhs.ino == rhs.ino;
}

inline bool operator!=(const ModuleDescriptor &lhs,
        const ModuleDescriptor &rhs) {
    return lhs.dev != rhs.dev || lhs.ino != rhs.ino;
}
}

// WrapperManager implementation
namespace {
size_t WrapperManager::dlSymbol(const char *name) {
    return reinterpret_cast<size_t>(dlsym(RTLD_NEXT, name));
}

WrapperManager::WrapperManager() {
    this->dlopen = reinterpret_cast<dlopen_fp_t>(dlSymbol("dlopen"));
    this->dlclose = reinterpret_cast<dlclose_fp_t>(dlSymbol("dlclose"));
    this->fork = reinterpret_cast<fork_fp_t>(dlSymbol("fork"));
    this->exit = reinterpret_cast<exit_fp_t>(dlSymbol("exit"));
    this->abort = reinterpret_cast<abort_fp_t>(dlSymbol("abort"));
    this->signal = reinterpret_cast<signal_fp_t>(dlSymbol("signal"));
    this->sigaction = reinterpret_cast<sigaction_fp_t>(dlSymbol("sigaction"));
#if 0
    this->execve = reinterpret_cast<execve_fp_t>(dlSymbol("execve"));
    this->execv = reinterpret_cast<execv_fp_t>(dlSymbol("execv"));
    this->execvp = reinterpret_cast<execvp_fp_t>(dlSymbol("execvp"));
    this->execl = reinterpret_cast<execl_fp_t>(dlSymbol("execl"));
    this->execlp = reinterpret_cast<execlp_fp_t>(dlSymbol("execlp"));
#endif
}
}

// HookLibManager implementation
namespace {
void HookLibManager::parseConfigFile() {
    const char *config = getenv("HOOK_STUB_CONFIG_FILE");
    if (!config) {
        config = "./hookstub.cfg";
    }

    std::ifstream file(config);

    // ugly format!
    // exe
    // lib
    // config
    // /
    while (1) {
        ExeConfig ec;
        file >> ec.exe;
        if (ec.exe.empty()) {
            return;
        }
        while (1) {
            LibConfig lc;
            file >> lc.lib;
            if (lc.lib == "/") {
                break;
            }
            file >> lc.config;
            if (lc.lib.empty() || lc.config.empty()) {
                break;
            }
            ec.lcv.push_back(lc);
        }
        if (ec.lcv.empty()) {
            return;
        }
        m_exe_config_vector.push_back(ec);
    }
}

ExeConfigIterator HookLibManager::findExeConfig() {
    ExeConfigIterator first = m_exe_config_vector.begin();
    ExeConfigIterator last = m_exe_config_vector.end();

    char exe[128];
    sprintf(exe, "/proc/%u/exe", getpid());

    ModuleDescriptor md1;
    if (initModuleDescriptor(exe, &md1, 1)) {
        return last;
    }

    for (ExeConfigIterator iter = first; iter !=last; ++iter) {
        ModuleDescriptor md2;
        if (initModuleDescriptor(iter->exe.c_str(), &md2, 1)) {
            continue;
        }
        if (md1 == md2) {
            return iter;
        }
    }

    return last;
}

HookLibManager::HookLibManager() {
    m_hook_stub.exeRegisterHook = exeRegisterHook;
    m_hook_stub.soRegisterHook = soRegisterHook;
    m_hook_stub.exeRegisterHook_ = exeRegisterHook_;
    m_hook_stub.soRegisterHook_ = soRegisterHook_;
    m_hook_stub.exeAddress = exeAddress;
    m_hook_stub.soAddress = soAddress;
    parseConfigFile();
}

HookLibManager::~HookLibManager() { }

void HookLibManager::hookLibInit() {
    ExeConfigIterator iter = findExeConfig();

    if (m_exe_config_vector.end() == iter) {
        return;
    }

    // This process is what we are interested in.
    // Should report any error from now on.
    ExeConfig &ec = *iter;

    // initialize each hook library
    std::string cwd = "./";
    for (size_t i = 0; i < ec.lcv.size(); ++i) {
        LibConfig &lc = ec.lcv[i];
        std::string name;
        if ('/' == lc.lib[0]) {
            name = lc.lib;
        } else {
            name = cwd + lc.lib;
        }

        void *handle = getWrapperManager()->dlopen(name.c_str(), RTLD_NOW);
        if (!handle) {
            hookStubLog("%s: %s: %s", "load hook library",
                    name.c_str(), dlerror());
            continue;
        }
        
        size_t init = reinterpret_cast<size_t>(dlsym(handle,
                    "hookLibInit"));
        size_t fini = reinterpret_cast<size_t>(dlsym(handle,
                    "hookLibFini"));
        size_t atfork = reinterpret_cast<size_t>(dlsym(handle,
                    "hookLibAtFork"));
        size_t atunload = reinterpret_cast<size_t>(dlsym(handle,
                    "hookLibAtUnload"));

        if (!init || !fini) {
            hookStubLog("%s: %s: %s", "load hook library", name.c_str(),
                    "hook library shall implement hookLibInit and hookLibFini");
            getWrapperManager()->dlclose(handle);
            continue;
        }

        HookLib hook_lib;
        hook_lib.name = name;
        hook_lib.handle = handle;
        hook_lib.init = reinterpret_cast<HookLibInitRoutine>(init);
        hook_lib.fini = reinterpret_cast<HookLibFiniRoutine>(fini);
        hook_lib.atfork = reinterpret_cast<HookLibAtForkRoutine>(atfork);
        hook_lib.atunload = reinterpret_cast<HookLibAtUnloadRoutine>(atunload);

        if (hook_lib.init(&m_hook_stub, lc.config.c_str())) { // init failure
            getWrapperManager()->dlclose(handle);
            continue;
        }

        m_hook_lib_vector.push_back(hook_lib);
    }
}

void HookLibManager::hookLibFini() {
    for (size_t i = 0; i < m_hook_lib_vector.size(); ++i) {
        HookLib &hook_lib = m_hook_lib_vector[i];
        hook_lib.fini();
        getWrapperManager()->dlclose(hook_lib.handle);
    }
}

void HookLibManager::hookLibAtFork() {
    for (size_t i = 0; i < m_hook_lib_vector.size(); ++i) {
        HookLib &hook_lib = m_hook_lib_vector[i];
        if (hook_lib.atfork) {
            hook_lib.atfork();
        }
    }
}

void HookLibManager::hookLibAtUnload(const char *name) {
    for (size_t i = 0; i < m_hook_lib_vector.size(); ++i) {
        HookLib &hook_lib = m_hook_lib_vector[i];
        if (hook_lib.atunload) {
            hook_lib.atunload(name);
        }
    }
}

void HookLibManager::noReturn() {
    if (m_hook_lib_vector.empty()) {
        return;
    }

    // call HookManager::getInstance iff necessary.
    HookManager *hm = HookManager::getInstance();
    hm->noReturn();
}

void HookLibManager::soResolvePendingTarget(void *handle) {
    if (m_hook_lib_vector.empty()) {
        return;
    }

    HookManager *hm = HookManager::getInstance();
    hm->soResolvePendingTarget(handle);
}

void HookLibManager::soMarkPendingTarget(void *handle) {
    if (m_hook_lib_vector.empty()) {
        return;
    }

    // call HookManager::getInstance iff necessary.
    HookManager *hm = HookManager::getInstance();
    hm->soMarkPendingTarget(handle);
}
}

// HookLibInitFini implementation 
namespace {
HookLibInitFini::HookLibInitFini() {
    HookLibManager *hlm = getHookLibManager();
    hlm->hookLibInit();
}

HookLibInitFini::~HookLibInitFini() {
    HookLibManager *hlm = getHookLibManager();
    hlm->hookLibFini();
}
}

// HookManager implementation
namespace {
inline bool operator==(const Target &lhs, const Target &rhs) {
    return lhs.target_name == rhs.target_name
        && lhs.module_descriptor == rhs.module_descriptor;
}

char HookManager::m_asm_code[128] = { 0 };

HookManager::HookManager() {
    m_prolog_free = 0;
    m_epilog_free = 0;

    m_target_vector.reserve(1024);
    m_page_size = sysconf(_SC_PAGE_SIZE);
    m_rel_jmp_size = 5;

    char exe[128];
    sprintf(exe, "/proc/%u/exe", getpid());
    memset(m_exe_name, 0, sizeof(m_exe_name));
    readlink(exe, m_exe_name, sizeof(m_exe_name) - 1);

    initModuleDescriptor(m_exe_name, &m_exe_descriptor);

    m_exe_handle = getWrapperManager()->dlopen(0, RTLD_LAZY);
    dlinfo(m_exe_handle, RTLD_DI_LINKMAP, &m_exe_lm);
    m_exe_address = reinterpret_cast<char *>(m_exe_lm->l_addr);

    bfd_init();
    bfd *abfd = bfd_openr(m_exe_name, 0);
    bfd_check_format(abfd, bfd_object);
    m_disassembler = disassembler(abfd);
    init_disassemble_info(&m_disassemble_info, 0, disassemblerPrintf);
    m_disassemble_info.mach = bfd_get_mach(abfd);
    m_disassemble_info.arch = bfd_get_arch(abfd);
    disassemble_init_for_target(&m_disassemble_info);
    bfd_close(abfd);

    m_personality = reinterpret_cast<size_t>(__gxx_personality_v0);
    m_begin_catch = reinterpret_cast<size_t>(__cxa_begin_catch);
    m_rethrow = reinterpret_cast<size_t>(__cxa_rethrow);
    m_end_catch = reinterpret_cast<size_t>(__cxa_end_catch);
    m_unwind_resume = reinterpret_cast<size_t>(_Unwind_Resume);
    m_register_frame = __register_frame;
    m_deregister_frame = __deregister_frame;

    initLSD(&m_lsd);

    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_sigaction = handleSigTrap;
    action.sa_flags |= SA_SIGINFO;
    getWrapperManager()->sigaction(SIGTRAP, &action, 0);
}

HookManager::~HookManager() {
    // FIXME:
    // I guess free/unmap executable memory may cause undefined behavior.
}
}

namespace {
TargetIterator HookManager::findTarget(const char *target_name,
        const ModuleDescriptor &module_descriptor) {
    Target target;
    target.target_name = target_name;
    target.module_descriptor = module_descriptor;
    return std::find(m_target_vector.begin(), m_target_vector.end(), target);
}

Target *HookManager::findTarget(const void *entry) {
    typedef std::map<const void *, size_t>::iterator Iterator;
    Iterator iter = m_addr_id_map.find(entry);
    if (m_addr_id_map.end() == iter) {
        return 0;
    }
    return &m_target_vector[iter->second];
}

int HookManager::dynResolveFunction(void *handle, const char *function_name,
        const char *module_name, FunctionSymbol *function_symbol) {
#ifdef HOOK_STUB_64
    typedef Elf64_Sym Elf_Sym;
#define ELF_ST_TYPE ELF64_ST_TYPE
#else
    typedef Elf32_Sym Elf_Sym;
#define ELF_ST_TYPE ELF32_ST_TYPE
#endif
    void *p = dlsym(handle, function_name);
    if (!p) {
        hookStubLog("%s: %s: %s: %s", "resolve function",
                function_name, module_name, dlerror());
        return -1;
    }

    Dl_info dl_info;
    Elf_Sym *elf_sym = 0;
    dladdr1(p, &dl_info, reinterpret_cast<void **>(&elf_sym), RTLD_DL_SYMENT);

    if (SHN_UNDEF == elf_sym->st_shndx
            || ELF_ST_TYPE(elf_sym->st_info) != STT_FUNC) {
        hookStubLog("%s: %s: %s: %s", "resolve function",
                function_name, module_name, "No such function");
        return -1;
    }

    function_symbol->function_address
        = reinterpret_cast<char *>(dl_info.dli_saddr);
    function_symbol->function_size = elf_sym->st_size;
    return 0;
}

struct link_map *
HookManager::soLinkMap(const ModuleDescriptor &module_descriptor) {
    struct link_map *lm;
    for (lm = m_exe_lm->l_next; lm; lm = lm->l_next) {
        if (!lm->l_name) {
            continue;
        }

        if (!lm->l_name[0]) {
            continue;
        }

        ModuleDescriptor md;
        initModuleDescriptor(lm->l_name, &md);
        if (module_descriptor != md) {
            continue;
        }

        return lm;
    }

    // for loop ending means "shared library is not in process space"
    return 0;
}

int HookManager::soAddress(const char *module_name, void **module_address) {
    ModuleDescriptor module_descriptor;
    if (initModuleDescriptor(module_name, &module_descriptor)) {
        return -1;
    }
    struct link_map *module_lm = soLinkMap(module_descriptor);
    if (!module_lm) {
        return -1;
    }
    *module_address = reinterpret_cast<void *>(module_lm->l_addr);
    return 0;
}

int HookManager::exeAddress(void **module_address) {
    *module_address = m_exe_address;
    return 0;
}

int HookManager::disassemblerPrintf(void *stream, const char *format, ...) {
    size_t len = strlen(m_asm_code);
    va_list args;
    va_start(args, format);
    vsnprintf(m_asm_code + len, sizeof(m_asm_code) - len, format, args);
    va_end(args);
    return 0;
}

#ifdef HOOK_STUB_64
char *HookManager::findRemainingCode(char *target_code, size_t target_size,
        const char *target_name, const char *module_name) {
    m_asm_code[0] = '\0';
    bfd_vma buffer_vma = reinterpret_cast<bfd_vma>(target_code);
    char buffer[32]; // should be sufficient for first instruction
    m_disassemble_info.buffer = reinterpret_cast<bfd_byte *>(buffer);
    m_disassemble_info.buffer_length = sizeof(buffer);
    m_disassemble_info.buffer_vma = buffer_vma;
    memcpy(buffer, target_code, std::min(sizeof(buffer), target_size));
    int len = m_disassembler(buffer_vma, &m_disassemble_info);

    // push %rax/%rcx/%rdx/%rbx/%rsp/%rbp/%rsi/%rdi
    if (target_size >= 1
            && target_code[0] >= '\x50' && target_code[0] <= '\x57') {
        return target_code + 1;
    }

    // push %r8/%r9/%r10/%r11/%r12/%r13/%r14/%r15
    if (target_size >= 2 && '\x41' == target_code[0]
            && target_code[1] >= '\x50' && target_code[1] <= '\x57') {
        return target_code + 2;
    }

    // sub imm8, %rsp
    if (target_size >= 4
            && '\x48' == target_code[0]
            && '\x83' == target_code[1]
            && '\xec' == target_code[2]) {
        return target_code + 4;
    }

    // sub imm32, %rsp
    if (target_size >= 7
            && '\x48' == target_code[0]
            && '\x81' == target_code[1]
            && '\xec' == target_code[2]) {
        return target_code + 7;
    }

    // and imm8, %rsp
    if (target_size >= 4
            && '\x48' == target_code[0]
            && '\x83' == target_code[1]
            && '\xe4' == target_code[2]) {
        return target_code + 4;
    }

    // and imm32, %rsp
    if (target_size >= 7
            && '\x48' == target_code[0]
            && '\x81' == target_code[1]
            && '\xe4' == target_code[2]) {
        return target_code + 7;
    }

    // mov reg, imm8(%rsp)
    if (target_size >= 5
            && '\x48' == target_code[0]
            && '\x89' == target_code[1]
            && '\x24' == target_code[3]) {
        if ('\x44' == target_code[2] // rax
                || '\x4c' == target_code[2] // rcx
                || '\x54' == target_code[2] // rdx
                || '\x5c' == target_code[2] // rbx
                || '\x6c' == target_code[2] // rbp
                || '\x74' == target_code[2] // rsi
                || '\x7c' == target_code[2]) { // rdi
            return target_code + 5;
        }
    }

    if (target_size >= 5
            && '\x4c' == target_code[0]
            && '\x89' == target_code[1]
            && '\x24' == target_code[3]) {
        if ('\x44' == target_code[2] // r8
                || '\x4c' == target_code[2] // r9
                || '\x54' == target_code[2] // r10
                || '\x5c' == target_code[2] // r11
                || '\x64' == target_code[2] // r12
                || '\x6c' == target_code[2] // r13
                || '\x74' == target_code[2] // r14
                || '\x7c' == target_code[2]) { // r15
            return target_code + 5;
        }
    }

    // mov reg, imm32(%rsp)
    if (target_size >= 8
            && '\x48' == target_code[0]
            && '\x89' == target_code[1]
            && '\x24' == target_code[3]) {
        if ('\x84' == target_code[2] // rax
                || '\x8c' == target_code[2] // rcx
                || '\x94' == target_code[2] // rdx
                || '\x9c' == target_code[2] // rbx
                || '\xac' == target_code[2] // rbp
                || '\xb4' == target_code[2] // rsi
                || '\xbc' == target_code[2]) { // rdi
            return target_code + 8;
        }
    }
    if (target_size >= 8
            && '\x4c' == target_code[0]
            && '\x89' == target_code[1]
            && '\x24' == target_code[3]) {
        if ('\x84' == target_code[2] // r8
                || '\x8c' == target_code[2] // r9
                || '\x94' == target_code[2] // r10
                || '\x9c' == target_code[2] // r11
                || '\xa4' == target_code[2] // r12
                || '\xac' == target_code[2] // r13
                || '\xb4' == target_code[2] // r14
                || '\xbc' == target_code[2]) { // r15
            return target_code + 8;
        }
    }

    hookStubLog("%s: %s: %s: %s: %s", "analyze code",
        target_name, module_name, "Unknown code pattern", m_asm_code);

    // Do NOT hack it if instruction is referring %rip,
    // including jump-relative-ip, call-relative-ip.
    fprintf(stderr, "Code is referring %%rip? (y/n):");
    char answer[LINE_MAX];
    if (fgets(answer, sizeof(answer), stdin)) {
        if ('n' == answer[0] && '\n' == answer[1]) {
            return target_code + len;
        }
    }

    return 0;
}
#else
char *HookManager::findRemainingCode(char *target_code, size_t target_size,
        const char *target_name, const char *module_name) {
    m_asm_code[0] = '\0';
    bfd_vma buffer_vma = reinterpret_cast<bfd_vma>(target_code);
    char buffer[32]; // should be sufficient for first instruction
    m_disassemble_info.buffer = reinterpret_cast<bfd_byte *>(buffer);
    m_disassemble_info.buffer_length = sizeof(buffer);
    m_disassemble_info.buffer_vma = buffer_vma;
    memcpy(buffer, target_code, std::min(sizeof(buffer), target_size));
    int len = m_disassembler(buffer_vma, &m_disassemble_info);

    // push %eax/%ecx/%edx/%ebx/%esp/%ebp/%esi/%edi
    if (target_size >= 1
            && target_code[0] >= '\x50' && target_code[0] <= '\x57') {
        return target_code + 1;
    }

    // sub imm8, %esp
    if (target_size >= 3
            && '\x83' == target_code[0]
            && '\xec' == target_code[1]) {
        return target_code + 3;
    }

    // sub imm32, %esp
    if (target_size >= 6
            && '\x81' == target_code[0]
            && '\xec' == target_code[1]) {
        return target_code + 6;
    }

    // and imm8, %esp
    if (target_size >= 3
            && '\x83' == target_code[0]
            && '\xe4' == target_code[1]) {
        return target_code + 3;
    }

    // and imm32, %esp
    if (target_size >= 6
            && '\x81' == target_code[0]
            && '\xe4' == target_code[1]) {
        return target_code + 6;
    }
    
    hookStubLog("%s: %s: %s: %s: %s", "analyze code",
        target_name, module_name, "Unknown code pattern", m_asm_code);

    // Do NOT hack it if instruction is referring %eip,
    // including jump-relative-ip, call-relative-ip.
    fprintf(stderr, "Code is referring %%eip? (y/n):");
    char answer[LINE_MAX];
    if (fgets(answer, sizeof(answer), stdin)) {
        if ('n' == answer[0] && '\n' == answer[1]) {
            return target_code + len;
        }
    }

    return 0;
}
#endif

void HookManager::buildRelativeJump(char *curr_pc, char *target_pc) {
    int offset = target_pc - curr_pc - m_rel_jmp_size;
    *curr_pc = 0xe9;
    memcpy(curr_pc + 1, &offset, sizeof(offset));
}

void HookManager::buildAbsoluteJumpToRemainingCode(char *curr_pc,
        char *target_pc) {
    char tmplt[] = {
        // Use the stack aggresively.
        0x48, 0x89, 0x44, 0x24, 0xf8, // mov %rax, -0x08(%rsp) // save rax
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov target_pc, %rax
        0x48, 0x89, 0x44, 0x24, 0xf0, // mov %rax, -0x10(%rsp)
        0x48, 0x8b, 0x44, 0x24, 0xf8, // mov -0x08(%rsp), %rax // restore rax
        0xff, 0x64, 0x24, 0xf0 // jmp *-0x10(%rsp)
    };
    char arg[32]; // should be sufficient
    memcpy(arg, &target_pc, sizeof(target_pc));
    char *a = arg;
    char *t = tmplt;
    char *c = curr_pc;
    while (t < tmplt + sizeof(tmplt)) {
        if (*t) {
            *c = *t;
        } else {
            *c = *a;
            ++a;
        }
        ++t;
        ++c;
    }
}
}

namespace {
#ifdef HOOK_STUB_64
void HookManager::initLSD(LSD *lsd) {
    memset(lsd, 0, sizeof(LSD));

    lsd->LPStart_encoding = 0xff;
    lsd->ttype_encoding = 0; // absolute address 
    lsd->advance = reinterpret_cast<char *>(&lsd->dummy)
        - reinterpret_cast<char *>(&lsd->call_site_encoding);

    lsd->call_site_encoding = 1; // uleb128 encoding method
    lsd->call_site_table_size = reinterpret_cast<char *>(&lsd->ar_filter)
        - reinterpret_cast<char *>(&lsd->rethrow_cs_start);

    // uleb128(RETHROW_CS_START)
    lsd->rethrow_cs_start[0] = 0x90;
    lsd->rethrow_cs_start[1] = 0x01;
    lsd->rethrow_cs_len = RETHROW_CS_LEN;
    // uleb128(RETHROW_CS_LP)
    lsd->rethrow_cs_lp[0] = 0x92;
    lsd->rethrow_cs_lp[1] = 0x01;
    lsd->rethrow_cs_action = 0; // cleanup

    // uleb128(RERUME_CS_START)
    lsd->resume_cs_start[0] = 0xB3;
    lsd->resume_cs_start[1] = 0x01;
    lsd->resume_cs_len = RESUME_CS_LEN;
    lsd->resume_cs_lp = 0; // no landing pad
    lsd->resume_cs_action = 0;

    // uleb128(TARGET_CS_START)
    lsd->target_cs_start[0] = 0xB5;
    lsd->target_cs_start[1] = 0x01;
    lsd->target_cs_len = TARGET_CS_LEN;
    lsd->target_cs_lp = TARGET_CS_LP;
    lsd->target_cs_action = 1; // exception handler

    lsd->ar_filter = 1;
    lsd->ar_disp = 0;

    lsd->ttype = 0; // catch any exception
}
#else
void HookManager::initLSD(LSD *lsd) {
    memset(lsd, 0, sizeof(LSD));

    lsd->LPStart_encoding = 0xff;
    lsd->ttype_encoding = 0; // absolute address 
    lsd->advance = reinterpret_cast<char *>(&lsd->dummy)
        - reinterpret_cast<char *>(&lsd->call_site_encoding);

    lsd->call_site_encoding = 1; // uleb128 encoding method
    lsd->call_site_table_size = reinterpret_cast<char *>(&lsd->ar_filter)
        - reinterpret_cast<char *>(&lsd->rethrow_cs_start);

    lsd->rethrow_cs_start = RETHROW_CS_START;
    lsd->rethrow_cs_len = RETHROW_CS_LEN;
    lsd->rethrow_cs_lp = RETHROW_CS_LP;
    lsd->rethrow_cs_action = 0; // cleanup

    lsd->resume_cs_start = RESUME_CS_START;
    lsd->resume_cs_len = RESUME_CS_LEN;
    lsd->resume_cs_lp = 0; // no landing pad
    lsd->resume_cs_action = 0;

    lsd->target_cs_start = TARGET_CS_START;
    lsd->target_cs_len = TARGET_CS_LEN;
    lsd->target_cs_lp = TARGET_CS_LP;
    lsd->target_cs_action = 1; // exception handler

    lsd->ar_filter = 1;
    lsd->ar_disp = 0;

    lsd->ttype = 0; // catch any exception
}
#endif

#ifdef HOOK_STUB_64
void HookManager::initCIE(CIE *cie) {
    memset(cie, 0, sizeof(CIE));

    cie->length = reinterpret_cast<char *>(&cie->dummy)
        - reinterpret_cast<char *>(&cie->CIE_id);
    cie->CIE_id = 0;
    cie->version = 1;
    strcpy(cie->augmentation, "zPL");

    cie->code_align = 1;
    cie->data_align = 0x78; // sleb128(-8)
    cie->retaddr_column = 16;
    cie->advance = reinterpret_cast<char *>(&cie->dw_cfa_def_cfa)
        - reinterpret_cast<char *>(&cie->personality_encoding);

    cie->personality_encoding = 0; // absolute address
    memcpy(cie->personality, &m_personality, sizeof(size_t));
    cie->lsda_encoding = 0; //absolute address

    cie->dw_cfa_def_cfa = 0xc; // DW_CFA_def_cfa instruction
    cie->cfa_reg = 6;
    cie->cfa_offset = 16;

    cie->dw_cfa_offset_rip = 0x90; // DW_CFA_offset(rip) instruction
    cie->rip_offset = 1;

    cie->dw_cfa_offset_rbp = 0x86; // DW_CFA_offset(rbp) instruction
    cie->rbp_offset = 2;

    cie->dw_cfa_offset_rax = 0x80;
    cie->rax_offset = 3;

    cie->dw_cfa_offset_rcx = 0x82; // FIXME: Is it right?
    cie->rcx_offset = 4;

    cie->dw_cfa_offset_rdx = 0x81;
    cie->rdx_offset = 5;

    cie->dw_cfa_offset_rbx = 0x83;
    cie->rbx_offset = 6;

    cie->dw_cfa_offset_rsi = 0x84; // FIXME: Is it right?
    cie->rsi_offset = 7;

    cie->dw_cfa_offset_rdi = 0x85; // FIXME: Is it right?
    cie->rdi_offset = 8;

    cie->dw_cfa_offset_r8 = 0x88;
    cie->r8_offset = 9;

    cie->dw_cfa_offset_r9 = 0x89;
    cie->r9_offset = 10;

    cie->dw_cfa_offset_r10 = 0x8a;
    cie->r10_offset = 11;

    cie->dw_cfa_offset_r11 = 0x8b;
    cie->r11_offset = 12;

    cie->dw_cfa_offset_r12 = 0x8c;
    cie->r12_offset = 13;

    cie->dw_cfa_offset_r13 = 0x8d;
    cie->r13_offset = 14;

    cie->dw_cfa_offset_r14 = 0x8e;
    cie->r14_offset = 15;

    cie->dw_cfa_offset_r15 = 0x8f;
    cie->r15_offset = 16;
}
#else
void HookManager::initCIE(CIE *cie) {
    memset(cie, 0, sizeof(CIE));

    cie->length = reinterpret_cast<char *>(&cie->dummy)
        - reinterpret_cast<char *>(&cie->CIE_id);
    cie->CIE_id = 0;
    cie->version = 1;
    strcpy(cie->augmentation, "zPL");

    cie->code_align = 1;
    cie->data_align = 0x7c; // sleb128(-4)
    cie->retaddr_column = 8;
    cie->advance = reinterpret_cast<char *>(&cie->dw_cfa_def_cfa)
        - reinterpret_cast<char *>(&cie->personality_encoding);

    cie->personality_encoding = 0; // absolute address
    memcpy(cie->personality, &m_personality, sizeof(size_t));
    cie->lsda_encoding = 0; //absolute address

    cie->dw_cfa_def_cfa = 0xc; // DW_CFA_def_cfa instruction
    cie->cfa_reg = 5;
    cie->cfa_offset = 8;

    cie->dw_cfa_offset_eip = 0x88; // DW_CFA_offset(eip) instruction
    cie->eip_offset = 1;

    cie->dw_cfa_offset_ebp = 0x85; // DW_CFA_offset(ebp) instruction
    cie->ebp_offset = 2;

    cie->dw_cfa_offset_eax = 0x80;
    cie->eax_offset = 3;

    cie->dw_cfa_offset_ecx = 0x81;
    cie->ecx_offset = 4;

    cie->dw_cfa_offset_edx = 0x82;
    cie->edx_offset = 5;

    cie->dw_cfa_offset_ebx = 0x83;
    cie->ebx_offset = 6;

    cie->dw_cfa_offset_esi = 0x86;
    cie->esi_offset = 7;

    cie->dw_cfa_offset_edi = 0x87;
    cie->edi_offset = 8;
}
#endif

void HookManager::initFDE(FDE *fde, long CIE_delta,
        void *pc_begin, size_t function_size) {
    memset(fde, 0, sizeof(FDE));
    fde->length = reinterpret_cast<char *>(&fde->dummy)
            - reinterpret_cast<char *>(&fde->CIE_delta);
    fde->CIE_delta = CIE_delta;
    fde->pc_begin = pc_begin;
    fde->function_size = function_size;
    fde->advance = reinterpret_cast<char *>(&fde->dummy)
            - reinterpret_cast<char *>(&fde->lsda);
    void *lsda = &m_lsd;
    memcpy(&fde->lsda, &lsda, sizeof(void *));
}

void HookManager::initEHFrame(EHFrame *eh_frame,
        void *pc_begin, size_t function_size) {
    initCIE(&eh_frame->cie);
    long CIE_delta = reinterpret_cast<char *>(&eh_frame->fde.CIE_delta)
        - reinterpret_cast<char *>(eh_frame);
    initFDE(&eh_frame->fde, CIE_delta, pc_begin, function_size);
    memset(&eh_frame->last, 0, sizeof(eh_frame->last));
}

EHFrame *HookManager::createEHFrame(void *pc_begin, size_t function_size) {
    EHFrame *eh_frame = new EHFrame();
    initEHFrame(eh_frame, pc_begin, function_size);
    m_register_frame(&eh_frame->fde);
    return eh_frame;
}

void HookManager::destroyEHFrame(EHFrame *eh_frame) {
    m_deregister_frame(&eh_frame->fde);
    delete eh_frame;
}
}

namespace {
void HookManager::prolog(size_t target_id, size_t *cfa, size_t *reg,
        void *target_ra) {
    Context context;
    context.cfa = cfa;
    context.ra = target_ra;
    context.ti = target_id;
    m_context_list.push_back(context);

    Target &target = m_target_vector[target_id];
    HookIterator first = target.hook_list.begin();
    HookIterator last = target.hook_list.end();
    for (HookIterator iter = first; iter != last; ++iter) {
        if (iter->prolog_routine) {
            try {
                iter->prolog_routine(target.target_name.c_str(),
                        target.module_name.c_str(),
                        cfa, reg, iter->prolog_arg);
            } catch (...) {
                hookStubLog("%s: %s", "run prolog", "caught exception");
            }
        }
    }
}

void HookManager::epilog(size_t target_id, size_t *cfa, size_t *reg, int ret) {
    assert(!m_context_list.empty());

    Context &context = m_context_list.back();

    assert(cfa == context.cfa);

    // In case of tail call, if one exception is escaping away from
    // callee, we can deduce that there is no any landing pad in caller.
    // Otherwise, the compiler shall not generate tail call.
    Target &target = m_target_vector[context.ti];
    HookIterator first = target.hook_list.begin();
    HookIterator last = target.hook_list.end();
    for (HookIterator iter = first; iter != last; ++iter) {
        if (iter->epilog_routine) {
            try {
                iter->epilog_routine(target.target_name.c_str(),
                        target.module_name.c_str(),
                        cfa, reg, ret, iter->epilog_arg);
            } catch (...) {
                hookStubLog("%s: %s", "run epilog", "caught exception");
            }
        }
    }

    m_context_list.pop_back();
}

void *HookManager::ora(size_t target_id, size_t *cfa) {
    // In single thread mode, the last context is what we need.
    assert(!m_context_list.empty());
    Context &context = m_context_list.back();
    assert(cfa == context.cfa);
    assert(target_id == context.ti);
    return context.ra;
}
}

namespace {
int HookManager::hackTarget(char *target_code, char *remaining_code,
        const char *target_name, const char *module_name) {
    size_t hack_size = remaining_code - target_code;
    if (hack_size > m_page_size) {
        hookStubLog("%s: %s: %s: %s", "hack code",
                target_name, module_name, "Too many codes to hack");
        return -1;
    }

    size_t hack_pages = 1;
    char *target_page = target_code
        - reinterpret_cast<size_t>(target_code) % m_page_size;
    if (target_page + m_page_size < remaining_code) {
        // hacked codes cross two pages
        hack_pages = 2;
    }

    if (mprotect(target_page, m_page_size * hack_pages,
                PROT_WRITE | PROT_EXEC)) {
        hookStubLog("%s: %s: %s: %s", "hack code",
                target_name, module_name, strerror(errno));
        return -1;
    }

    // inject "int 3".
    // Instruction boundary of remaining code is kept,
    memset(target_code, 0xcc, hack_size);

    // Adjacent pages relative to target code may be PLT,
    // which have write/execute permission.
    // Hacked page cannot overlap with PLT page because we need to
    // set hacked page access permission as read/execute.
    mprotect(target_page, m_page_size * hack_pages, PROT_READ | PROT_EXEC);

    return 0;
}

/*!
 * \brief Create prolog thunk for target function
 * \param target_id Identifier of target function
 * \param target_code target function address
 * \param remaining_code Remaining target code
 * \param epilog_thunk Epilog thunk address
 * \param target_name Target name
 * \param module_name Module name
 * \return Upon successful completion, It shall return the address of
 * prolog thunk. Otherwise, It shall return 0.
 * \note Prologue thunk is responsible for setting epilog thunk as the
 * temporary return address of target function and saving original unhacked
 * target code.
 */
#ifdef HOOK_STUB_64
PrologThunk *HookManager::createPrologThunk(size_t target_id,
        char *target_code, char *remaining_code, EpilogThunk *epilog_thunk,
        const char *target_name, const char *module_name) {
    // assume target code is readable
    std::string copied_code(target_code, remaining_code);

    size_t return_address = reinterpret_cast<size_t>(epilog_thunk->thunk_buf
            + TARGET_CS_START + TARGET_CS_LEN);

    char arg_buf[64]; // should be sufficient
    char *arg = arg_buf;
    memcpy(arg, &return_address, sizeof(return_address));
    arg += sizeof(return_address);

    // arguments: return_address
    char template_buf[] =  {
        0x50, // push %rax
        // modify the return address of target function
        // so that epilogue thunk can be executed after
        // target function returns.
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov return_address, %rax
        0x48, 0x89, 0x44, 0x24, 0x08, // mov %rax, 0x08(%rsp)
        0x58 // pop %rax
    };

    size_t max_thunk_size = 128;

    // 64 should be sufficient for build-absolute-jump-to-remaining-code.
    size_t thunk_size = sizeof(template_buf) + copied_code.size() + 64;
    if (thunk_size > max_thunk_size) {
        hookStubLog("%s: %s: %s: %s", "create prolog thunk",
                target_name, module_name, "Too big thunk");
        return 0;
    }
    thunk_size = max_thunk_size;

    if (!m_prolog_free) {
        int num = 1024;
        void *p = mmap(0, num * max_thunk_size,
                PROT_READ | PROT_WRITE | PROT_EXEC,
                MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (MAP_FAILED == p) {
            hookStubLog("%s: %s: %s: %s", "create prolog thunk",
                    target_name, module_name, strerror(errno));
            return 0;
        }
        m_prolog_free = reinterpret_cast<char *>(p);
        char *q = m_prolog_free;
        for (int i = 0; i < num - 1; ++i) {
            char *next = q + max_thunk_size;
            *reinterpret_cast<char **>(q) = next;
            q = next;
        }
        *reinterpret_cast<char **>(q) = 0;
    }

    char *thunk_buf = m_prolog_free;
    m_prolog_free = *reinterpret_cast<char **>(m_prolog_free);

    char *thunk = thunk_buf;
    char *tmplt = template_buf;
    arg = arg_buf;
    while (tmplt < template_buf + sizeof(template_buf)) {
        if (*tmplt) {
            *thunk = *tmplt;
        } else {
            *thunk = *arg;
            ++arg;
        }
        ++thunk;
        ++tmplt;
    }

    memcpy(thunk, copied_code.c_str(), copied_code.size());
    thunk += copied_code.size();

    // build the instruction "jmp remaining_code"
    buildAbsoluteJumpToRemainingCode(thunk, remaining_code);

    PrologThunk *prolog_thunk = new PrologThunk();
    prolog_thunk->thunk_buf = thunk_buf;
    prolog_thunk->thunk_size = thunk_size;
    return prolog_thunk;
}
#else
PrologThunk *HookManager::createPrologThunk(size_t target_id,
        char *target_code, char *remaining_code, EpilogThunk *epilog_thunk,
        const char *target_name, const char *module_name) {
    // Assume target code is readable.
    std::string copied_code(target_code, remaining_code);

    size_t return_address = reinterpret_cast<size_t>(epilog_thunk->thunk_buf
            + TARGET_CS_START + TARGET_CS_LEN);

    char arg_buf[64]; // should be sufficient
    char *arg = arg_buf;
    memcpy(arg, &return_address, sizeof(return_address));
    arg += sizeof(return_address);

    // arguments: return_address
    char template_buf[] =  {
        // modify the return address of target function
        // so that epilogue thunk can be executed after
        // target function returns.
        0xc7, 0x04, 0x24, 0x00, 0x00, 0x00, 0x00 // movl return_address, (%esp)

    };

    size_t max_thunk_size = 64;

    size_t thunk_size = sizeof(template_buf)
        + copied_code.size() + m_rel_jmp_size;
    if (thunk_size > max_thunk_size) {
        hookStubLog("%s: %s: %s: %s", "create prolog thunk",
                target_name, module_name, "Too big thunk");
        return 0;
    }
    thunk_size = max_thunk_size;

    if (!m_prolog_free) {
        int num = 1024;
        void *p = mmap(0, num * max_thunk_size,
                PROT_READ | PROT_WRITE | PROT_EXEC,
                MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (MAP_FAILED == p) {
            hookStubLog("%s: %s: %s: %s", "create prolog thunk",
                    target_name, module_name, strerror(errno));
            return 0;
        }
        m_prolog_free = reinterpret_cast<char *>(p);
        char *q = m_prolog_free;
        for (int i = 0; i < num - 1; ++i) {
            char *next = q + max_thunk_size;
            *reinterpret_cast<char **>(q) = next;
            q = next;
        }
        *reinterpret_cast<char **>(q) = 0;
    }

    char *thunk_buf = m_prolog_free;
    m_prolog_free = *reinterpret_cast<char **>(m_prolog_free);

    char *thunk = thunk_buf;
    char *tmplt = template_buf;
    arg = arg_buf;
    while (tmplt < template_buf + sizeof(template_buf)) {
        if (*tmplt) {
            *thunk = *tmplt;
        } else {
            *thunk = *arg;
            ++arg;
        }
        ++thunk;
        ++tmplt;
    }

    memcpy(thunk, copied_code.c_str(), copied_code.size());
    thunk += copied_code.size();

    // build the instruction "jmp remaining_code"
    buildRelativeJump(thunk, remaining_code);

    PrologThunk *prolog_thunk = new PrologThunk();
    prolog_thunk->thunk_buf = thunk_buf;
    prolog_thunk->thunk_size = thunk_size;
    return prolog_thunk;
}
#endif

/*!
 * \brief Create epilog thunk for target function
 * \param target_id Identifier of target function
 * \param target_code Target function address
 * \param target_size Target function size
 * \param target_name Target name
 * \param module_name Module name
 * \return Upon successful completion, It shall return the address of
 * epilog thunk. Otherwise, It shall return 0.
 * \note Epilog thunk is responsible for calling epilog chain, restoring the
 * orignal return address of target function, and transfer the control to
 * the REAL caller of target function or epilog thunk again.
 */
#ifdef HOOK_STUB_64
EpilogThunk *HookManager::createEpilogThunk(size_t target_id,
        char *target_code, size_t target_size,
        const char *target_name, const char *module_name) {
    // arguments:
    // __cxa_begin_catch
    // target_id, ora_get, epilog_chain,
    // __cxa_rethrow
    // __cxa_end_catch
    // _Unwind_Resume
    // target_id, ora_get, epilog_chain,
    char template_buf[] = {
        0x90, // "nop" makes LSD::target_cs_lp non-zero.
        // landing pad of target call site (LSD::target_cs_lp)
        // TARGET_CS_LP = 1

        // allocate space for original return address
        0x48, 0x83, 0xec, 0x08, // sub $0x08, %rsp

        0x55, // push %rbp
        0x48, 0x89, 0xe5, // mov %rsp, %rbp

        0x50, // push %rax
        0x51, // push %rcx
        0x52, // push %rdx
        0x53, // push %rbx
        0x56, // push %rsi
        0x57, // push %rdi
        0x41, 0x50, // push %r8
        0x41, 0x51, // push %r9
        0x41, 0x52, // push %r10
        0x41, 0x53, // push %r11
        0x41, 0x54, // push %r12
        0x41, 0x55, // push %r13
        0x41, 0x56, // push %r14
        0x41, 0x57, // push %r15

        // allocate space for local usage (Probably, we can use callee-saved registers)
        0x48, 0x83, 0xec, 0x18, // sub $0x18, %rsp

        // catch exception
        0x48, 0x89, 0xc7, // mov %rax, %rdi // _Unwind_Exception
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov __cxa_begin_catch, %rax
        0xff, 0xd0, // call *%rax // call __cxa_begin_catch 

        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov target_id, %rax
        0x48, 0x89, 0x04, 0x24, // mov %rax, (%rsp)
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov ora_get, %rax
        0x48, 0x89, 0x44, 0x24, 0x08, // mov %rax, 0x08(%rsp)
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov epilog_chain, %rax
        0x48, 0x89, 0x44, 0x24, 0x10, // mov %rax, 0x10(%rsp)

        // restore original return address
        0x48, 0x8d, 0x75, 0x10, // lea 0x10(%rbp), %rsi // canonical frame address
        0x48, 0x8b, 0x3c, 0x24, // mov (%rsp), %rdi // target_id
        0x48, 0x8b, 0x44, 0x24, 0x08, // mov 0x08(%rsp), %rax // ora_get
        0xff, 0xd0, // call *%rax // call ora_get.
        0x48, 0x89, 0x45, 0x08, // mov %rax, 0x08(%rbp)

        // run epilog
        0x48, 0x31, 0xc9, // xor %rcx, %rcx // abnormal return flag
        0x48, 0x89, 0xea, // mov %rbp, %rdx // registers buffer
        0x48, 0x8d, 0x75, 0x10, // lea 0x10(%rbp), %rsi // canonical frame address
        0x48, 0x8b, 0x3c, 0x24, // mov (%rsp), %rdi // target_id
        0x48, 0x8b, 0x44, 0x24, 0x10, // mov 0x10(%rsp), %rax // epilog_chain 
        0xff, 0xd0, // call *%rax // call epilog_chain.

        // rethrow exception.
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov __cxa_rethrow, %rax
        // rethrow call site (LSD::rethrow_cs_start, LSD::rethrow_cs_len)
        // RETHROW_CS_START = 144, RETHROW_CS_LEN = 2
        0xff, 0xd0, // call *%rax // call __cxa_rethrow 

        // landing pad of rethrow call site (LSD::rethrow_cs_lp)
        // RETHROW_CS_LP = 146
        0x48, 0x89, 0x04, 0x24, // mov %rax, (%rsp) // save _Unwind_Exception
        0x48, 0x89, 0xc7, // mov %rax, %rdi // _Unwind_Exception
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov __cxa_end_catch, %rax
        0xff, 0xd0, // call *%rax // call __cxa_end_catch

        0x48, 0x8b, 0x3c, 0x24, // mov (%rsp), %rdi // _Unwind_Exception 
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov _Unwind_Resume, %rax
        // _Unwind_Resume call site (LSD::resume_cs_start, LSD::resume_cs_len).
        // No landing pad.
        // RESUME_CS_START = 179, RESUME_CS_LEN = 2
        0xff, 0xd0, // call *%rax // call _Unwind_Resume, no return

        // imaginary target call site (LSD::target_cs_start/target_cs_len)
        // TARGET_CS_START = 181
        // TARGET_CS_LEN = 4
        0x90, 0x90, 0x90, 0x90,

        // Without exception, we should start here.
        //
        // allocate space for original return address
        0x48, 0x83, 0xec, 0x08, // sub $0x08, %rsp

        0x55, // push %rbp
        0x48, 0x89, 0xe5, // mov %rsp, %rbp

        0x50, // push %rax
        0x51, // push %rcx
        0x52, // push %rdx
        0x53, // push %rbx
        0x56, // push %rsi
        0x57, // push %rdi
        0x41, 0x50, // push %r8
        0x41, 0x51, // push %r9
        0x41, 0x52, // push %r10
        0x41, 0x53, // push %r11
        0x41, 0x54, // push %r12
        0x41, 0x55, // push %r13
        0x41, 0x56, // push %r14
        0x41, 0x57, // push %r15

        // allocate space for local usage (Probably, we can use callee-saved registers)
        0x48, 0x83, 0xec, 0x18, // sub $0x18, %rsp
    
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov target_id, %rax
        0x48, 0x89, 0x04, 0x24, // mov %rax, (%rsp)
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov ora_get, %rax
        0x48, 0x89, 0x44, 0x24, 0x08, // mov %rax, 0x08(%rsp)
        0x48, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, //  mov epilog_chain, %rax
        0x48, 0x89, 0x44, 0x24, 0x10, // mov %rax, 0x10(%rsp)

        // restore original return address now
        0x48, 0x8d, 0x75, 0x10, // lea 0x10(%rbp), %rsi // canonical frame address
        0x48, 0x8b, 0x3c, 0x24, // mov (%rsp), %rdi // target_id
        0x48, 0x8b, 0x44, 0x24, 0x08, // mov 0x08(%rsp), %rax // ora_get
        0xff, 0xd0, // call *%rax // call ora_get.
        0x48, 0x89, 0x45, 0x08, // mov %rax, 0x08(%rbp)

        // run epilog
        0x48, 0x31, 0xc9, // xor %rcx, %rcx
        0x48, 0xff, 0xc1, // inc %rcx // normal return flag
        0x48, 0x89, 0xea, // mov %rbp, %rdx // registers buffer
        0x48, 0x8d, 0x75, 0x10, // lea 0x10(%rbp), %rsi // canonical frame address
        0x48, 0x8b, 0x3c, 0x24, // mov (%rsp), %rdi // target_id
        0x48, 0x8b, 0x44, 0x24, 0x10, // mov 0x10(%rsp), %rax // epilog_chain 
        0xff, 0xd0, // call *%rax // call epilog_chain.

        0x48, 0x83, 0xc4, 0x18, // add $0x18, %rsp

        0x41, 0x5f, // pop %r15
        0x41, 0x5e, // pop %r14
        0x41, 0x5d, // pop %r13
        0x41, 0x5c, // pop %r12
        0x41, 0x5b, // pop %r11
        0x41, 0x5a, // pop %r10
        0x41, 0x59, // pop %r9
        0x41, 0x58, // pop %r8
        0x5f, // pop %rdi
        0x5e, // pop %rsi
        0x5b, // pop %rbx
        0x5a, // pop %rdx
        0x59, // pop %rcx
        0x58, // pop %rax

        // restore stack as it was and ready to
        // return to the original return address of target function.
        0x48, 0x89, 0xec, // mov %rbp, %rsp
        0x5d, // pop %rbp

        0xc3 // ret
    };

    size_t ora_get = reinterpret_cast<size_t>(oraGet);
    size_t epilog_chain = reinterpret_cast<size_t>(epilogChain);
    char arg_buf[128]; // should be sufficient
    char *arg = arg_buf;
    memcpy(arg, &m_begin_catch, sizeof(m_begin_catch));
    arg += sizeof(m_begin_catch);

    memcpy(arg, &target_id, sizeof(target_id));
    arg += sizeof(target_id);
    memcpy(arg, &ora_get, sizeof(ora_get));
    arg += sizeof(ora_get);
    memcpy(arg, &epilog_chain, sizeof(epilog_chain));
    arg += sizeof(epilog_chain);

    memcpy(arg, &m_rethrow, sizeof(m_rethrow));
    arg += sizeof(m_rethrow);

    memcpy(arg, &m_end_catch, sizeof(m_end_catch));
    arg += sizeof(m_end_catch);

    memcpy(arg, &m_unwind_resume, sizeof(m_unwind_resume));
    arg += sizeof(m_unwind_resume);

    memcpy(arg, &target_id, sizeof(target_id));
    arg += sizeof(target_id);
    memcpy(arg, &ora_get, sizeof(ora_get));
    arg += sizeof(ora_get);
    memcpy(arg, &epilog_chain, sizeof(epilog_chain));
    arg += sizeof(epilog_chain);

    size_t max_thunk_size = 512;

    size_t thunk_size = sizeof(template_buf);
    if (thunk_size > max_thunk_size) {
        hookStubLog("%s: %s: %s: %s", "create epilog thunk",
                target_name, module_name, "Too big thunk");
        return 0;
    }
    thunk_size = max_thunk_size;

    if (!m_epilog_free) {
        int num = 1024;
        void *p = mmap(0, num * max_thunk_size,
                PROT_READ | PROT_WRITE | PROT_EXEC,
                MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (MAP_FAILED == p) {
            hookStubLog("%s: %s: %s: %s", "create epilog thunk",
                    target_name, module_name, strerror(errno));
            return 0;
        }
        m_epilog_free = reinterpret_cast<char *>(p);
        char *q = m_epilog_free;
        for (int i = 0; i < num - 1; ++i) {
            char *next = q + max_thunk_size;
            *reinterpret_cast<char **>(q) = next;
            q = next;
        }
        *reinterpret_cast<char **>(q) = 0;
    }

    char *thunk_buf = m_epilog_free;
    m_epilog_free = *reinterpret_cast<char **>(m_epilog_free);

    char *thunk = thunk_buf;
    char *tmplt = template_buf;
    arg = arg_buf;
    while (tmplt < template_buf + sizeof(template_buf)) {
        if (*tmplt) {
            *thunk = *tmplt;
        } else {
            *thunk = *arg;
            ++arg;
        }
        ++thunk;
        ++tmplt;
    }

    EpilogThunk *epilog_thunk = new EpilogThunk();
    epilog_thunk->thunk_buf = thunk_buf;
    epilog_thunk->thunk_size = thunk_size;
    epilog_thunk->eh_frame = createEHFrame(epilog_thunk->thunk_buf,
            epilog_thunk->thunk_size);
    return epilog_thunk;
}
#else
EpilogThunk *HookManager::createEpilogThunk(size_t target_id,
        char *target_code, size_t target_size,
        const char *target_name, const char *module_name) {
    // arguments:
    // __cxa_begin_catch
    // target_id, ora_get, epilog_chain,
    // __cxa_rethrow
    // __cxa_end_catch
    // _Unwind_Resume
    // target_id, ora_get, epilog_chain,
    char template_buf[] = {
        // The machine code is arranged in a special order,
        // so that 'char' is enough for recording call site and landing pad

        0x90, // "nop" makes LSD::target_cs_lp non-zero.
        // landing pad of target call site (LSD::target_cs_lp)
        // TARGET_CS_LP = 1

        // allocate space for original return address
        0x83, 0xec, 0x04, // sub $0x04, %esp

        0x55, // push %ebp
        0x89, 0xe5, // mov %esp, %ebp

        0x50, // push %eax
        0x51, // push %ecx
        0x52, // push %edx
        0x53, // push %ebx
        0x56, // push %esi
        0x57, // push %edi

        0x83, 0xec, 0x10, // sub $0x10, %esp // allocate space for local usage

        // catch exception
        0x89, 0x04, 0x24, // mov %eax, (%esp) // _Unwind_Exception
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov __cxa_begin_catch, %eax
        0xff, 0xd0, // call *%eax // call __cxa_begin_catch 

        0x31, 0xc0, // xor %eax, %eax
        0x89, 0x44, 0x24, 0x0c, // mov %eax, 0x0c(%esp) // abnormal return flag 
        0x89, 0x6c, 0x24, 0x08, // mov %ebp, 0x08(%esp) // registers buffer
        0x8d, 0x45, 0x08, // lea 0x08(%ebp), %eax
        0x89, 0x44, 0x24, 0x04, // mov %eax, 0x04(%esp) // canonical frame address 
        0xc7, 0x04, 0x24, 0x00, 0x00, 0x00, 0x00, // movl target_id, (%esp)

        // restore original return address
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov ora_get, %eax
        0xff, 0xd0, // call *%eax // call ora_get 
        0x89, 0x45, 0x04, // mov %eax, 0x04(%ebp)

        // run epilog
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov epilog_chain, %eax
        0xff, 0xd0, // call *%eax // call epilog_chain

        // rethrow exception.
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov __cxa_rethrow, %eax
        // rethrow call site (LSD::rethrow_cs_start, LSD::rethrow_cs_len)
        // RETHROW_CS_START = 72, RETHROW_CS_LEN = 2
        0xff, 0xd0, // call *%eax // call __cxa_rethrow 

        // landing pad of rethrow call site (LSD::rethrow_cs_lp)
        // RETHROW_CS_LP = 74
        0x89, 0x04, 0x24, // mov %eax, (%esp) // _Unwind_Exception
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov __cxa_end_catch, %eax
        0xff, 0xd0, // call *%eax // call __cxa_end_catch
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov _Unwind_Resume, %eax
        // _Unwind_Resume call site (LSD::resume_cs_start, LSD::resume_cs_len).
        // No landing pad.
        // RESUME_CS_START = 89, RESUME_CS_LEN = 2
        0xff, 0xd0, // call *%eax // call _Unwind_Resume, no return

        // imaginary target call site (LSD::target_cs_start/target_cs_len)
        // TARGET_CS_START = 91
        // TARGET_CS_LEN = 4
        0x90, 0x90, 0x90, 0x90,

        // Without exception, we should start here.
        // allocate space for original return address
        0x83, 0xec, 0x04, // sub $0x04, %esp

        0x55, // push %ebp
        0x89, 0xe5, // mov %esp, %ebp

        0x50, // push %eax
        0x51, // push %ecx
        0x52, // push %edx
        0x53, // push %ebx
        0x56, // push %esi
        0x57, // push %edi

        0x83, 0xec, 0x10, // sub $0x10, %esp // allocate space for local usage

        0x31, 0xc0, // xor %eax, %eax
        0x40, // inc %eax
        0x89, 0x44, 0x24, 0x0c, // mov %eax, 0x0c(%esp) // normal return flag 
        0x89, 0x6c, 0x24, 0x08, // mov %ebp, 0x08(%esp) // registers buffer
        0x8d, 0x45, 0x08, // lea 0x08(%ebp), %eax
        0x89, 0x44, 0x24, 0x04, // mov %eax, 0x04(%esp) // canonical frame address 
        0xc7, 0x04, 0x24, 0x00, 0x00, 0x00, 0x00, // movl target_id, (%esp)

        // restore original return address now
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov ora_get, %eax
        0xff, 0xd0, // call *%eax // call ora_get 
        0x89, 0x45, 0x04, // mov %eax, 0x04(%ebp)

        // run epilog
        0xb8, 0x00, 0x00, 0x00, 0x00, // mov epilog_chain, %eax
        0xff, 0xd0, // call *%eax // call epilog_chain

        0x83, 0xc4, 0x10, // add $0x10, %esp

        0x5f, // pop %edi
        0x5e, // pop %esi
        0x5b, // pop %ebx
        0x5a, // pop %edx
        0x59, // pop %ecx
        0x58, // pop %eax

        // restore stack as it was and ready to
        // return to the original return address of target function.
        0x89, 0xec, // mov %ebp, %esp
        0x5d, // pop %ebp

        0xc3 // ret
    };

    size_t ora_get = reinterpret_cast<size_t>(oraGet);
    size_t epilog_chain = reinterpret_cast<size_t>(epilogChain);
    char arg_buf[128]; // should be sufficient
    char *arg = arg_buf;
    memcpy(arg, &m_begin_catch, sizeof(m_begin_catch));
    arg += sizeof(m_begin_catch);

    memcpy(arg, &target_id, sizeof(target_id));
    arg += sizeof(target_id);
    memcpy(arg, &ora_get, sizeof(ora_get));
    arg += sizeof(ora_get);
    memcpy(arg, &epilog_chain, sizeof(epilog_chain));
    arg += sizeof(epilog_chain);

    memcpy(arg, &m_rethrow, sizeof(m_rethrow));
    arg += sizeof(m_rethrow);

    memcpy(arg, &m_end_catch, sizeof(m_end_catch));
    arg += sizeof(m_end_catch);

    memcpy(arg, &m_unwind_resume, sizeof(m_unwind_resume));
    arg += sizeof(m_unwind_resume);

    memcpy(arg, &target_id, sizeof(target_id));
    arg += sizeof(target_id);
    memcpy(arg, &ora_get, sizeof(ora_get));
    arg += sizeof(ora_get);
    memcpy(arg, &epilog_chain, sizeof(epilog_chain));
    arg += sizeof(epilog_chain);

    size_t max_thunk_size = 256;

    size_t thunk_size = sizeof(template_buf);
    if (thunk_size > max_thunk_size) {
        hookStubLog("%s: %s: %s: %s", "create epilog thunk",
                target_name, module_name, "Too big thunk");
        return 0;
    }
    thunk_size = max_thunk_size;

    if (!m_epilog_free) {
        int num = 1024;
        void *p = mmap(0, num * max_thunk_size,
                PROT_READ | PROT_WRITE | PROT_EXEC,
                MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (MAP_FAILED == p) {
            hookStubLog("%s: %s: %s: %s", "create epilog thunk",
                    target_name, module_name, strerror(errno));
            return 0;
        }
        m_epilog_free = reinterpret_cast<char *>(p);
        char *q = m_epilog_free;
        for (int i = 0; i < num - 1; ++i) {
            char *next = q + max_thunk_size;
            *reinterpret_cast<char **>(q) = next;
            q = next;
        }
        *reinterpret_cast<char **>(q) = 0;
    }

    char *thunk_buf = m_epilog_free;
    m_epilog_free = *reinterpret_cast<char **>(m_epilog_free);

    char *thunk = thunk_buf;
    char *tmplt = template_buf;
    arg = arg_buf;
    while (tmplt < template_buf + sizeof(template_buf)) {
        if (*tmplt) {
            *thunk = *tmplt;
        } else {
            *thunk = *arg;
            ++arg;
        }
        ++thunk;
        ++tmplt;
    }

    EpilogThunk *epilog_thunk = new EpilogThunk();
    epilog_thunk->thunk_buf = thunk_buf;
    epilog_thunk->thunk_size = thunk_size;
    epilog_thunk->eh_frame = createEHFrame(epilog_thunk->thunk_buf,
            epilog_thunk->thunk_size);
    return epilog_thunk;
}
#endif

void HookManager::destroyPrologThunk(PrologThunk *prolog_thunk) {
    if (!prolog_thunk) {
        return;
    }
    *reinterpret_cast<char **>(prolog_thunk->thunk_buf) = m_prolog_free;
    m_prolog_free = prolog_thunk->thunk_buf;
}

void HookManager::destroyEpilogThunk(EpilogThunk *epilog_thunk) {
    if (!epilog_thunk) {
        return;
    }
    *reinterpret_cast<char **>(epilog_thunk->thunk_buf) = m_epilog_free;
    m_epilog_free = epilog_thunk->thunk_buf;
    destroyEHFrame(epilog_thunk->eh_frame);
}
}

namespace {
void HookManager::noReturn() {
    while (!m_context_list.empty()) {
        Context &context = m_context_list.back();
        // The last context will be removed by epilog.
        epilog(context.ti, context.cfa, 0 /* reg */, 0 /* abnormal return */);
    }
}

void HookManager::soResolvePendingTarget(void *handle) {
    if (handle == m_exe_handle) {
        return;
    }

    // Besides the shared library designated by handle,
    // we must also check its dependent shared libraries.

    TargetIterator first = m_target_vector.begin();
    TargetIterator last = m_target_vector.end();
    for (TargetIterator iter = first; iter != last; ++iter) {
        if (iter->pending
            && iter->module_descriptor != m_exe_descriptor) {
            FunctionSymbol function_symbol;
            struct link_map *lm = soLinkMap(iter->module_descriptor);
            if (!lm) {
                continue; // shared library is absent in process space.
            }
            char *module_address = reinterpret_cast<char *>(lm->l_addr);
            if (iter->target_size) {
                function_symbol.function_address = iter->target_vma
                    + module_address;
                function_symbol.function_size = iter->target_size;
            } else {
                void *module_handle = getWrapperManager()->dlopen(lm->l_name,
                        RTLD_LAZY);
                if (dynResolveFunction(handle,
                            iter->target_name.c_str(),
                            iter->module_name.c_str(), &function_symbol)) {
                    getWrapperManager()->dlclose(module_handle);
                    iter->pending = 0; // avoid resolving it in the future.
                    continue;
                }
                getWrapperManager()->dlclose(module_handle);
            }
            resolveTarget(iter, function_symbol, module_address);
        }
    }
}

void HookManager::soMarkPendingTarget(void *handle) {
    if (handle == m_exe_handle) {
        return;
    }
    // The shared library designated by handle may have been
    // unloaded from process space. In this case, its handle cannot
    // be used any more.
    // Furthermore, its dependent shared libraries may also have been
    // unloaded from process space.
    
    std::map<ModuleDescriptor, std::string> m;
    std::map<ModuleDescriptor, std::string>::iterator iter;

    TargetIterator first = m_target_vector.begin();
    TargetIterator last = m_target_vector.end();
    for (TargetIterator iter = first; iter != last; ++iter) {
        if (!iter->pending
            && iter->module_descriptor != m_exe_descriptor) {
            if (!soLinkMap(iter->module_descriptor)) {
                // Shared library has been unloaded from process space.
                destroyPrologThunk(iter->prolog_thunk);
                destroyEpilogThunk(iter->epilog_thunk);
                iter->target_code = 0;
                iter->prolog_thunk = 0;
                iter->epilog_thunk = 0;
                iter->pending = 1; // Shared library may be loaded again.
                m[iter->module_descriptor] = iter->module_name;
            }
        }
    }
    
    for (iter = m.begin(); iter != m.end(); ++iter) {
        getHookLibManager()->hookLibAtUnload(iter->second.c_str());
    }
}
}

namespace {
HookManager *HookManager::getInstance() {
    // HookManager is heavy weight.
    // In multi-process environ, It should be created iff necessary,
    // saying calling HookManager::getInstance.
    static HookManager hm;
    return &hm;
}

int HookManager::exeRegisterHook(const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    Hook hook;
    hook.prolog_routine = prolog_routine;
    hook.prolog_arg = prolog_arg;
    hook.epilog_routine = epilog_routine;
    hook.epilog_arg = epilog_arg;

    TargetIterator iter = findTarget(target_name, m_exe_descriptor);
    if (iter != m_target_vector.end()) {
        iter->hook_list.push_back(hook);
        return 0;
    }

    FunctionSymbol function_symbol;
    if (dynResolveFunction(m_exe_handle,
                target_name, m_exe_name, &function_symbol)) {
        return -1;
    }

    size_t target_vma;
    target_vma = function_symbol.function_address - m_exe_address;

    iter = addPendingTarget(target_vma, function_symbol.function_size,
            target_name, m_exe_name, m_exe_descriptor, hook);

    return resolveTarget(iter, function_symbol, m_exe_address);
}

int HookManager::exeRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    Hook hook;
    hook.prolog_routine = prolog_routine;
    hook.prolog_arg = prolog_arg;
    hook.epilog_routine = epilog_routine;
    hook.epilog_arg = epilog_arg;

    TargetIterator iter = findTarget(target_name, m_exe_descriptor);
    if (iter != m_target_vector.end()) {
        iter->hook_list.push_back(hook);
        return 0;
    }

    iter = addPendingTarget(target_vma, target_size,
            target_name, m_exe_name, m_exe_descriptor, hook);

    FunctionSymbol function_symbol;
    function_symbol.function_address = target_vma + m_exe_address;
    function_symbol.function_size = target_size;

    return resolveTarget(iter, function_symbol, m_exe_address);
}

int HookManager::soRegisterHook(const char *target_name,
        const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    ModuleDescriptor module_descriptor;
    if (initModuleDescriptor(module_name, &module_descriptor)) {
        return -1;
    }

    Hook hook;
    hook.prolog_routine = prolog_routine;
    hook.prolog_arg = prolog_arg;
    hook.epilog_routine = epilog_routine;
    hook.epilog_arg = epilog_arg;

    TargetIterator iter = findTarget(target_name, module_descriptor);
    if (iter != m_target_vector.end()) {
        iter->hook_list.push_back(hook);
        return 0;
    }

    struct link_map *module_lm = soLinkMap(module_descriptor);
    if (!module_lm) {
        // pending target may be resolvable if loading more shared libraries.
        // When loading more shared libraries, we check any pending target
        // and try to resolve it.
        addPendingTarget(0, 0, target_name, module_name,
                module_descriptor, hook);
        return 1;
    }

    char *module_address = reinterpret_cast<char *>(module_lm->l_addr);

    FunctionSymbol function_symbol;

    void *module_handle = getWrapperManager()->dlopen(module_lm->l_name,
            RTLD_LAZY);

    if (dynResolveFunction(module_handle, target_name, module_name,
                &function_symbol)) {
        getWrapperManager()->dlclose(module_handle);
        return -1;
    }

    getWrapperManager()->dlclose(module_handle);

    size_t target_vma;
    target_vma = function_symbol.function_address - module_address;
    iter = addPendingTarget(target_vma, function_symbol.function_size,
            target_name, module_name, module_descriptor, hook);

    return resolveTarget(iter, function_symbol, module_address);
}

int HookManager::soRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name, const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    ModuleDescriptor module_descriptor;
    if (initModuleDescriptor(module_name, &module_descriptor)) {
        return -1;
    }

    Hook hook;
    hook.prolog_routine = prolog_routine;
    hook.prolog_arg = prolog_arg;
    hook.epilog_routine = epilog_routine;
    hook.epilog_arg = epilog_arg;

    TargetIterator iter = findTarget(target_name, module_descriptor);
    if (iter != m_target_vector.end()) {
        iter->hook_list.push_back(hook);
        return 0;
    }

    iter = addPendingTarget(target_vma, target_size,
            target_name, module_name, module_descriptor, hook);

    struct link_map *module_lm = soLinkMap(module_descriptor);
    if (!module_lm) {
        // pending target may be resolvable if loading more shared libraries.
        // When loading more shared libraries, we check any pending target
        // and try to resolve it.
        return 1;
    }

    char *module_address = reinterpret_cast<char *>(module_lm->l_addr);

    FunctionSymbol function_symbol;
    function_symbol.function_address = target_vma + module_address;
    function_symbol.function_size = target_size;

    return resolveTarget(iter, function_symbol, module_address);
}

TargetIterator HookManager::addPendingTarget(size_t target_vma,
        size_t target_size, const char *target_name, const char *module_name,
        const ModuleDescriptor &module_descriptor, const Hook &hook) {
    Target target;
    target.target_id = m_target_vector.size();
    target.target_vma = target_vma;
    target.target_size = target_size;
    target.target_name = target_name;
    target.module_name = module_name;
    target.module_descriptor = module_descriptor;
    target.hook_list.push_back(hook);
    target.target_code = 0;
    target.prolog_thunk = 0;
    target.epilog_thunk = 0;
    target.pending = 1;
    return m_target_vector.insert(m_target_vector.end(), target);
}

int HookManager::resolveTarget(TargetIterator iter,
        const FunctionSymbol &function_symbol, char *module_address) {
    size_t target_size;
    target_size = function_symbol.function_size;

    char *target_code = function_symbol.function_address;

    const char *target_name = iter->target_name.c_str();
    const char *module_name = iter->module_name.c_str();

    char *remaining_code;
    remaining_code = findRemainingCode(target_code, target_size,
            target_name, module_name);
    if (!remaining_code) {
        return -1;
    }

    size_t target_id = iter->target_id;

    EpilogThunk *epilog_thunk = createEpilogThunk(target_id,
            target_code, target_size, target_name, module_name);
    if (!epilog_thunk) {
        return -1;
    }

    PrologThunk *prolog_thunk = createPrologThunk(target_id,
            target_code, remaining_code, epilog_thunk,
            target_name, module_name);
    if (!prolog_thunk) {
        destroyEpilogThunk(epilog_thunk);
        return -1;
    }

    if (hackTarget(target_code, remaining_code, target_name, module_name)) {
        destroyPrologThunk(prolog_thunk);
        destroyEpilogThunk(epilog_thunk);
        return -1;
    }

    iter->target_code = target_code;
    iter->target_vma = target_code - module_address;
    iter->target_size = target_size;
    iter->prolog_thunk = prolog_thunk;
    iter->epilog_thunk = epilog_thunk;

    iter->pending = 0;
    m_addr_id_map[iter->target_code] = iter->target_id;
    return 0;
}
}

// utility function implementation
namespace {
/*!
 * \brief Call each registered prolog routine for target function
 * \param target_id Identifier of target function
 * \param cfa Canonical frame address
 * \param reg General registers buffer 
 * \prarm target_ra Return address of target function
 */
void prologChain(size_t target_id, size_t *cfa, size_t *reg, void *target_ra) {
    HookManager *hm = HookManager::getInstance();
    hm->prolog(target_id, cfa, reg, target_ra);
}

/*!
 * \brief Call each registered epilog routine for target function
 * \param target_id Identifier of target function
 * \param cfa Canonical frame address
 * \param reg General registers buffer 
 * \param ret Flag if target function returns normally.
 */
void epilogChain(size_t target_id, size_t *cfa, size_t *reg, int ret) {
    HookManager *hm = HookManager::getInstance();
    hm->epilog(target_id, cfa, reg, ret);
}

/*!
 * \brief Get original return address of target function
 * \param target_id Identifier of target function
 * \param cfa Canonical frame address
 * \return It shall return original return address of target function.
 */
void *oraGet(size_t target_id, size_t *cfa) {
    HookManager *hm = HookManager::getInstance();
    return hm->ora(target_id, cfa);
}

void hookStubLog(const char *format, ...) {
    va_list args;
    va_start(args, format);
    fprintf(stderr, "libhookstub: ");
    vfprintf(stderr, format, args);
    fprintf(stderr, "\n");
    va_end(args);
}

WrapperManager *getWrapperManager() {
    return &g_wrapper_manager;
}

HookLibManager *getHookLibManager() {
    return &g_hook_lib_manager;
}

void handleSigTrap(int sig, siginfo_t *info, void *data) {
    ucontext_t *uc = reinterpret_cast<ucontext_t *>(data);
    char *entry;
    size_t *cfa;
    void *ra;
    size_t buf[HOOK_STUB_NREG];
    size_t *reg = buf + HOOK_STUB_NREG;
#ifdef HOOK_STUB_64
    int ip = REG_RIP;
    int sp = REG_RSP;
    reg[HOOK_STUB_RAX] = uc->uc_mcontext.gregs[REG_RAX];
    reg[HOOK_STUB_RCX] = uc->uc_mcontext.gregs[REG_RCX];
    reg[HOOK_STUB_RDX] = uc->uc_mcontext.gregs[REG_RDX];
    reg[HOOK_STUB_RBX] = uc->uc_mcontext.gregs[REG_RBX];
    reg[HOOK_STUB_RSI] = uc->uc_mcontext.gregs[REG_RSI];
    reg[HOOK_STUB_RDI] = uc->uc_mcontext.gregs[REG_RDI];
    reg[HOOK_STUB_R8] = uc->uc_mcontext.gregs[REG_R8];
    reg[HOOK_STUB_R9] = uc->uc_mcontext.gregs[REG_R9];
    reg[HOOK_STUB_R10] = uc->uc_mcontext.gregs[REG_R10];
    reg[HOOK_STUB_R11] = uc->uc_mcontext.gregs[REG_R11];
    reg[HOOK_STUB_R12] = uc->uc_mcontext.gregs[REG_R12];
    reg[HOOK_STUB_R13] = uc->uc_mcontext.gregs[REG_R13];
    reg[HOOK_STUB_R14] = uc->uc_mcontext.gregs[REG_R14];
    reg[HOOK_STUB_R15] = uc->uc_mcontext.gregs[REG_R15];
#else
    int ip = REG_EIP;
    int sp = REG_ESP;
    reg[HOOK_STUB_EAX] = uc->uc_mcontext.gregs[REG_EAX];
    reg[HOOK_STUB_ECX] = uc->uc_mcontext.gregs[REG_ECX];
    reg[HOOK_STUB_EDX] = uc->uc_mcontext.gregs[REG_EDX];
    reg[HOOK_STUB_EBX] = uc->uc_mcontext.gregs[REG_EBX];
    reg[HOOK_STUB_ESI] = uc->uc_mcontext.gregs[REG_ESI];
    reg[HOOK_STUB_EDI] = uc->uc_mcontext.gregs[REG_EDI];
#endif
    entry = reinterpret_cast<char *>(uc->uc_mcontext.gregs[ip]) - 1;
    cfa = reinterpret_cast<size_t *>(uc->uc_mcontext.gregs[sp]) + 1;
    // return address of target function
    ra = *reinterpret_cast<void **>(uc->uc_mcontext.gregs[sp]);

    HookManager *hm = HookManager::getInstance();

    // Inside signal handler, we know entry address of target function.
    // So, get the target based on its entry address.
    Target *target = hm->findTarget(entry);
    if (!target || target->pending) {
        return;
    }

    prologChain(target->target_id, cfa, reg, ra);

    // transfer control to prolog thunk after signal handler returns.
    uc->uc_mcontext.gregs[ip]
        = reinterpret_cast<greg_t>(target->prolog_thunk->thunk_buf);
}
}

// wrapper functions
extern "C" {
/* HookLibManager::HookLibManager calls init routine of hook library, which
 * in turn may call wrapper function. In this case, the global HookLibManager
 * object is not fully constructed.
 * So, It's risky for wrapper function to refer the global HookLibManager
 * object. We need to be very careful!
 * One solution is seperating the functionality of init/fini hook library from
 * HookLibManager and delegating it to one global object of class HookLibInitFini.
 */
pid_t fork(void) {
    WrapperManager *wm = getWrapperManager();
    pid_t pid = wm->fork();
    if (0 == pid) { // child
        HookLibManager *hlm = getHookLibManager();
        hlm->hookLibAtFork();
    }
    return pid;
}

void exit(int status) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();
    wm->exit(status);
}

void abort(void) {
    // FIXME: Is it safe to do anything in case of emergency, saying "abort"?
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();
    hlm->hookLibFini();
    wm->abort();
}

void *dlopen(const char *name, int mode) {
    void *ret = getWrapperManager()->dlopen(name, mode);
    if (ret) {
        // More libraries may be loaded into process's space.
        // Resolve pending SO target if possible.
        getHookLibManager()->soResolvePendingTarget(ret);
    }
    return ret;
}

int dlclose(void *handle) {
    int ret = getWrapperManager()->dlclose(handle);
    if (!ret) {
        // Shared library may be unloaded from process's space.
        // Mark resolved SO target as pending if necessary.

        getHookLibManager()->soMarkPendingTarget(handle);
    }
    return ret;
}

// Hook stub is using SIGTRAP.
// Other components shall not install SIGTRAP handler again.
void (*signal(int sig, void (*handler)(int)))(int) {
    if (SIGTRAP == sig) {
        errno = EINVAL;
        return SIG_ERR;
    }
    return getWrapperManager()->signal(sig, handler);
}

int sigaction(int sig, const struct sigaction *act, struct sigaction *oact) {
    if (SIGTRAP == sig) {
        if (act) {
            errno = EINVAL;
            return -1;
        }
        return getWrapperManager()->sigaction(sig, 0, oact);
    }
    return getWrapperManager()->sigaction(sig, act, oact);
}

#if 0
int execve(const char *path, char *const argv[], char *const envp[]) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn(); // side effect: If underlying execve fails, It does return.
    return wm->execve(path, argv, envp);
}

int execv(const char *path, char *const argv[]) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();
    return wm->execv(path, argv);
}

int execvp(const char *file, char *const argv[]) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();
    return wm->execvp(file, argv);
}

int execl(const char *path, const char *arg, ...) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();

    int argc = 0;
    char **argv = 0;
    typedef char *cstr_ptr_t;

    const char *p = 0;
    va_list ap;

    va_start(ap, arg);
    p = arg;
    while (p) {
        ++argc;
        p = va_arg(ap, const char *);
    }
    va_end(ap);

    argv = new cstr_ptr_t[argc + 1];

    va_start(ap, arg);
    p = arg;
    int i = 0;
    while (p) {
        char *buf = new char[strlen(p) + 1];
        strcpy(buf, p);
        argv[i] = buf;
        p = va_arg(ap, const char *);
        ++i;
    }
    va_end(ap);

    argv[argc] = 0;

    return wm->execv(path, argv);
}

int execlp(const char *file, const char *arg, ...) {
    WrapperManager *wm = getWrapperManager();
    HookLibManager *hlm = getHookLibManager();
    hlm->noReturn();

    int argc = 0;
    char **argv = 0;
    typedef char *cstr_ptr_t;

    const char *p = 0;
    va_list ap;

    va_start(ap, arg);
    p = arg;
    while (p) {
        ++argc;
        p = va_arg(ap, const char *);
    }
    va_end(ap);

    argv = new cstr_ptr_t[argc + 1];

    va_start(ap, arg);
    p = arg;
    int i = 0;
    while (p) {
        char *buf = new char[strlen(p) + 1];
        strcpy(buf, p);
        argv[i] = buf;
        p = va_arg(ap, const char *);
        ++i;
    }
    va_end(ap);

    argv[argc] = 0;

    return wm->execvp(file, argv);
}
#endif
}

// API of hook stub.
int exeRegisterHook(const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    HookManager *hm = HookManager::getInstance();
    return hm->exeRegisterHook(target_name,
            prolog_routine, prolog_arg,
            epilog_routine, epilog_arg);
}

int soRegisterHook(const char *target_name, const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    HookManager *hm = HookManager::getInstance();
    return hm->soRegisterHook(target_name, module_name,
            prolog_routine, prolog_arg,
            epilog_routine, epilog_arg);
}

int exeRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    HookManager *hm = HookManager::getInstance();
    return hm->exeRegisterHook_(target_vma, target_size, target_name,
            prolog_routine, prolog_arg,
            epilog_routine, epilog_arg);
}

int soRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name, const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg) {
    HookManager *hm = HookManager::getInstance();
    return hm->soRegisterHook_(target_vma, target_size,
            target_name, module_name,
            prolog_routine, prolog_arg,
            epilog_routine, epilog_arg);
}

int exeAddress(void **module_address) {
    HookManager *hm = HookManager::getInstance();
    return hm->exeAddress(module_address);
}

int soAddress(const char *module_name, void **module_address) {
    HookManager *hm = HookManager::getInstance();
    return hm->soAddress(module_name, module_address);
}

