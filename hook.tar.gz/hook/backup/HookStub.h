#ifndef HOOK_STUB_H
#define HOOK_STUB_H

#ifdef __cplusplus
extern "C" {
#endif

#if __WORDSIZE == 64
#define HOOK_STUB_64
#endif

#ifdef HOOK_STUB_64
enum {
    HOOK_STUB_RAX = -1,
    HOOK_STUB_RCX = -2,
    HOOK_STUB_RDX = -3,
    HOOK_STUB_RBX = -4,
    HOOK_STUB_RSI = -5,
    HOOK_STUB_RDI = -6,
    HOOK_STUB_R8 = -7,
    HOOK_STUB_R9 = -8,
    HOOK_STUB_R10 = -9,
    HOOK_STUB_R11 = -10,
    HOOK_STUB_R12 = -11,
    HOOK_STUB_R13 = -12,
    HOOK_STUB_R14 = -13,
    HOOK_STUB_R15 = -14
};
#define HOOK_STUB_NREG (-HOOK_STUB_R15)
#else // assume 32bit
enum {
    HOOK_STUB_EAX = -1,
    HOOK_STUB_ECX = -2,
    HOOK_STUB_EDX = -3,
    HOOK_STUB_EBX = -4,
    HOOK_STUB_ESI = -5,
    HOOK_STUB_EDI = -6
};
#define HOOK_STUB_NREG (-HOOK_STUB_EDI)
#endif

/*!
 * \brief Prototype of prolog hook.
 * \param target_name Name of target function
 * \param module_name Name of module containing target function definition
 * \param cfa Canonical frame address
 * \param reg General registers buffer
 * \param arg Argument of epilog hook.
 * \note It's possible to access the argument of target function via \a cfa
 * and/or \a reg.
 * e.g, cfa[0] should be the first argument of target function in IA32.
 * In x86_64,
 * reg[HOOK_STUB_RDI] should be the 1st argument,
 * reg[HOOK_STUB_RSI] should be the 2nd argument,
 * reg[HOOK_STUB_RDX] should be the 3rd argument,
 * reg[HOOK_STUB_RCX] should be the 4th argument,
 * reg[HOOK_STUB_R8] should be the 5th argument,
 * reg[HOOK_STUB_R9] should be the 6th argument,
 * cfa[0] should be the 7th argument.
 */
typedef void (*PrologRoutine)(const char *target_name, const char *module_name,
        const size_t *cfa, const size_t *reg, void *arg);

/*!
 * \brief Prototype of epilog hook.
 * \param target_name Name of target function
 * \param module_name Name of module containing target function definition
 * \param cfa Canonical frame address
 * \param reg General registers buffer 
 * \param ret Flag if target function returns normally
 * \param arg Argument of epilog hook.
 * \note Only if \a ret is non-zero, \a cfa and \a reg are valid.
 */
typedef void (*EpilogRoutine)(const char *target_name, const char *module_name,
        const size_t *cfa, const size_t *reg, int ret, void *arg);

/*!
 * \brief Register prolog hook and epilog hook for target function of EXE.
 * \param target_name Name of target function
 * \param prolog_routine Prolog routine called at entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successful completion, It shall return 0.
 * \note Target function should appear in .dynsym section of EXE.
 */
int exeRegisterHook(const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*!
 * \brief Register prolog hook and epilog hook for target function of EXE.
 * \param target_vma Offset of target function relative to EXE base address.
 * \param target_size Size of target function.
 * \param target_name Name of target function
 * \param prolog_routine Prolog routine called at entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successful completion, It shall return 0.
 */
int exeRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*!
 * \brief Register prolog hook and epilog hook for target function of SO.
 * \param target_name Name of target function
 * \param module_name Path name of shared library defining target function
 * \param prolog_routine Prolog routine called at entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successful completion, It shall return 0. If return value
 * is greatern than 0, It means that the target function is in pending state,
 * i.e., It may be resolvable if loading more shared libraries in the future.
 * \note Target function should appear in .dynsym section of SO.
 */
int soRegisterHook(const char *target_name, const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*!
 * \brief Register prolog hook and epilog hook for target function of EXE.
 * \param target_vma Offset of target function relative to SO base address.
 * \param target_size Size of target function.
 * \param target_name Name of target function
 * \param module_name Path name of shared library defining target function
 * \param prolog_routine Prolog routine called at entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successful completion, It shall return 0.
 */
int soRegisterHook_(size_t target_vma, size_t target_size,
        const char *target_name, const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*!
 * \brief Get the base address of EXE.
 * \param module_address Receiving the base address of EXE.
 * \return Upon successful completion, It shall return 0.
 */
int exeAddress(void **module_address);

/*!
 * \brief Get the base address of shared library.
 * \param module_name Path name of shared library
 * \param module_address Receiving the base address of shared library.
 * \return Upon successful completion, It shall return 0. If shared library
 * is not yet loaded into process space, It shall return -1.
 */
int soAddress(const char *module_name, void **module_address);

/*! \brief API sets of hook stub */
typedef struct HookStub {
    int (*exeRegisterHook)(const char *target_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int (*soRegisterHook)(const char *target_name, const char *module_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int (*exeRegisterHook_)(size_t target_vma, size_t target_size,
            const char *target_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int (*soRegisterHook_)(size_t target_vma, size_t target_size,
            const char *target_name, const char *module_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int (*exeAddress)(void **module_address);

    int (*soAddress)(const char *module_name, void **module_address);
} HookStub;

#ifdef __cplusplus
}
#endif

#endif

