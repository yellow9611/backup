#include <stdio.h>
#include "bfd.h"
int main(int argc, char *argv[]) {
    long cbsize;
    asymbol **symtab;
    long count;
    long i;
    bfd *abfd;
    asection *section;
    bfd_init();
    abfd = bfd_openr(argv[1], 0);
    bfd_check_format(abfd, bfd_object);
    printf("start = %x\n", bfd_get_start_address(abfd));

    cbsize = bfd_get_symtab_upper_bound(abfd);

    symtab = (asymbol **)(malloc(cbsize));

    count = bfd_canonicalize_symtab(abfd, symtab);

    for (i = 0; i < count; ++i) {
        long base = symtab[i]->section->vma;
        long value = symtab[i]->value;
        printf("%s %x %x\n", bfd_asymbol_name(symtab[i]), base, value);
    }

    free(symtab);

    bfd_close(abfd);
    return 0;
}

