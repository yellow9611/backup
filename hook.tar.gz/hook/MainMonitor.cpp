#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct Target {
    string function;
    string module;
    Target(const string &f, const string &m) : function(f), module(m) { }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

void prologMainMonitor(const char *name, const char *module,
        const size_t *cfa, const size_t *reg, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    assert(strcmp(name, "main") == 0);
#ifdef HOOK_STUB_64
    int argc = reg[HOOK_STUB_RDI];
    char **argv = reinterpret_cast<char **>(reg[HOOK_STUB_RSI]);
#else
    int argc = cfa[0];
    char **argv = reinterpret_cast<char **>(cfa[1]);
#endif

    fprintf(stderr, "libmainmonitor: main: argc = %d\n", argc);
    for (int i = 0; i < argc; ++i) {
        fprintf(stderr, "argv[%d] = %s\n", i, argv[i]);
    }
}

void epilogMainMonitor(const char *name, const char *module,
        const size_t *cfa, const size_t *reg, int ret, void *arg) {
    if (!ret) {
        return;
    }
    Target *target = reinterpret_cast<Target *>(arg);
    assert(strcmp(name, "main") == 0);
#ifdef HOOK_STUB_64
    int argc = reg[HOOK_STUB_RDI];
    char **argv = reinterpret_cast<char **>(reg[HOOK_STUB_RSI]);
#else
    int argc = cfa[0];
    char **argv = reinterpret_cast<char **>(cfa[1]);
#endif

    fprintf(stderr, "libmainmonitor: main: argc = %d\n", argc);
    for (int i = 0; i < argc; ++i) {
        fprintf(stderr, "argv[%d] = %s\n", i, argv[i]);
    }

#ifdef HOOK_STUB_64
    int rv = reg[HOOK_STUB_RAX];
#else
    int rv = reg[HOOK_STUB_EAX];
#endif
    fprintf(stderr, "return value = %d\n", rv); 
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);
    while (1) {
        string function;
        string module;
        ifs >> function >> module;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(),
                    prologMainMonitor, &target, epilogMainMonitor, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(),
                    target.module.c_str(),
                    prologMainMonitor, &target, epilogMainMonitor, &target);
        }
    }

    return 0;
}

void hookLibFini() {
}

