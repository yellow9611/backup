static void foo(void) {
}

static void bar(void) {
}

