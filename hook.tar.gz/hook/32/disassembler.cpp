#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "bfd.h"
#include "dis-asm.h"

char g_asm_code[128];

int disassemblerPrintf(void *stream, const char *format, ...) {
    size_t len = strlen(g_asm_code);
    va_list args;
    va_start(args, format);
    vsnprintf(g_asm_code + len, sizeof(g_asm_code) - len, format, args);
    va_end(args);
    return 0;
}

int main(int argc, char *argv[]) {
    disassembler_ftype m_disassembler;
    disassemble_info m_disassemble_info;
    const char *m_exe_name = "./a.out";

    bfd_init();
    bfd *abfd = bfd_openr(m_exe_name, 0);
    bfd_check_format(abfd, bfd_object);
    m_disassembler = disassembler(abfd);
    init_disassemble_info(&m_disassemble_info, 0, disassemblerPrintf);
    m_disassemble_info.mach = bfd_get_mach(abfd);
    m_disassemble_info.arch = bfd_get_arch(abfd);
    disassemble_init_for_target(&m_disassemble_info);
    bfd_close(abfd);

    void *target_code = (void *)(main);
    bfd_vma buffer_vma = reinterpret_cast<bfd_vma>(target_code);
    char buffer[32]; // should be sufficient for first instruction
    m_disassemble_info.buffer = reinterpret_cast<bfd_byte *>(target_code);
    m_disassemble_info.buffer_length = sizeof(buffer);
    m_disassemble_info.buffer_vma = buffer_vma;
    //memcpy(buffer, target_code, sizeof(buffer));
    int len = m_disassembler(buffer_vma, &m_disassemble_info);

    if (len > 0) {
        printf("%s\n", g_asm_code);
    }
    return 0;
}

