#ifndef HOOK_LIB_H
#define HOOK_LIB_H

#include "HookStub.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*HookLibInitRoutine)(const HookStub *hook_stub,
        const char *config_file);
typedef void (*HookLibFiniRoutine)(void);
typedef void (*HookLibAtForkRoutine)(void);
typedef void (*HookLibAtUnloadRoutine)(const char *name);

/*!
 * \brief It is called once hook library is loaded into process space.
 * \return Upon successful completion, It shall return 0.
 */
int hookLibInit(const HookStub *hook_stub, const char *config_file);

/*!
 * \brief It is called once hook library is going to be unloaded from
 * process space.
 */
void hookLibFini(void);

/*!
 * \brief Hook library in child process receives fork notification.
 */
void hookLibAtFork(void);

/*!
 * \brief Hook library receives notification when shared library is unloaded
 * from process space.
 * \param name Path name of shared library.
 */
void hookLibAtUnload(const char *name);

#ifdef __cplusplus
}
#endif

#endif

