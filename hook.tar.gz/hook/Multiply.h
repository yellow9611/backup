#ifndef MULTIPLY_H
#define MULTIPLY_H

#ifdef __cplusplus
extern "C" {
#endif

int mul(int i, int j);

#ifdef __cplusplus
}
#endif

#endif


