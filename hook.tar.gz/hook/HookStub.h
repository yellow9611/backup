#ifndef HOOK_STUB_H
#define HOOK_STUB_H

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * \brief Prototype of prolog hook.
 * \param id Target identifier
 * \param cfa Canonical frame address
 * \param arg Argument of prolog hook
 * \note It's possible to access the argument of target function via \a cfa.
 * e.g, cfa[0] should be the first argument of target function in IA32.
 */
typedef void (*PrologRoutine)(size_t id,
        const size_t *cfa, void *arg);

/*!
 * \brief Prototype of epilog hook.
 * \param id Target identifier
 * \param cfa Canonical frame address
 * \param ret Flag if target function returns normally
 * \param arg Argument of epilog hook.
 */
typedef void (*EpilogRoutine)(size_t id,
        const size_t *cfa, int ret, void *arg);

typedef struct Module Module; /* opaque */

/*!
 * \brief Open module object.
 * \param name Module name
 * \return Upon successful completion, It shall return a pointer
 * to the module object. Otherwise, It shall return 0.
 */
Module *openModule(const char *name);

/*! \brief Close module object. */
void closeModule(Module *);

/*!
 * \brief Get the symbol offset relative to the base address of module image.
 * \param module Module object
 * \param name Global symbol name
 * \return If symbol is not found in the module, It shall return -1.
 */
ssize_t getSymbolOffset(Module *module, const char *name);

/*!
 * \brief Register prolog hook and epilog hook for target function.
 * \return Upon successful completion, It shall designate one unique identifier
 * for the target and return it. Otherwise, It shall return -1.
 */
ssize_t registerHook(const char *module_name, const char *target_name,
        size_t target_offset,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);


/*! \brief API sets of hook stub */
typedef struct HookStub {
    Module *(*openModule)(const char *);
    void (*closeModule)(Module *);
    ssize_t (*getSymbolOffset)(Module *, const char *);
    ssize_t (*registerHook)(const char *, const char *, size_t,
            PrologRoutine, void *,
            EpilogRoutine, void *);
} HookStub;

#ifdef __cplusplus
}
#endif

#endif

