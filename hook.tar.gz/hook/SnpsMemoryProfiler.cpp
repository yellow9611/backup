#include <unistd.h>
#include <stdio.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct Target {
    string function;
    string module;
    Target(const string &f, const string &m) : function(f), module(m) { }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

typedef void *mem_group;
// If mem_groups_size is inaccessible dynamically, we have trouble.
extern "C" {
size_t mem_get_info(int);
size_t mem_groups_size(void);
size_t mem_group_size(mem_group group);
size_t mem_group_get_free(mem_group group, long *p_free_blocks);
size_t mem_group_get_active(mem_group group, long *p_allocations);
const char *mem_get_group_name(mem_group group);
mem_group mem_next_group(mem_group group);
}

void showMemoryGroupStatus(const Target *target, const char *phase) {
    size_t scale = 1024 * 1024;
    int MEM_INFO_MB_TOTAL = 1;
    fprintf(stderr, "libsnpsmemoryprofiler<%u, %u>: %s: %s: %s: "
            "{ PageAllocator = %luMB, MemoryGroups = %luMB }\n",
            getpid(), getppid(),
            phase, target->function.c_str(), target->module.c_str(),
            mem_get_info(MEM_INFO_MB_TOTAL),
            mem_groups_size() / scale );
#if 0
    mem_group mg = mem_next_group(0);
    while (mg) {
        long dummy;
        const char *mg_name = mem_get_group_name(mg);
        if (!mg_name) {
            mg_name = "nil";
        }
        size_t mg_size = mem_group_size(mg);
        size_t mg_active = mem_group_get_active(mg, &dummy);
        size_t mg_free = mem_group_get_free(mg, &dummy);
        fprintf(stderr,
                "{ name = %s, size = %luMB, active = %luMB, free = %luMB }\n",
                mg_name, mg_size / scale, mg_active / scale, mg_free / scale);
        mg = mem_next_group(mg);
    }
#endif
}

void prolog(const char *name, const char *module,
        const size_t *cfa, const size_t *reg, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    showMemoryGroupStatus(target, "enter");
}

void epilog(const char *name, const char *module,
        const size_t *cfa, const size_t *reg, int ret, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    showMemoryGroupStatus(target, "leave");
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);
    while (1) {
        string function;
        string module;
        ifs >> function >> module;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(),
                    prolog, &target, epilog, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(),
                    target.module.c_str(), prolog, &target, epilog, &target);
        }
    }

    return 0;
}

void hookLibFini() {
}

