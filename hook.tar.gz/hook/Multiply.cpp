#include "Multiply.h"
int mul(int i, int j) {
    int ret = i * j;
    return ret;
}

