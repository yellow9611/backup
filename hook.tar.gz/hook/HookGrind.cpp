#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>

using namespace std;

static void usage(int argc, char *argv[]);

int main(int argc, char *argv[]) {
    if (argc < 3) {
        usage(argc, argv);
    }

    string cwd = "./";
    string preload = argv[1];
    if ('/' != preload[0]) {
        preload = cwd + preload;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return -1;
    }
    
    if (0 == pid) { // child
        if (setenv("LD_PRELOAD", preload.c_str(), 1 /* overwrite */)) {
            perror("setenv");
            return -1;
        }
        execvp(argv[2], &argv[2]);
        perror("execvp");
        return -1;
    }
    
    // parent
    int status;
    if (-1 == wait(&status)) {
        perror("wait");
        return -1;
    }

    return 0;
}

void usage(int argc, char *argv[]) {
    fprintf(stderr, "Usage: %s %s %s\n",
            argv[0], "hookstub", "program [arguments]");
}

