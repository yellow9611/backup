#include <stdio.h>
extern "C" long add(long i, long j) {
    long sum = i + j;
    throw sum;
    return sum;
}

int main(int argc, char *argv[]) {
    try {
        add(1, 2);
    } catch (long e) {
        fprintf(stderr, "catch long exception %ld\n", e);
    }
    return 0;
}

