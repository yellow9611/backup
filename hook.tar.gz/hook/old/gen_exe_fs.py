#!/bin/env python
import os
import sys
import re

def main():
    str = r"""
        ^
        \s+
        (\d+) # Num
        :\s+
        ([0-9a-fA-F]+) # Value
        \s+
        (\d+) # Size
        \s+
        FUNC # Type
        \s+
        GLOBAL # Bind
        \s+
        DEFAULT # Vis
        \s+
        ([0-9a-zA-Z]+) # Ndx
        \s+
        ([0-9a-zA-Z_]+) # Name
        $
    """
    pattern = re.compile(str, re.VERBOSE)

    in_file = os.popen(" ".join(["readelf", "-s", "-W", sys.argv[1]]));
    out_file = open(sys.argv[2], "w");

    for line in in_file:
        match = pattern.match(line)
        if match:
            (num, value, size, ndx, name) = match.groups()
            if ndx != "UND" and int(size):
                msg = " ".join([name, value, size, "\n"])
                out_file.write(msg)

    in_file.close();
    out_file.close();

if __name__ == "__main__":
    main()

