#include "Multiply.h"

extern "C" int add(int i, int j) {
    int sum = i + j;
    return sum;
}

int main(int argc, char *argv[]) {
    int i;
    int j;
    for (i = 0; i < 16; ++i) {
        for (j = 0; j < 16; ++j) {
            add(i, j);
            mul(i, j);
        }
    }
    return 0;
}

