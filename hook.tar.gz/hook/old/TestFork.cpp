#include <unistd.h>

int main(int argc, char *argv[]) {
    fork();
    return 0;
}

