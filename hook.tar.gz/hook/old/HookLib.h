#ifndef HOOK_LIB_H
#define HOOK_LIB_H

#include "HookStub.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*HookLibInitRoutine)(const HookStub *hook_stub,
        const char *config_file);
typedef void (*HookLibFiniRoutine)(void);
typedef void (*HookLibAtForkRoutine)(void);

/*! \brief Upon successful completion, It shall return 0. */
int hookLibInit(const HookStub *hook_stub, const char *config_file);

void hookLibFini(void);

void hookLibAtFork(void);

#ifdef __cplusplus
}
#endif

#endif

