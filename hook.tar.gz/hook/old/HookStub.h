#ifndef HOOK_STUB_H
#define HOOK_STUB_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef HOOK_STUB_64
enum {
    HOOK_STUB_RAX = -1,
    HOOK_STUB_RCX = -2,
    HOOK_STUB_RDX = -3,
    HOOK_STUB_RBX = -4,
    HOOK_STUB_RSI = -5,
    HOOK_STUB_RDI = -6,
    HOOK_STUB_R8 = -7,
    HOOK_STUB_R9 = -8,
    HOOK_STUB_R10 = -9,
    HOOK_STUB_R11 = -10,
    HOOK_STUB_R12 = -11,
    HOOK_STUB_R13 = -12,
    HOOK_STUB_R14 = -13,
    HOOK_STUB_R15 = -14
};
#else // assume 32bit
enum {
    HOOK_STUB_EAX = -1,
    HOOK_STUB_ECX = -2,
    HOOK_STUB_EDX = -3,
    HOOK_STUB_EBX = -4,
    HOOK_STUB_ESI = -5,
    HOOK_STUB_EDI = -6
};
#endif

/*!
 * \brief Prototype of prolog hook.
 * \param target_name Name of target function
 * \param module_name Name of module containing target function definition
 * \param cfa Canonical frame address
 * \param reg General register address
 * \param arg Argument of epilog hook.
 * \note It's possible to access the argument of target function via \a cfa
 * and/or \a reg.
 * e.g, cfa[0] should be the first argument of target function in IA32.
 * reg[HOOK_STUB_RDI] should be the first argument of target function in x86-64.
 */
typedef void (*PrologRoutine)(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, void *arg);

/*!
 * \brief Prototype of epilog hook.
 * \param target_name Name of target function
 * \param module_name Name of module containing target function definition
 * \param cfa Canonical frame address
 * \param reg General register address
 * \param ret Flag if target function returns normally
 * \param arg Argument of epilog hook.
 * \note Only if \a ret is non-zero, \a cfa and \a reg are valid.
 */
typedef void (*EpilogRoutine)(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, int ret, void *arg);

/*! Get the address of function of exe. */
void *exeGetFunction(const char *name);

/*!
 * \brief Register prolog hook and epilog hook for target function of EXE.
 * \param target_name Name of target function
 * \param hacked_code_size How many target codes should be hacked.
 * \param prolog_routine Prolog routine called at the entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at the exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successfunl completion, It shall return 0.
 * \note If \a hacked_code_size is zero, the target function is hacked iff it
 * matches preset code pattern. Otherwise, the code pattern check is ignored.
 */
int exeRegisterHook(const char *target_name, size_t hacked_code_size,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*!
 * \brief Register prolog hook and epilog hook for target function of SO.
 * \param target_name Name of target function
 * \param hacked_code_size How many target codes should be hacked.
 * \param module_name Path name of shared library defining the target function
 * \param prolog_routine Prolog routine called at the entry of target function.
 * \param prolog_arg Argument of prolog routine.
 * \param epilog_routine Epilog routine called at the exit of target function.
 * \param epilog_arg Argument of epilog routine.
 * \return Upon successfunl completion, It shall return 0. If the return value
 * is greatern than 0, It means that the target function is in pending state,
 * i.e., It may be resolvable if loading more shared libraries in the future.
 */
int soRegisterHook(const char *target_name, size_t hacked_code_size,
        const char *module_name,
        PrologRoutine prolog_routine, void *prolog_arg,
        EpilogRoutine epilog_routine, void *epilog_arg);

/*! \brief API sets of hook stub */
typedef struct HookStub {
    void *(*exeGetFunction)(const char *name);

    int (*exeRegisterHook)(const char *target_name, size_t hacked_code_size,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);

    int (*soRegisterHook)(const char *target_name, size_t hacked_code_size,
            const char *module_name,
            PrologRoutine prolog_routine, void *prolog_arg,
            EpilogRoutine epilog_routine, void *epilog_arg);
} HookStub;

#ifdef __cplusplus
}
#endif

#endif

