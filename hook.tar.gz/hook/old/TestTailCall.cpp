#include <stdio.h>

extern "C" int even_self_tail_call(unsigned v) {
    fprintf(stderr, "even_self_tail_call(%u)\n", v);
    if (0 == v) {
        return 1;
    }
    if (1 == v) {
        return 0;
    }
    return even_self_tail_call(v - 2);
}

extern "C" int even(unsigned v) {
    fprintf(stderr, "even(%u)\n", v);
    return even_self_tail_call(v);
}

int main(int argc, char *argv[]) {
    even_self_tail_call(4);
    even(4);
    return 0;
}

