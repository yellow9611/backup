#include <unistd.h>
#include <limits.h>
#include <stdio.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct MemoryUsage {
    unsigned long size; // VmSize
    unsigned long resident; // VmRSS
    unsigned long shared;
    unsigned long trs; // VmExe
    unsigned long lrs;
    unsigned long drs; // VmData + VmStk
    unsigned long dt;
};

struct Target {
    string function;
    string module;
    size_t size;
    Target(const string &f, const string &m, size_t s)
        : function(f), module(m), size(s) {
    }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

void showMemoryUsage(const Target *target, const char *stage) {
    MemoryUsage mu;
    char statm[PATH_MAX + 1];
    sprintf(statm, "/proc/%u/statm", getpid());
    ifstream file(statm);
    file >> mu.size >> mu.resident >> mu.shared >> mu.trs
        >> mu.lrs >> mu.drs >> mu.dt;

    long page_size = sysconf(_SC_PAGE_SIZE) / 1024;
    fprintf(stderr, "libmemoryprofiler<%u, %u>: %s: %s: %s "
            "{ VmSize = %luKB, VmRSS = %luKB, VmData + VmStk = %luKB, VmExe = %luKB }\n",
            getpid(), getppid(),
            stage, target->function.c_str(), target->module.c_str(),
            mu.size * page_size, mu.resident * page_size,
            mu.drs * page_size, mu.trs * page_size);
}

void memoryProlog(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    showMemoryUsage(target, "enter");
}

void memoryEpilog(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, int ret, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    showMemoryUsage(target, "leave");
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);
    while (1) {
        string function;
        string module;
        size_t size;
        ifs >> function >> module >> size;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module, size));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(), target.size,
                    memoryProlog, &target,
                    memoryEpilog, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(), target.size,
                    target.module.c_str(),
                    memoryProlog, &target,
                    memoryEpilog, &target);
        }
    }

    return 0;
}

void hookLibFini() {
}

