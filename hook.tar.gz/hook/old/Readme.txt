1 Terminology
* Canonical Frame Address
    Once function call happens, callee saves caller's ebp on the stack,
    setup its own ebp, optionally saves registers ebx/esi/edi (callee-saved
    registers) on the stack, then subtracts esp and reserves space on the stack
    for its local usage (local variable, etc). At this point, [esp, ebp)
    identify the frame of callee. We name esp as CFA.

    ebp[0] is the caller's ebp
    ebp[4] is the callee's return address
    ebp + 8 is the caller's esp, i.e., caller's CFA.
    So, from the point view of callee, [ebp + 8, ebp[0]) identify the frame of
    caller.
    
* Target Function
    Any function you are interested in and wanna to hook. Its code may reside
    in exe or so.


2 Motivation
* Different requirements of monitoring program, such as how many times
target function is called, what's the memory statistics at the entry and
exit of each target function call, how much real/user/system time elapsed
during the period of target function call.
* Sometimes, we don't wanna write any hook code and compile them into 
program. Sometimes, we have only binary program.

    
3 Framework
* Hook Library
Users can write many different hook libraries, such as memory profiler or time
profiler. However, each hook library shall be shared library that must implement
2 APIs:
extern "C" int hookLibInit(const HookStub *hook_stub, const char *config_file);
extern "C" void hookLibFini(void)
The format of configuration file of hook library is up to the implementator of
hook library.
In most cases, the configuration file of hook library specifies the name of
target function. So, hook library can register prolog and/or epilog hook for
target functions when hookLibInit is called.

Each hook library should also implement a third API.
extern "C" void hookLibAtFork(void)


* Hook Stub
It's a shared library that can be forced to load into process's space via
environ LD_PRELOAD.

Once hook stub is loaded into process's space, It starts parsing its
configuration file, whose default path name is "./hookstub.cfg" and can be
overriden by environ HOOK_STUB_CONFIG_FILE.

The format of configuration file:
path name of program 1
path name of hook library a
path name of configuration file of hook library a
path name of hook library b
path name of configuration file of hook library b
/
.................................................
path name of program 2
path name of hook library c
path name of configuration file of hook library c
path name of hook library d
path name of configuration file of hook library d
/
.................................................

Then hook stub checks if the image file of current process appears in its
configuration file. If NO, hook stub does nothing any longer effectively.
Otherwsie, it loads each designated hook library into current process space
and calls API "hookLibInit" of each hook library, passing HookStub object and
path name of configuration file of hook library.

When process terminates, for each successfully initialized hook library, hook
stub calls API "hookLibFini".

When process forks a child process, hook stub and hook library
also reside in child process's space. If hook library implements
"hookLibAtFork", hook stub will call this API in child process. At this point,
hook library can re-initialize its global data for child process.

* Hook Grind
It's just a wrapper for easy use of hook stub.

4 Hook Stub Implementation
Key Points:
* Inject a jump instruction (5 byte) at the begining of target function.
The jump destination is "prolog thunk" which is responsible for saving
original return address of target function, calling each registered prolog hook,
and setting "epilog thunk" as the return address of target function.

* Epilog Thunk: When target function returns, epilog thunk takes over the
control, calls each registered epilog hook, restores the orignal return address
of target function, and transfer the control to the REAL caller of target function
or epilog thunk again.

5 Examples
* libcallcount.so
A simple profiler calculating how many times target function is called.

* libtimeprofiler.so
A simple profiler calculating how much real/user/system time elapsed during
target function call.

* libmemoryprofiler.so
A simple profiler showing the memory statistics at the entry/exit of target
function call.

* libsnpsmemoryprofiler.so
A simple profiler showing SNPS memory group size.

*libmainmonitor.so
A simple profiler monitoring the argument and return value of main routine.
