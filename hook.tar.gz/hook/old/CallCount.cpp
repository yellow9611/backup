#include <unistd.h>
#include <stdio.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct Target {
    string function;
    string module;
    size_t size;
    int count;
    Target(const string &f, const string &m, size_t s)
        : function(f), module(m), size(s), count(0) {
    }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

void epilogCallCount(const char *name, const char *module,
        const void *cfa, const void *reg, int ret, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    ++target->count;
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);
    while (1) {
        string function;
        string module;
        size_t size;
        ifs >> function >> module >> size;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module, size));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(), target.size,
                    0, 0, epilogCallCount, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(), target.size,
                    target.module.c_str(), 0, 0, epilogCallCount, &target);
        }
    }

    return 0;
}

void hookLibFini() {
    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        fprintf(stderr, "libcallcount<%u, %u>: %s: %s: %d\n",
                getpid(), getppid(),
                iter->function.c_str(), iter->module.c_str(), iter->count);
    }
}

void hookLibAtFork() {
    fprintf(stderr, "libcallcount<%u, %u>: hookLibAtFork\n",
            getpid(), getppid());
}

