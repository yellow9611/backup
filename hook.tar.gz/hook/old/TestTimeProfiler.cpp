#include <stdlib.h>

extern "C" int foo(int depth) {
    if (depth <= 1) {
        long sum = 0;
        int i;
        int j;
        for (i = 0; i < 0x7FFFFFFF; ++i) {
            for (j = 0; j < 2; ++j) {
                sum = i + j;
            }
        }
        return sum;
    }
    return foo(depth - 1) + 1; // disable tail call
}

int main(int argc, char *argv[]) {
    foo(3);
    return 0;
}

