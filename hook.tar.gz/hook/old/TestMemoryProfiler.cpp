#include <stdlib.h>

extern "C" void* foo(void) {
    void *p;
    p = malloc(10 * 1024 * 1024);
    return p;
}

extern "C" void *bar(void) {
    void *p;
    p = malloc(10 * 1024 * 1024);
    return p;
}

int main(int argc, char *argv[]) {
    void *p = foo();
    void *q = bar();
    free(p);
    free(q);
    return 0;
}

