#include <unistd.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <stdio.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct TimeUsage {
    struct timeval rtime; // real time
    struct timeval utime; // user time
    struct timeval stime; // sys time
};

struct Target {
    string function;
    string module;
    size_t size;
    TimeUsage total;
    TimeUsage begin;
    unsigned level;
    Target(const string &f, const string &m, size_t s)
        : function(f), module(m), size(s), level(0) {
        timerclear(&total.rtime);
        timerclear(&total.utime);
        timerclear(&total.stime);
    }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

void getTimeUsage(TimeUsage *tu) {
    gettimeofday(&tu->rtime, 0);
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    tu->utime = ru.ru_utime;
    tu->stime = ru.ru_stime;
}

void timeProlog(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    ++target->level;
    if (1 == target->level) { // outermost
        getTimeUsage(&target->begin);
    }
}

void timeEpilog(const char *target_name, const char *module_name,
        const void *cfa, const void *reg, int ret, void *arg) {
    Target *target = reinterpret_cast<Target *>(arg);
    if (1 == target->level) { // outermost
        TimeUsage end;
        getTimeUsage(&end);
        TimeUsage &begin = target->begin;

        // accumulate time
        struct timeval diff;
        timersub(&end.rtime, &begin.rtime, &diff);
        timeradd(&diff, &target->total.rtime, &target->total.rtime);

        timersub(&end.utime, &begin.utime, &diff);
        timeradd(&diff, &target->total.utime, &target->total.utime);

        timersub(&end.stime, &begin.stime, &diff);
        timeradd(&diff, &target->total.stime, &target->total.stime);
    }
    --target->level;
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);

    while (1) {
        string function;
        string module;
        size_t size;
        ifs >> function >> module >> size;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module, size));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(), target.size,
                    timeProlog, &target,
                    timeEpilog, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(), target.size,
                    target.module.c_str(),
                    timeProlog, &target,
                    timeEpilog, &target);
        }
    }

    return 0;
}

void hookLibFini() {
    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    double scale = 1E6;
    for (TargetIterator iter = first; iter != last; ++iter) {
        fprintf(stderr, "libtimeprofiler<%u, %u>: %s: %s: "
                "{ real time = %.2fs, user time = %.2fs, sys time = %.2fs }\n",
                getpid(), getppid(),
                iter->function.c_str(), iter->module.c_str(),
                iter->total.rtime.tv_sec + iter->total.rtime.tv_usec / scale,
                iter->total.utime.tv_sec + iter->total.utime.tv_usec / scale,
                iter->total.stime.tv_sec + iter->total.stime.tv_usec / scale);
    }
}

