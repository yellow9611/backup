#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <list>
#include <fstream>
#include "HookLib.h"

using namespace std;

struct Target {
    string function;
    string module;
    size_t size;
    Target(const string &f, const string &m, size_t s)
        : function(f), module(m), size(s) {
    }
};

typedef list<Target> TargetList;
typedef TargetList::iterator TargetIterator;

TargetList g_target_list;

void epilogMainMonitor(const char *name, const char *module,
        const void *cfa, const void *reg, int ret, void *arg) {
    if (!ret) {
        return;
    }
    Target *target = reinterpret_cast<Target *>(arg);
    assert(strcmp(name, "main") == 0);
    const size_t *p = reinterpret_cast<const size_t *>(cfa);
    const size_t *q = reinterpret_cast<const size_t *>(reg);
    int argc = p[0];
    char **argv = reinterpret_cast<char **>(p[1]);

    fprintf(stderr, "libmainmonitor: main: argc = %d\n", argc);
    for (int i = 0; i < argc; ++i) {
        fprintf(stderr, "argv[%d] = %s\n", i, argv[i]);
    }

    int rv = q[HOOK_STUB_EAX];
    fprintf(stderr, "return value = %d\n", rv); 
}

int hookLibInit(const HookStub *hook_stub, const char *config_file) {
    ifstream ifs(config_file);
    while (1) {
        string function;
        string module;
        size_t size;
        ifs >> function >> module >> size;
        if (function.empty() || module.empty()) {
            break;
        }
        g_target_list.push_back(Target(function, module, size));
    }

    TargetIterator first = g_target_list.begin();
    TargetIterator last = g_target_list.end();

    for (TargetIterator iter = first; iter != last; ++iter) {
        Target &target = *iter;
        if (target.module == "*") {
            hook_stub->exeRegisterHook(target.function.c_str(), target.size,
                    0, 0, epilogMainMonitor, &target);
        } else {
            hook_stub->soRegisterHook(target.function.c_str(), target.size,
                    target.module.c_str(), 0, 0, epilogMainMonitor, &target);
        }
    }

    return 0;
}

void hookLibFini() {
}

