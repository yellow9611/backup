/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericList
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Double list whose element shall be copyable.
 */

/** @example test_generic_list.c */

#if !defined(GENERIC_LIST_H)
#define GENERIC_LIST_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_list_iterator_t generic_list_iterator_t;
typedef struct generic_list_iterator_api_t generic_list_iterator_api_t;
typedef struct generic_list_t generic_list_t;
typedef struct generic_list_api_t generic_list_api_t;
typedef struct generic_list_item_t generic_list_item_t;

/** @brief Get API of generic list iterator. */
const generic_list_iterator_api_t *generic_list_iterator_api(void);

/** @brief Get API of generic list. */
const generic_list_api_t *generic_list_api(void);

struct generic_list_item_t {
    generic_list_item_t *next;
    generic_list_item_t *prev;
    char data[1];
};

/** @brief API of generic list iterator. */
struct generic_list_iterator_api_t {
    void (*next)(generic_list_iterator_t *);
    void (*prev)(generic_list_iterator_t *);
    void (*move)(generic_list_iterator_t *, ptrdiff_t); /* 0 */
    void *(*deref)(generic_list_iterator_t *);
    int (*equal)(const generic_list_iterator_t *,
            const generic_list_iterator_t *);
    ptrdiff_t (*sub)(const generic_list_iterator_t *,
            const generic_list_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic list iterator.
 * @attention Only member @a api is public.
 */
struct generic_list_iterator_t {
    const generic_list_iterator_api_t *api;
    const generic_list_t *gl;
    generic_list_item_t *item;
};

/** @brief API of generic list. */
struct generic_list_api_t {
    /**
     * @brief Construct one empty list.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_list_t *,
        generic_memory_manager_t *, const generic_data_manager_t *);
    /** @brief Destruct the list. */
    void (*destruct)(generic_list_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_list_t *);

    /** @brief Test if list is empty or not. */
    int (*empty)(const generic_list_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_list_iterator_t (*begin)(generic_list_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_list_iterator_t (*end)(generic_list_t *);

    /** @brief Get the address of the first element. */
    void *(*front)(generic_list_t *);

    /** @brief Get the address of the last element. */
    void *(*back)(generic_list_t *);

    /**
     * @brief Insert one element before the position designated by @a iter.
     * @return Upon successful completion, It shall return the iterator that
     * points to the new element. Otherwise, It shall be the end of list.
     */
    generic_list_iterator_t (*insert)(generic_list_t *,
            const generic_list_iterator_t *iter, const void *);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_list_iterator_t (*erase)(generic_list_t *,
            const generic_list_iterator_t *iter);

    /**
     * @brief Insert one element at the front.
     * @return Upon successful completion, It shall return 0.
     */
    int (*push_front)(generic_list_t *, const void *);

    /** @brief Erase the first element. */
    void (*pop_front)(generic_list_t *);

    /**
     * @brief Insert one element at the back.
     * @return Upon successful completion, It shall return 0.
     */
    int (*push_back)(generic_list_t *, const void *);

    /** @brief Erase the last element. */
    void (*pop_back)(generic_list_t *);

    /** @brief Erase all elements. */
    void (*clear)(generic_list_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_list_t *);

    /** @brief Get data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_list_t *);
};

/**
 * @brief Representation of generic list.
 * @attention All members are private.
 */
struct generic_list_t {
    generic_memory_manager_t *gmm;
    const generic_data_manager_t *gdm;
    generic_list_item_t sentry; /* before head, after tail. */
    size_t item_count;
    size_t item_size; /* item size in bytes */
    size_t data_offset; /* client data offset relative to item->data */
};

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_LIST_H */

/** @} */

