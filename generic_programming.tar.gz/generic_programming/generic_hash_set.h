/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericHashSet
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Hash set and hash multiset.
 * @details Element shall be copyable.
 * Equality test shall be applicable to element.
 * Elemenst of the container are unordered.
 */

/** @example test_generic_hash_set.c */

#if !defined(GENERIC_HASH_SET_H)
#define GENERIC_HASH_SET_H

#include <stddef.h>
#include "generic_utility.h"
#include "generic_hash_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_hash_set_api_t generic_hash_set_api_t;
typedef struct generic_hash_set_t generic_hash_set_t;
typedef struct generic_hash_set_iterator_t generic_hash_set_iterator_t;
typedef struct generic_hash_set_iterator_api_t generic_hash_set_iterator_api_t;
typedef struct generic_hash_set_local_iterator_t generic_hash_set_local_iterator_t;
typedef struct generic_hash_set_local_iterator_api_t generic_hash_set_local_iterator_api_t;

/** @brief Get API of generic hash set iterator. */
const generic_hash_set_iterator_api_t *generic_hash_set_iterator_api(void);

/** @brief Get API of generic hash set local iterator. */
const generic_hash_set_local_iterator_api_t *generic_hash_set_local_iterator_api(void);

/** @brief Get API of generic hash set. */
const generic_hash_set_api_t *generic_hash_set_api(void);

/** @brief API of generic hash set iterator. */
struct generic_hash_set_iterator_api_t {
    void (*next)(generic_hash_set_iterator_t *);
    void (*prev)(generic_hash_set_iterator_t *); /* 0 */
    void (*move)(generic_hash_set_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_hash_set_iterator_t *);
    int (*equal)(const generic_hash_set_iterator_t *,
            const generic_hash_set_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_set_iterator_t *,
            const generic_hash_set_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash set iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_set_iterator_t {
    const generic_hash_set_iterator_api_t *api;
    generic_hash_table_iterator_t imp;
};

/** @brief API of generic hash set local iterator. */
struct generic_hash_set_local_iterator_api_t {
    void (*next)(generic_hash_set_local_iterator_t *);
    void (*prev)(generic_hash_set_local_iterator_t *); /* 0 */
    void (*move)(generic_hash_set_local_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_hash_set_local_iterator_t *);
    int (*equal)(const generic_hash_set_local_iterator_t *,
            const generic_hash_set_local_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_set_local_iterator_t *,
            const generic_hash_set_local_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash set local iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_set_local_iterator_t {
    const generic_hash_set_local_iterator_api_t *api;
    generic_hash_table_local_iterator_t imp;
};

/**
 * @brief API of generic hash set.
 * @attention If rehash happens because of high load factor,
 * any previous iterator or local iterator shall be invalid.
 * @attention Multiple elements that are equal are not allowed.
 */
struct generic_hash_set_api_t {
    /**
     * @brief Construct one empty hash set.
     * @return Upon successful completion, It shall return 0.
     * @param bucket_hint Estimated required bucket count.
     */
    int (*construct)(generic_hash_set_t *, size_t bucket_hint,
            generic_memory_manager_t *, const generic_data_manager_t *,
            generic_hash_fp_t);

    /** @brief Destruct the hash set. */
    void (*destruct)(generic_hash_set_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_hash_set_t *);

    /** @brief Test if hash set is empty or not. */
    int (*empty)(const generic_hash_set_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_hash_set_iterator_t (*begin)(generic_hash_set_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_hash_set_iterator_t (*end)(generic_hash_set_t *);

    /**
     * @brief Find the element that is equal to @a elem.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of hash set.
     */
    generic_hash_set_iterator_t (*find)(generic_hash_set_t *,
            const void *elem);

    /** @brief Get the number of elements that are equal to @a elem. */
    size_t (*count)(const generic_hash_set_t *, const void *elem);

    /**
     * @brief Get the range of elements that are equal to @a elem.
     * @param[out] begin Points to the first element equal to @a elem.
     * @param[out] end Points after the last element equal to @a elem.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_hash_set_t *, const void *elem,
            generic_hash_set_iterator_t *, generic_hash_set_iterator_t *);

    /** @brief Get the local iterator that points to first element of @a bucket. */
    generic_hash_set_local_iterator_t (*local_begin)(generic_hash_set_t *,
            size_t bucket);

    /** @brief Get the local iterator that points after last element of @a bucket. */
    generic_hash_set_local_iterator_t (*local_end)(generic_hash_set_t *,
            size_t bucket);

    /** @brief Get the number of buckets. */
    size_t (*bucket_count)(const generic_hash_set_t *);

    /** @brief Get the number of elements in @a bucket. */
    size_t (*bucket_size)(const generic_hash_set_t *, size_t bucket);

    /** @brief Get the bucket that @a elem maps to. */
    size_t (*bucket)(const generic_hash_set_t *, const void *elem);

    /** @brief Get load factor. */
    float (*load_factor)(const generic_hash_set_t *);

    /** @brief Get max load factor. */
    float (*get_max_load_factor)(const generic_hash_set_t *);

    /**
     * @brief Set max load factor.
     * @return Upon successful completion, It shall return 0.
     * @attention It may cause rehash.
     */
    int (*set_max_load_factor)(generic_hash_set_t *, float);

    /**
     * @brief Insert one element @a elem.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of hash set.
     * @attention It may cause rehash.
     */
    generic_hash_set_iterator_t (*insert)(generic_hash_set_t *,
            const void *elem);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_hash_set_iterator_t (*erase)(generic_hash_set_t *,
            const generic_hash_set_iterator_t *iter);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the local iterator that points after
     * the erased element.
     */
    generic_hash_set_local_iterator_t (*lerase)(generic_hash_set_t *,
            const generic_hash_set_local_iterator_t *iter);

    /**
     * @brief Erase all elements that are equal to @a elem.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_hash_set_t *, const void *elem);

    /** @brief Erase all elements. */
    void (*clear)(generic_hash_set_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_hash_set_t *);

    /** @brief Get data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_hash_set_t *);

    /** @brief Get hash function. */
    generic_hash_fp_t (*hash)(const generic_hash_set_t *);
};

/**
 * @brief Representation of hash set.
 * @attention All members are private.
 */
struct generic_hash_set_t {
    generic_hash_table_t imp;
};

typedef struct generic_hash_multiset_api_t generic_hash_multiset_api_t;
typedef struct generic_hash_multiset_t generic_hash_multiset_t;
typedef struct generic_hash_multiset_iterator_t generic_hash_multiset_iterator_t;
typedef struct generic_hash_multiset_iterator_api_t generic_hash_multiset_iterator_api_t;
typedef struct generic_hash_multiset_local_iterator_t generic_hash_multiset_local_iterator_t;
typedef struct generic_hash_multiset_local_iterator_api_t generic_hash_multiset_local_iterator_api_t;

/** @brief Get API of generic hash multiset iterator. */
const generic_hash_multiset_iterator_api_t *generic_hash_multiset_iterator_api(void);

/** @brief Get API of generic hash multiset local iterator. */
const generic_hash_multiset_local_iterator_api_t *generic_hash_multiset_local_iterator_api(void);

/** @brief Get API of generic hash multiset. */
const generic_hash_multiset_api_t *generic_hash_multiset_api(void);

/** @brief API of generic hash multiset iterator. */
struct generic_hash_multiset_iterator_api_t {
    void (*next)(generic_hash_multiset_iterator_t *);
    void (*prev)(generic_hash_multiset_iterator_t *); /* 0 */
    void (*move)(generic_hash_multiset_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_hash_multiset_iterator_t *);
    int (*equal)(const generic_hash_multiset_iterator_t *,
            const generic_hash_multiset_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_multiset_iterator_t *,
            const generic_hash_multiset_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash multiset iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_multiset_iterator_t {
    const generic_hash_multiset_iterator_api_t *api;
    generic_hash_table_iterator_t imp;
};

/** @brief API of generic hash multiset local iterator. */
struct generic_hash_multiset_local_iterator_api_t {
    void (*next)(generic_hash_multiset_local_iterator_t *);
    void (*prev)(generic_hash_multiset_local_iterator_t *); /* 0 */
    void (*move)(generic_hash_multiset_local_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_hash_multiset_local_iterator_t *);
    int (*equal)(const generic_hash_multiset_local_iterator_t *,
            const generic_hash_multiset_local_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_multiset_local_iterator_t *,
            const generic_hash_multiset_local_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash multiset local iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_multiset_local_iterator_t {
    const generic_hash_multiset_local_iterator_api_t *api;
    generic_hash_table_local_iterator_t imp;
};

/**
 * @brief API of generic hash multiset.
 * @attention If rehash happens because of high load factor,
 * any previous iterator or local iterator shall be invalid.
 * @attention Multiple elements that are equal are allowed.
 */
struct generic_hash_multiset_api_t {
    /**
     * @brief Construct one empty hash multiset.
     * @return Upon successful completion, It shall return 0.
     * @param bucket_hint Estimated required bucket count.
     */
    int (*construct)(generic_hash_multiset_t *, size_t bucket_hint,
            generic_memory_manager_t *,
            const generic_data_manager_t *, generic_hash_fp_t);

    /** @brief Destruct the hash multiset. */
    void (*destruct)(generic_hash_multiset_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_hash_multiset_t *);
    
    /** @brief Test if hash multiset is empty or not. */
    int (*empty)(const generic_hash_multiset_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_hash_multiset_iterator_t (*begin)(generic_hash_multiset_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_hash_multiset_iterator_t (*end)(generic_hash_multiset_t *);

    /**
     * @brief Find the element that is equal to @a elem.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of hash multiset.
     */
    generic_hash_multiset_iterator_t (*find)(generic_hash_multiset_t *,
            const void *elem);

    /** @brief Get the number of elements that are equal to @a elem. */
    size_t (*count)(const generic_hash_multiset_t *, const void *elem);

    /**
     * @brief Get the range of elements that are equal to @a elem.
     * @param[out] begin Points to the first element equal to @a elem.
     * @param[out] end Points after the last element equal to @a elem.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_hash_multiset_t *, const void *elem,
            generic_hash_multiset_iterator_t *begin,
            generic_hash_multiset_iterator_t *end);

    /** @brief Get the local iterator that points to first element of @a bucket. */
    generic_hash_multiset_local_iterator_t (*local_begin)(generic_hash_multiset_t *,
            size_t bucket);

    /** @brief Get the local iterator that points after last element of @a bucket. */
    generic_hash_multiset_local_iterator_t (*local_end)(generic_hash_multiset_t *,
            size_t bucket);

    /** @brief Get the number of buckets. */
    size_t (*bucket_count)(const generic_hash_multiset_t *);

    /** @brief Get the number of elements in @a bucket. */
    size_t (*bucket_size)(const generic_hash_multiset_t *, size_t bucket);

    /** @brief Get the bucket that @a elem maps to. */
    size_t (*bucket)(const generic_hash_multiset_t *, const void *elem);

    /** @brief Get load factor. */
    float (*load_factor)(const generic_hash_multiset_t *);

    /** @brief Get max load factor. */
    float (*get_max_load_factor)(const generic_hash_multiset_t *);

    /**
     * @brief Set max load factor.
     * @return Upon successful completion, It shall return 0.
     * @attention It may cause rehash.
     */
    int (*set_max_load_factor)(generic_hash_multiset_t *, float);

    /**
     * @brief Insert one element @a elem.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of hash multiset.
     * @attention It may cause rehash.
     */
    generic_hash_multiset_iterator_t (*insert)(generic_hash_multiset_t *,
            const void *elem);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_hash_multiset_iterator_t (*erase)(generic_hash_multiset_t *,
            const generic_hash_multiset_iterator_t *iter);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the local iterator that points after
     * the erased element.
     */
    generic_hash_multiset_local_iterator_t (*lerase)(generic_hash_multiset_t *,
            const generic_hash_multiset_local_iterator_t *iter);

    /**
     * @brief Erase all elements that are equal to @a elem.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_hash_multiset_t *, const void *elem);

    /** @brief Erase all elements. */
    void (*clear)(generic_hash_multiset_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_hash_multiset_t *);

    /** @brief Get data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_hash_multiset_t *);

    /** @brief Get hash function. */
    generic_hash_fp_t (*hash)(const generic_hash_multiset_t *);
};

/**
 * @brief Representation of hash multiset.
 * @attention All members are private.
 */
struct generic_hash_multiset_t {
    generic_hash_table_t imp;
};

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_HASH_SET_H */

/** @} */

