/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericString
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief String without sharing.
 */

/** @example test_generic_string.c */

#if !defined(GENERIC_STRING_H)
#define GENERIC_STRING_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef generic_pointer_iterator_t generic_string_iterator_t;
typedef generic_pointer_iterator_api_t generic_string_iterator_api_t;
typedef struct generic_string_t generic_string_t;
typedef struct generic_string_api_t generic_string_api_t;

/** @brief Get API of generic string iterator. */
const generic_string_iterator_api_t *generic_string_iterator_api(void);

/** @brief Get API of generic string. */
const generic_string_api_t *generic_string_api(void);

/** @brief API of generic string. */
struct generic_string_api_t {
    /**
     * @brief Construct one empty string.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_string_t *, generic_memory_manager_t *);

    /** @brief Destruct the string. */
    void (*destruct)(generic_string_t *);

    /** @brief Get the string length. */
    size_t (*size)(const generic_string_t *);

    /** @brief Get the string length. */
    size_t (*length)(const generic_string_t *);

    /** @brief Test if the string is empty or not. */
    int (*empty)(const generic_string_t *);

    /** @brief Get the iterator that points to the first character. */
    generic_string_iterator_t (*begin)(generic_string_t *);

    /** @brief Get the iterator that points after the last character. */
    generic_string_iterator_t (*end)(generic_string_t *);

    /** @brief Get the first character. */
    char (*front)(const generic_string_t *);

    /** @brief Get the last character. */
    char (*back)(const generic_string_t *);

    /** @brief Get the raw character sequence. */
    const char *(*data)(const generic_string_t *);

    /** @brief Get the raw c-style string. */
    const char *(*c_str)(const generic_string_t *);

    /** @brief Get the nth character. */
    char (*get)(const generic_string_t *, size_t);

    /** @brief Set the nth character. */
    void (*set)(generic_string_t *, size_t, char); 

    /**
     * @brief Reserve enough memory to be able to hold @a n characters
     * @return Upon successful completion, It shall return 0.
     */
    int (*reserve)(generic_string_t *, size_t n);

    /**
     * @brief Insert one character at the back.
     * @return Upon successful completion, It shall return 0.
     */
    int (*push_back)(generic_string_t *, char);

    /** @brief Erase the last character. */
    void (*pop_back)(generic_string_t *);

    /** @brief Erase all characters. */
    void (*clear)(generic_string_t *);

    /**
     * @brief Append operation.
     * @param size Data size in bytes.
     * @return Upon successful completion, It shall return 0.
     */
    int (*append_data)(generic_string_t *, const void *, size_t size);

    /**
     * @brief Append operation.
     * @return Upon successful completion, It shall return 0.
     */
    int (*append_gstr)(generic_string_t *, const generic_string_t *);

    /**
     * @brief Append operation.
     * @return Upon successful completion, It shall return 0.
     */
    int (*append_cstr)(generic_string_t *, const char *);

    /**
     * @brief Append a number of characters.
     * @return Upon successful completion, It shall return 0.
     */
    int (*append_char)(generic_string_t *, size_t, char);

    /**
     * @brief Assign operation.
     * @param size Data size in bytes.
     * @return Upon successful completion, It shall return 0.
     */
    int (*assign_data)(generic_string_t *, const void *, size_t size);

    /**
     * @brief Assign operation.
     * @return Upon successful completion, It shall return 0.
     */
    int (*assign_gstr)(generic_string_t *, const generic_string_t *);

    /**
     * @brief Assign operation.
     * @return Upon successful completion, It shall return 0.
     */
    int (*assign_cstr)(generic_string_t *, const char *);

    /** @brief Get the memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_string_t *);
};

/**
 * @brief Representation of generic string.
 * @attention All members are private.
 */
struct generic_string_t {
    generic_memory_manager_t *gmm;
    char *data;
    size_t size;
    size_t capacity;
};

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_STRING_H */

/** @} */

