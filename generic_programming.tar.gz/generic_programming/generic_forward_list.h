/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericForwardList
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Single list whose element shall be copyable.
 */

/** @example test_generic_forward_list.c */

#if !defined(GENERIC_FORWARD_LIST_H)
#define GENERIC_FORWARD_LIST_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_forward_list_iterator_api_t generic_forward_list_iterator_api_t;
typedef struct generic_forward_list_api_t generic_forward_list_api_t;
typedef struct generic_forward_list_iterator_t generic_forward_list_iterator_t;
typedef struct generic_forward_list_t generic_forward_list_t;
typedef struct generic_forward_list_item_t generic_forward_list_item_t;

/** @brief Get API of generic forward list iterator. */
const generic_forward_list_iterator_api_t *generic_forward_list_iterator_api(void);

/** @brief Get API of generic forward list. */
const generic_forward_list_api_t *generic_forward_list_api(void);

struct generic_forward_list_item_t {
    generic_forward_list_item_t *next;
    char data[1];
};

/** @brief API of generic forward list iterator. */
struct generic_forward_list_iterator_api_t {
    void (*next)(generic_forward_list_iterator_t *);
    void (*prev)(generic_forward_list_iterator_t *); /* 0 */
    void (*move)(generic_forward_list_iterator_t *, ptrdiff_t); /* 0 */
    void *(*deref)(generic_forward_list_iterator_t *);
    int (*equal)(const generic_forward_list_iterator_t *,
            const generic_forward_list_iterator_t *);
    ptrdiff_t (*sub)(const generic_forward_list_iterator_t *,
            const generic_forward_list_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic forward list iterator.
 * @attention Only member @a api is public.
 */
struct generic_forward_list_iterator_t {
    const generic_forward_list_iterator_api_t *api;
    const generic_forward_list_t *gfl;
    generic_forward_list_item_t *item;
};

/** @brief API of generic forward list. */
struct generic_forward_list_api_t {
    /**
     * @brief Construct one empty forward list.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_forward_list_t *,
        generic_memory_manager_t *, const generic_data_manager_t *);

    /** @brief Destruct the forward list. */
    void (*destruct)(generic_forward_list_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_forward_list_t *);

    /** @brief Test if forward list is empty or not. */
    int (*empty)(const generic_forward_list_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_forward_list_iterator_t (*begin)(generic_forward_list_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_forward_list_iterator_t (*end)(generic_forward_list_t *);

    /** @brief Get the iterator that points before the first element. */
    generic_forward_list_iterator_t (*before_begin)(generic_forward_list_t *);

    /** @brief Get the address of the first element. */
    void *(*front)(generic_forward_list_t *);

    /**
     * @brief Insert one element after the position @a iter.
     * @return Upon successful completion, It shall return the iterator that
     * points to the new element. Otherwise, It shall be the end of forward
     * list.
     */
    generic_forward_list_iterator_t (*insert_after)(generic_forward_list_t *,
            const generic_forward_list_iterator_t *iter, const void *);

    /**
     * @brief Erase the element after the position @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_forward_list_iterator_t (*erase_after)(generic_forward_list_t *,
            const generic_forward_list_iterator_t *iter);

    /**
     * @brief Insert one element at the front.
     * @return Upon successful completion, It shall return 0.
     */
    int (*push_front)(generic_forward_list_t *, const void *);

    /** @brief Erase the first element. */
    void (*pop_front)(generic_forward_list_t *);

    /** @brief Erase all elements. */
    void (*clear)(generic_forward_list_t *);

    /** @brief Get the memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_forward_list_t *);

    /** @brief Get the data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_forward_list_t *);
};

/**
 * @brief Representation of generic forward list.
 * @attention All members are private.
 */
struct generic_forward_list_t {
    generic_memory_manager_t *gmm;
    const generic_data_manager_t *gdm;
    generic_forward_list_item_t sentry; /* before head, after tail. */
    size_t item_count;
    size_t item_size; /* each item size in bytes */
    size_t data_offset; /* client data offset relative to item->data */
};

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_FORWARD_LIST_H */

/** @} */

