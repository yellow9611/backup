C Gerneric Programming
yellow9611@gmail.com

1 Disclaimer
This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

2 License
  Permission is granted to anyone to use this library for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, without any restriction.

3. Assumption
Please see generic_config.h and generic_config.c

4. Recommendation
4.1 Do NOT use iterator as polymorphic object.
generic_iterator_t::api is intended to implement generic algorithm.
4.2 Do NOT use predicator/actor as polymorphic object.
They are intended to implement generic algorithm.
4.3 Do NOT use any container as polymorphic object.

5. Status
utility DONE
vector  DONE
deque ...
forward list DONE
list DONE
hash map DONE
hash multimap DONE
hash set DONE
hash multiset DONE
tree map DONE
tree multimap DONE
tree set DONE
tree multiset DONE
trie tree or judy array ...
string DONE
algorithm ...

