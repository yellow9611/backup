/** @addtogroup GenericAlgorithm */

/** @{ */

/**
 * @file
 * @brief Generic algorithm.
 */

#if !defined(GENERIC_ALGORITHM_H)
#define GENERIC_ALGORITHM_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * @brief For each data in [@a first, @a last), apply the @a actor.
 * @attention @a first and @a last shall belong to the same concrete
 * iterator type.
 */
void generic_for_each(const generic_iterator_t *first,
        const generic_iterator_t *last, generic_actor_t *actor);

/**
 * @brief In [@a first, @a last), find the first data that satisfies
 * the @a predicator. If no such data, It shall return @a last.
 * @attention @a first, @a last and @a ret shall belong to the
 * same concrete iterator type.
 */
void generic_find_if(const generic_iterator_t *first,
        const generic_iterator_t *last,
        const generic_predicator_t *predicator,
        generic_iterator_t *ret);

/**
 * @brief Calculate the distance from @a first to @a last.
 * @attention @a first and @a last shall belong to the same concrete
 * iterator type.
 */
ptrdiff_t generic_distance(const generic_iterator_t *first,
        const generic_iterator_t *last);

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_ALGORITHM_H */

/** @} */

