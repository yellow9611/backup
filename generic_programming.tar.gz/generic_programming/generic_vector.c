/** @addtogroup GenericVector */

/** @{ */

/**
 * @file
 * @brief Implementation of dynamic array.
 */

#include "generic_vector.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void generic_vector_clear(generic_vector_t *);

static inline void
generic_vector_iterator_init(generic_vector_iterator_t *iter,
        const generic_vector_t *gv, void *p) {
    generic_pointer_iterator_init(iter, p, gv->gdm->size);
}

static size_t generic_vector_next_capacity(const generic_vector_t *gv,
        size_t delta) {
    const size_t maximum = (size_t)(-1);
    size_t base;
    if (maximum - gv->size <= delta) {
        return maximum;
    }
    base = gv->size + delta;
    if (maximum - base <= base) {
        return maximum;
    }

    return 2 * base;
    /* invariant:
     * ret >= gv->size
     * ret >= delta
     */
}

static void generic_vector_swap(generic_vector_t *x,
        generic_vector_t *y) {
    generic_vector_t tmp = *x;
    *x = *y;
    *y = tmp;
}

static int generic_vector_data_copy(char *target,
        const char *src, size_t count,
        const generic_data_manager_t *gdm) {
    char *t;
    const char *s;
    const char *last = src + count * gdm->size;

    for (s = src, t = target; s != last; s += gdm->size, t += gdm->size) {
        if (gdm->copy(t, s)) {
            if (gdm->destruct) {
                char *e = t;
                for (t = target; t != e; t += gdm->size) {
                    gdm->destruct(t);
                }
            }
            return -1;
        }
    }

    return 0;
}

static int generic_vector_construct(generic_vector_t *gv,
        generic_memory_manager_t *gmm, const generic_data_manager_t *gdm) {
    gv->gmm = gmm;
    gv->gdm = gdm;
    gv->data = 0;
    gv->size = 0;
    gv->capacity = 0;
    return 0;
}

static void generic_vector_destruct(generic_vector_t *gv) {
    generic_vector_clear(gv);
    gv->gmm->deallocate(gv->gmm, gv->data, gv->capacity * gv->gdm->size);
}

static size_t generic_vector_size(const generic_vector_t *gv) {
    return gv->size;
}

static int generic_vector_empty(const generic_vector_t *gv) {
    return gv->size == 0;
}

static generic_vector_iterator_t generic_vector_begin(generic_vector_t *gv) {
    generic_vector_iterator_t iter;
    generic_vector_iterator_init(&iter, gv, gv->data);
    return iter;
}

static generic_vector_iterator_t generic_vector_end(generic_vector_t *gv) {
    generic_vector_iterator_t iter;
    generic_vector_iterator_init(&iter,
            gv, gv->data + gv->size * gv->gdm->size);
    return iter;
}

static void *generic_vector_front(generic_vector_t *gv) {
    return gv->data;
}

static void *generic_vector_back(generic_vector_t *gv) {
    return gv->data + (gv->size - 1) * gv->gdm->size;
}

static void *generic_vector_data(generic_vector_t *gv) {
    return gv->data;
}

static void *generic_vector_get(generic_vector_t *gv, size_t n) {
    return gv->data + n * gv->gdm->size;
}

static void *generic_vector_at(generic_vector_t *gv, size_t n) {
    if (n >= gv->size) {
        return 0;
    }
    return gv->data + n * gv->gdm->size;
}

static int generic_vector_reserve(generic_vector_t *gv, size_t n) {
    char *data;
    size_t size;
    size_t capacity;
    generic_memory_manager_t *gmm;

    if (n <= gv->capacity) {
        return 0;
    }

    gmm = gv->gmm;
    capacity = n;

    data = (char *)(gmm->allocate(gmm, capacity * gv->gdm->size));
    if (!data) {
        return -1;
    }

    if (generic_vector_data_copy(data, gv->data, gv->size, gv->gdm)) {
        gmm->deallocate(gmm, data, capacity * gv->gdm->size);
        return -1;
    }

    size = gv->size;

    generic_vector_clear(gv);
    gmm->deallocate(gmm, gv->data, gv->capacity * gv->gdm->size);

    gv->data = data;
    gv->size = size;
    gv->capacity = capacity;
    return 0;
}

static int generic_vector_push_back(generic_vector_t *gv,
        const void *data) {
    size_t capacity;

    if (gv->size < gv->capacity) {
        if (gv->gdm->copy(gv->data + gv->size * gv->gdm->size, data)) {
            return -1;
        }
        ++gv->size;
        return 0;
    }

    generic_vector_t ngv;
    capacity = generic_vector_next_capacity(gv, 1);

    if (capacity <= gv->capacity) {
        return -1;
    }

    if (generic_vector_construct(&ngv, gv->gmm, gv->gdm)) {
        return -1;
    }

    if (generic_vector_reserve(&ngv, capacity)) {
        generic_vector_destruct(&ngv);
        return -1;
    }

    /* ngv has enough memory now! */
    if (generic_vector_data_copy(ngv.data, gv->data, gv->size, gv->gdm)) {
        generic_vector_destruct(&ngv);
        return -1;
    }

    ngv.size = gv->size;

    /* push the new data back into ngv */
    if (generic_vector_push_back(&ngv, data)) {
        generic_vector_destruct(&ngv);
        return -1;
    }

    /* Now, it's safe to modify gv becase swap won't fail. */
    generic_vector_swap(gv, &ngv);
    generic_vector_destruct(&ngv);
    return 0;
}

static void generic_vector_pop_back(generic_vector_t *gv) {
    --gv->size;
    if (gv->gdm->destruct) {
        gv->gdm->destruct(gv->data + gv->size  * gv->gdm->size);
    }
}

static void generic_vector_clear(generic_vector_t *gv) {
    if (gv->gdm->destruct) {
        char *first = gv->data;
        char *last = first + gv->size * gv->gdm->size;
        while (first != last) {
            gv->gdm->destruct(first);
            first += gv->gdm->size;
        }
    }
    gv->size = 0;
}

static generic_memory_manager_t *
generic_vector_memory_manager(const generic_vector_t *gv) {
    return gv->gmm;
}

static const generic_data_manager_t *
generic_vector_data_manager(const generic_vector_t *gv) {
    return gv->gdm;
}

static generic_vector_api_t g_generic_vector_api = {
    &generic_vector_construct,
    &generic_vector_destruct,
    &generic_vector_size,
    &generic_vector_empty,
    &generic_vector_begin,
    &generic_vector_end,
    &generic_vector_front,
    &generic_vector_back,
    &generic_vector_data,
    &generic_vector_get,
    &generic_vector_at,
    &generic_vector_reserve,
    &generic_vector_push_back,
    &generic_vector_pop_back,
    &generic_vector_clear,
    &generic_vector_memory_manager,
    &generic_vector_data_manager
};

#if defined(__cplusplus)
}
#endif

const generic_vector_iterator_api_t *generic_vector_iterator_api(void) {
    return generic_pointer_iterator_api();
}

const generic_vector_api_t *generic_vector_api(void) {
    return &g_generic_vector_api;
}

/** @} */

