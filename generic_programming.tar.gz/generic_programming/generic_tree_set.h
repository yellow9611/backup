/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericTreeSet
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Tree set and tree multiset.
 * @details Elements shall be copyable.
 * Less operation shall be applicable to elements.
 * Elemenst of the container are ordered.
 */

/** @example test_generic_tree_set.c */

#if !defined(GENERIC_TREE_SET_H)
#define GENERIC_TREE_SET_H

#include <stddef.h>
#include "generic_utility.h"
#include "generic_tree_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_tree_set_api_t generic_tree_set_api_t;
typedef struct generic_tree_set_t generic_tree_set_t;
typedef struct generic_tree_set_iterator_t generic_tree_set_iterator_t;
typedef struct generic_tree_set_iterator_api_t generic_tree_set_iterator_api_t;

/** @brief Get API of generic tree set iterator. */
const generic_tree_set_iterator_api_t *generic_tree_set_iterator_api(void);

/** @brief Get API of generic tree set. */
const generic_tree_set_api_t *generic_tree_set_api(void);

/** @brief API of generic tree set iterator. */
struct generic_tree_set_iterator_api_t {
    void (*next)(generic_tree_set_iterator_t *);
    void (*prev)(generic_tree_set_iterator_t *);
    void (*move)(generic_tree_set_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_tree_set_iterator_t *);
    int (*equal)(const generic_tree_set_iterator_t *,
            const generic_tree_set_iterator_t *);
    ptrdiff_t (*sub)(const generic_tree_set_iterator_t *,
            const generic_tree_set_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic tree set iterator.
 * @attention Only member @a api is public.
 */
struct generic_tree_set_iterator_t {
    const generic_tree_set_iterator_api_t *api;
    generic_tree_table_iterator_t imp;
};

/**
 * @brief API of generic tree set.
 * @attention Multiple elements that are equal are not allowed.
 */
struct generic_tree_set_api_t {
    /**
     * @brief Construct one empty tree set.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_tree_set_t *,
            generic_memory_manager_t *, const generic_data_manager_t *);

    /** @brief Destruct the tree set. */
    void (*destruct)(generic_tree_set_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_tree_set_t *);

    /** @brief Test if tree set is empty or not. */
    int (*empty)(const generic_tree_set_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_tree_set_iterator_t (*begin)(generic_tree_set_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_tree_set_iterator_t (*end)(generic_tree_set_t *);

    /**
     * @brief Find the element that is equal to @a elem.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of tree set.
     */
    generic_tree_set_iterator_t (*find)(generic_tree_set_t *,
            const void *elem);

    /** @brief Get the number of elements that are equal to @a elem. */
    size_t (*count)(const generic_tree_set_t *, const void *elem);

    /**
     * @brief Get the range of elements that are equal to @a elem.
     * @param[out] begin Points to the first element equal to @a elem.
     * @param[out] end Points after the last element equal to @a elem.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_tree_set_t *, const void *elem,
            generic_tree_set_iterator_t *begin,
            generic_tree_set_iterator_t *end);

    /**
     * @brief Get the iterator that points to the first element which
     * is not less than @a elem
     * @attention If no such element, it shall be end of tree set.
     */
    generic_tree_set_iterator_t (*lower_bound)(generic_tree_set_t *,
            const void *elem);

    /**
     * @brief Get the iterator that points to the first element which 
     * is greater than @a elem.
     * @attention If no such element, it shall be end of tree set.
     */
    generic_tree_set_iterator_t (*upper_bound)(generic_tree_set_t *,
            const void *elem);

    /**
     * @brief Insert one element.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of tree set.
     */
    generic_tree_set_iterator_t (*insert)(generic_tree_set_t *, const void *);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_tree_set_iterator_t (*erase)(generic_tree_set_t *,
            const generic_tree_set_iterator_t *iter);

    /**
     * @brief Erase all elements equal to @a elem.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_tree_set_t *, const void *elem);

    /** @brief Erase all elements. */
    void (*clear)(generic_tree_set_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_tree_set_t *);

    /** @brief Get data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_tree_set_t *);
};

/**
 * @brief Representation of tree set.
 * @attention All members are private.
 */
struct generic_tree_set_t {
    generic_tree_table_t imp;
};

typedef struct generic_tree_multiset_api_t generic_tree_multiset_api_t;
typedef struct generic_tree_multiset_t generic_tree_multiset_t;
typedef struct generic_tree_multiset_iterator_t generic_tree_multiset_iterator_t;
typedef struct generic_tree_multiset_iterator_api_t generic_tree_multiset_iterator_api_t;

/** @brief Get API of generic tree multiset iterator. */
const generic_tree_multiset_iterator_api_t *generic_tree_multiset_iterator_api(void);

/** @brief Get API of generic tree multiset. */
const generic_tree_multiset_api_t *generic_tree_multiset_api(void);

/** @brief API of generic tree multiset iterator. */
struct generic_tree_multiset_iterator_api_t {
    void (*next)(generic_tree_multiset_iterator_t *);
    void (*prev)(generic_tree_multiset_iterator_t *);
    void (*move)(generic_tree_multiset_iterator_t *, ptrdiff_t); /* 0 */
    const void *(*deref)(generic_tree_multiset_iterator_t *);
    int (*equal)(const generic_tree_multiset_iterator_t *,
            const generic_tree_multiset_iterator_t *);
    ptrdiff_t (*sub)(const generic_tree_multiset_iterator_t *,
            const generic_tree_multiset_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic tree multiset iterator.
 * @attention Only member @a api is public.
 */
struct generic_tree_multiset_iterator_t {
    const generic_tree_multiset_iterator_api_t *api;
    generic_tree_table_iterator_t imp;
};

/**
 * @brief API of generic tree multiset.
 * @attention Multiple equal elements are allowed.
 */
struct generic_tree_multiset_api_t {
    /**
     * @brief Construct one empty tree multiset.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_tree_multiset_t *,
            generic_memory_manager_t *, const generic_data_manager_t *);

    /** @brief Destruct the tree multiset. */
    void (*destruct)(generic_tree_multiset_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_tree_multiset_t *);

    /** @brief Test if tree multiset is empty or not. */
    int (*empty)(const generic_tree_multiset_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_tree_multiset_iterator_t (*begin)(generic_tree_multiset_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_tree_multiset_iterator_t (*end)(generic_tree_multiset_t *);

    /**
     * @brief Find the element that is equal to @a elem.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of tree multiset.
     */
    generic_tree_multiset_iterator_t (*find)(generic_tree_multiset_t *, 
            const void *elem);

    /** @brief Get the number of elements that are equal to @a elem. */
    size_t (*count)(const generic_tree_multiset_t *, const void *elem);

    /**
     * @brief Get the range of elements that are equal to @a elem.
     * @param[out] begin Points to the first element equal to @a elem.
     * @param[out] end Points after the last element equal to @a elem.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_tree_multiset_t *, const void *elem,
            generic_tree_multiset_iterator_t *begin,
            generic_tree_multiset_iterator_t *end);
    /**
     * @brief Get the iterator that points to the first element that 
     * is not less than @a elem.
     * @attention If no such element, it shall be end of tree multiset.
     */
    generic_tree_multiset_iterator_t (*lower_bound)(generic_tree_multiset_t *,
            const void *elem);
    /**
     * @brief Get the iterator that points to the first element which 
     * is greater than @a elem.
     * @attention If no such element, it shall be end of tree multiset.
     */
    generic_tree_multiset_iterator_t (*upper_bound)(generic_tree_multiset_t *,
            const void *elem);

    /**
     * @brief Insert one element.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of tree multiset.
     */
    generic_tree_multiset_iterator_t (*insert)(generic_tree_multiset_t *,
            const void *);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_tree_multiset_iterator_t (*erase)(generic_tree_multiset_t *,
            const generic_tree_multiset_iterator_t *);

    /**
     * @brief Erase all elements that are equal to @a elem.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_tree_multiset_t *, const void *elem);

    /** @brief Erase all elements. */
    void (*clear)(generic_tree_multiset_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_tree_multiset_t *);

    /** @brief Get data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_tree_multiset_t *);
};

/**
 * @brief Representation of tree multiset.
 * @attention All members are private.
 */
struct generic_tree_multiset_t {
    generic_tree_table_t imp;
};

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_TREE_SET_H */

/** @} */

