/** @addtogroup GenericForwardList */

/** @{ */

/**
 * @file
 * @brief Implementation of single list.
 */

#include "generic_config.h"
#include "generic_forward_list.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void generic_forward_list_clear(generic_forward_list_t *);

static inline char *
generic_forward_list_item_data(const generic_forward_list_t *gfl,
        generic_forward_list_item_t *item) {
    return item->data + gfl->data_offset;
}

static void
generic_forward_list_iterator_next(generic_forward_list_iterator_t *iter) {
    iter->item = iter->item->next;
}

static void *
generic_forward_list_iterator_deref(generic_forward_list_iterator_t *iter) {
    return generic_forward_list_item_data(iter->gfl, iter->item);
}

static int
generic_forward_list_iterator_equal(const generic_forward_list_iterator_t *lhs,
        const generic_forward_list_iterator_t *rhs) {
    return lhs->item == rhs->item;
}

static generic_iterator_tag_t generic_forward_list_iterator_category(void) {
    return generic_forward_iterator_tag;
}

static size_t generic_forward_list_iterator_size(void) {
    return sizeof(generic_forward_list_iterator_t);
}

static generic_forward_list_iterator_api_t g_generic_forward_list_iterator_api = {
    &generic_forward_list_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_forward_list_iterator_deref,
    &generic_forward_list_iterator_equal,
    0, /* sub */
    &generic_forward_list_iterator_category,
    &generic_forward_list_iterator_size
};

static void
generic_forward_list_iterator_init(generic_forward_list_iterator_t *iter,
        const generic_forward_list_t *gfl, generic_forward_list_item_t *item) {
    iter->api = &g_generic_forward_list_iterator_api;
    iter->gfl = gfl;
    iter->item = item;
}

static generic_forward_list_item_t *
generic_forward_list_create_item(generic_forward_list_t *gfl,
        const void *data) {
    generic_memory_manager_t *gmm = gfl->gmm;
    const generic_data_manager_t *gdm = gfl->gdm;
    generic_forward_list_item_t *item;

    item = (generic_forward_list_item_t *)(gmm->allocate(gmm, gfl->item_size));
    if (!item) {
        return 0;
    }

    if (gdm->copy(generic_forward_list_item_data(gfl, item), data)) {
        gmm->deallocate(gmm, item, gfl->item_size);
        return 0;
    }

    return item;
}

static void generic_forward_list_destroy_item(generic_forward_list_t *gfl,
        generic_forward_list_item_t *item) {
    if (gfl->gdm->destruct) {
        gfl->gdm->destruct(generic_forward_list_item_data(gfl, item));
    }
    gfl->gmm->deallocate(gfl->gmm, item, gfl->item_size);
}

static void generic_forward_list_destroy_items(generic_forward_list_t *gfl,
        generic_forward_list_item_t *first,
        generic_forward_list_item_t *last) {
    generic_forward_list_item_t *item = first;
    if (gfl->gdm->destruct) {
        while (item != last) {
            generic_forward_list_item_t *next = item->next;
            gfl->gdm->destruct(generic_forward_list_item_data(gfl, item));
            gfl->gmm->deallocate(gfl->gmm, item, gfl->item_size);
            item = next;
        }
    } else {
        while (item != last) {
            generic_forward_list_item_t *next = item->next;
            gfl->gmm->deallocate(gfl->gmm, item, gfl->item_size);
            item = next;
        }
    }
}

static int generic_forward_list_construct(generic_forward_list_t *gfl,
        generic_memory_manager_t *gmm, const generic_data_manager_t *gdm) {
    gfl->gmm = gmm;
    gfl->gdm = gdm;
    gfl->sentry.next = &gfl->sentry;
    gfl->item_count = 0;
    generic_forward_list_config(gfl);
    return 0;
}

static void generic_forward_list_destruct(generic_forward_list_t *gfl) {
    generic_forward_list_clear(gfl);
}

static size_t generic_forward_list_size(const generic_forward_list_t *gfl) {
    return gfl->item_count;
}

static int generic_forward_list_empty(const generic_forward_list_t *gfl) {
    return gfl->item_count == 0;
}

static generic_forward_list_iterator_t
generic_forward_list_begin(generic_forward_list_t *gfl) {
    generic_forward_list_iterator_t iter;
    generic_forward_list_iterator_init(&iter, gfl, gfl->sentry.next);
    return iter;
}

static generic_forward_list_iterator_t
generic_forward_list_end(generic_forward_list_t *gfl) {
    generic_forward_list_iterator_t iter;
    generic_forward_list_iterator_init(&iter, gfl, &gfl->sentry);
    return iter;
}

static generic_forward_list_iterator_t
generic_forward_list_before_begin(generic_forward_list_t *gfl) {
    generic_forward_list_iterator_t iter;
    generic_forward_list_iterator_init(&iter, gfl, &gfl->sentry);
    return iter;
}

static void *generic_forward_list_front(generic_forward_list_t *gfl) {
    return generic_forward_list_item_data(gfl, gfl->sentry.next);
}

static generic_forward_list_iterator_t
generic_forward_list_insert_after(generic_forward_list_t *gfl,
        const generic_forward_list_iterator_t *iter, const void *data) {
    generic_forward_list_iterator_t ret;
    generic_forward_list_item_t *item;

    item = generic_forward_list_create_item(gfl, data);
    if (!item) {
        return generic_forward_list_end(gfl);
    }

    item->next = iter->item->next;
    iter->item->next = item;
    ++gfl->item_count;

    generic_forward_list_iterator_init(&ret, gfl, item);
    return ret;
}

static generic_forward_list_iterator_t
generic_forward_list_erase_after(generic_forward_list_t *gfl,
        const generic_forward_list_iterator_t *iter) {
    generic_forward_list_iterator_t ret;
    generic_forward_list_item_t *deletion = iter->item->next;

    iter->item->next = deletion->next;

    generic_forward_list_destroy_item(gfl, deletion);
    --gfl->item_count;

    generic_forward_list_iterator_init(&ret, gfl, iter->item->next);
    return ret;
}

static int generic_forward_list_push_front(generic_forward_list_t *gfl,
        const void *data) {
    generic_forward_list_iterator_t before_begin;
    generic_forward_list_iterator_t iter;
    generic_forward_list_iterator_t end;

    before_begin = generic_forward_list_before_begin(gfl);
    iter = generic_forward_list_insert_after(gfl, &before_begin, data);
    end = generic_forward_list_end(gfl);

    return generic_forward_list_iterator_equal(&iter, &end);
}

static void generic_forward_list_pop_front(generic_forward_list_t *gfl) {
    generic_forward_list_iterator_t before_begin;
    before_begin = generic_forward_list_before_begin(gfl);
    generic_forward_list_erase_after(gfl, &before_begin);
}

static void generic_forward_list_clear(generic_forward_list_t *gfl) {
    generic_forward_list_destroy_items(gfl, gfl->sentry.next, &gfl->sentry);
    gfl->sentry.next = &gfl->sentry;
    gfl->item_count = 0;
}

static generic_memory_manager_t *
generic_forward_list_memory_manager(const generic_forward_list_t *gfl) {
    return gfl->gmm;
}

static const generic_data_manager_t *
generic_forward_list_data_manager(const generic_forward_list_t *gfl) {
    return gfl->gdm;
}

static generic_forward_list_api_t g_generic_forward_list_api = {
    &generic_forward_list_construct,
    &generic_forward_list_destruct,
    &generic_forward_list_size,
    &generic_forward_list_empty,
    &generic_forward_list_begin,
    &generic_forward_list_end,
    &generic_forward_list_before_begin,
    &generic_forward_list_front,
    &generic_forward_list_insert_after,
    &generic_forward_list_erase_after,
    &generic_forward_list_push_front,
    &generic_forward_list_pop_front,
    &generic_forward_list_clear,
    &generic_forward_list_memory_manager,
    &generic_forward_list_data_manager
};

#if defined(__cplusplus)
}
#endif

const generic_forward_list_iterator_api_t *generic_forward_list_iterator_api(void) {
    return &g_generic_forward_list_iterator_api;
}

const generic_forward_list_api_t *generic_forward_list_api(void) {
    return &g_generic_forward_list_api;
}

/** @} */

