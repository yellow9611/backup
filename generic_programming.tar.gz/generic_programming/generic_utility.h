/** @addtogroup GenericUtility */

/** @{ */

/**
 * @file
 * @brief Utility for C generic programming.
 */

#if !defined(GENERIC_UTILITY_H)
#define GENERIC_UTILITY_H

#include <stddef.h>

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_memory_manager_t generic_memory_manager_t;

/**
 * @brief Equal comparision.
 * @return It shall return non-zero if the first data is equal
 * to the second one. Otherwise, It shall return zero.
 */
typedef int (*generic_equal_fp_t)(const void *, const void *);

/**
 * @brief Less comparision.
 * @return It shall return non-zero if the first data is less
 * than the second one. Otherwise, It shall return zero.
 */
typedef int (*generic_less_fp_t)(const void *, const void *);


/**
 * @brief Copy operation.
 * @return Upon successful completion, It shall return 0.
 */
typedef int (*generic_copy_fp_t)(void *, const void *);

/**
 * @brief Assign operation.
 * @return Upon successful completion, It shall return 0.
 */
typedef int (*generic_assign_fp_t)(void *, const void *);

/** @brief Swap operation. */
typedef void (*generic_swap_fp_t)(void *, void *);

/** @brief Destruct operation. */
typedef void (*generic_destruct_fp_t)(void *);

typedef struct generic_data_manager_t generic_data_manager_t;

typedef enum generic_iterator_tag_t {
    generic_forward_iterator_tag,
    generic_bidirectional_iterator_tag,
    generic_random_iterator_tag
} generic_iterator_tag_t;

typedef struct generic_iterator_t generic_iterator_t;
typedef struct generic_iterator_api_t generic_iterator_api_t;
typedef struct generic_pointer_iterator_t generic_pointer_iterator_t;
typedef struct generic_pointer_iterator_api_t generic_pointer_iterator_api_t;
typedef struct generic_predicator_t generic_predicator_t;
typedef struct generic_actor_t generic_actor_t;

/** @brief Hash operation. */
typedef size_t (*generic_hash_fp_t)(const void *);

/**
 * @brief Generic memory manager.
 * @attention Any concrete memory manager must obey to this interface.
 */
struct generic_memory_manager_t {
    /**
     * @brief Allocate memory.
     * @param size Memory size in bytes.
     */
    void *(*allocate)(generic_memory_manager_t *, size_t size);

    /**
     * @brief Deallocate memory.
     * @param size Memory size in bytes.
     */
    void (*deallocate)(generic_memory_manager_t *, void *, size_t size);
};

/** @brief Get the standard memory manager(malloc/free). */
generic_memory_manager_t *std_memory_manager(void);

/**
 * @brief Generic data manager.
 * @attention Any concrete data manager must obey to this interface.
 */
struct generic_data_manager_t {
    /** @brief Equal comparision. */
    generic_equal_fp_t equal;

    /** @brief Less comparision. */
    generic_less_fp_t less;

    /** @brief Copy operation. */
    generic_copy_fp_t copy;

    /** @brief Assign operation. */
    generic_assign_fp_t assign;

    /** @brief Swap operation. */
    generic_swap_fp_t swap;

#if 0
    /* It's hard to emulate default constructor.
     * For example, generic_hash_map_t at least requires
     * an argument of hash function. Of course, we can add
     * hash function or generic pointer of extra argument required
     * by non-default constructor into generic_data_manager_t.
     * However, ..., ugly.
     */
#endif
    /** @brief Destruct operation. */
    generic_destruct_fp_t destruct;

    /** @brief Data size in bytes. */
    size_t size;
};

/** @brief Get data manager for unsigned int. */
const generic_data_manager_t *uint_data_manager(void);

/** @brief Get data manager for unsigned long long. */
const generic_data_manager_t *ulonglong_data_manager(void);

/** @brief Get data manager for generic pointer (void *). */
const generic_data_manager_t *pointer_data_manager(void);

/**
 * @brief API of generic iterator.
 * @attention Any iterator shall support bitwise copy and assign.
 * @attention Any iterator operation cannot fail.
 * @attention No need to destruct iterator.
 * @attention Any concrete iterator API must obey to this interface.
 */
struct generic_iterator_api_t {
    /** @brief Move to next. */
    void (*next)(generic_iterator_t *);

    /** @brief Move to previous. */
    void (*prev)(generic_iterator_t *);

    /** @brief Move to the one that is @a distance away from @a iter. */
    void (*move)(generic_iterator_t *iter, ptrdiff_t distance);

    /** @brief Dereference operation. */
    void *(*deref)(generic_iterator_t *);

    /**
     * @brief Equal comparision.
     * @return It shall return non-zero if two iterators are equal.
     * Otherwise, It shall return zero.
     */
    int (*equal)(const generic_iterator_t *, const generic_iterator_t *);

    /** @brief Calculate the distance from the first to the second. */
    ptrdiff_t (*sub)(const generic_iterator_t *,
            const generic_iterator_t *);

    /** @brief Get the iterator category. */
    generic_iterator_tag_t (*category)(void);

    /** @brief Get the iterator itself size in bytes. */
    size_t (*size)(void);
};

/**
 * @brief Representation of generic iterator.
 * @attention The first member of any concrete iterator must be a pointer
 * to the concrete iterator API.
 * @attention Only the member @a api is public.
 * @internal
 * Generic algorithm requires: may change in the future.
 * Any concrete iterator's size cannot be greater than
 * sizeof(generic_iterator_t). When implementing generic algorithm that 
 * accepts arguments of pointer to generic_iterator_t, which actually point
 * to concrete iterator, we often need to allocate concrete iterators
 * on stack. This requirement facilitates this operation. We can allocate
 * generic iterators on stack and treat them as concrete iterators.
 */
struct generic_iterator_t {
    const generic_iterator_api_t *api;
    char data[64];
};

/** @brief API of pointer iterator. */
struct generic_pointer_iterator_api_t {
    void (*next)(generic_pointer_iterator_t *);
    void (*prev)(generic_pointer_iterator_t *);
    void (*move)(generic_pointer_iterator_t *, ptrdiff_t);
    void *(*deref)(generic_pointer_iterator_t *);
    int (*equal)(const generic_pointer_iterator_t *,
            const generic_pointer_iterator_t *);
    ptrdiff_t (*sub)(const generic_pointer_iterator_t *,
            const generic_pointer_iterator_t *);
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Represention of pointer iterator.
 * @attention Only the member @a api is public.
 */
struct generic_pointer_iterator_t {
    const generic_pointer_iterator_api_t *api;
    char *data;
    size_t size;
};

/**
 * @brief Initialize pointer iterator.
 * @param size Data size in bytes.
 */
void generic_pointer_iterator_init(generic_pointer_iterator_t *,
        void *, size_t size);

/** @brief Get API of pointer iterator. */
const generic_pointer_iterator_api_t *generic_pointer_iterator_api(void);

/**
 * @brief Generic predicator.
 * @attention Any concrete predicator shall conform to this interface.
 */
struct generic_predicator_t {
    /**
     * @brief Predicate operation.
     * @return If the predication is satisfied,
     * It shall return non-zero. Otherwsie, It shall return zero.
     */
    int (*predicate)(const generic_predicator_t *, const void *);
};

/**
 * @brief Generic actor.
 * @attention Any concrete actor shall conform to this interface.
 */
struct generic_actor_t {
    void (*act)(generic_actor_t *, void *);
};

/** @brief FNV1A32 hash function */
size_t generic_fnv1a32(const void *, size_t);

/** @brief FNV1A32 hash function */
size_t ucstr_fnv1a32(const unsigned char *);

/** @brief FNV1A32 hash function */
size_t cstr_fnv1a32(const char *);

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_UTILITY_H */

/** @} */

