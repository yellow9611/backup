/**
 * @file
 * @brief Tree table that facilitates to implement tree map and tree set.
 * @internal
 */

#if !defined(GENERIC_TREE_TABLE_H)
#define GENERIC_TREE_TABLE_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_tree_table_t generic_tree_table_t;
typedef struct generic_tree_table_iterator_t generic_tree_table_iterator_t;
typedef struct generic_tree_table_item_t generic_tree_table_item_t;
typedef struct generic_tree_table_data_t generic_tree_table_data_t;

struct generic_tree_table_item_t {
    generic_tree_table_item_t *left;
    generic_tree_table_item_t *right;
    generic_tree_table_item_t *parent;
    char color;
    char data[1];
};

struct generic_tree_table_data_t {
    const void *key;
    void *value;
};

struct generic_tree_table_iterator_t {
    generic_tree_table_t *gtt;
    generic_tree_table_item_t *item;
    generic_tree_table_data_t data;
};

void generic_tree_table_iterator_next(generic_tree_table_iterator_t *);

void generic_tree_table_iterator_prev(generic_tree_table_iterator_t *);

generic_tree_table_data_t *
generic_tree_table_iterator_deref(generic_tree_table_iterator_t *);

int generic_tree_table_iterator_equal(const generic_tree_table_iterator_t *,
        const generic_tree_table_iterator_t *);

generic_iterator_tag_t generic_tree_table_iterator_category(void);

struct generic_tree_table_t {
    generic_memory_manager_t *gmm;
    const generic_data_manager_t *gkm;
    const generic_data_manager_t *gvm;
    /* nil item
     * sentinel.parent == root
     * sentinel.left == leftmost
     * sentinel.right == rightmost
     * sentinel: before the leftmost, after the rightmost.
     * root's parent == sentinel
     */
    generic_tree_table_item_t sentinel;
    size_t item_count;
    size_t item_size; /* each item size in bytes */
    int unique;
    size_t key_offset; /* key offset relative to item->data */
    size_t value_offset; /* value offset relative to item->data */
};

int generic_tree_table_construct(generic_tree_table_t *,
        generic_memory_manager_t *, const generic_data_manager_t *,
        const generic_data_manager_t *, int);

void generic_tree_table_destruct(generic_tree_table_t *);

size_t generic_tree_table_size(const generic_tree_table_t *);

int generic_tree_table_empty(const generic_tree_table_t *);

void generic_tree_table_begin(generic_tree_table_t *,
        generic_tree_table_iterator_t *);

void generic_tree_table_end(generic_tree_table_t *,
        generic_tree_table_iterator_t *);

int generic_tree_table_find(generic_tree_table_t *, const void *,
        generic_tree_table_iterator_t *);

size_t generic_tree_table_count(const generic_tree_table_t *,
        const void *);

void generic_tree_table_lower_bound(generic_tree_table_t *,
        const void *, generic_tree_table_iterator_t *);

void generic_tree_table_upper_bound(generic_tree_table_t *,
        const void *, generic_tree_table_iterator_t *);

void generic_tree_table_equal_range(generic_tree_table_t *, const void *,
        generic_tree_table_iterator_t *,
        generic_tree_table_iterator_t *);

int generic_tree_table_insert(generic_tree_table_t *,
        const void *, const void *,
        generic_tree_table_iterator_t *);

void generic_tree_table_erase(generic_tree_table_t *,
        const generic_tree_table_iterator_t *,
        generic_tree_table_iterator_t *);

size_t generic_tree_table_remove(generic_tree_table_t *, const void *);

void generic_tree_table_clear(generic_tree_table_t *);

generic_memory_manager_t *
generic_tree_table_memory_manager(const generic_tree_table_t *);

const generic_data_manager_t *
generic_tree_table_key_manager(const generic_tree_table_t *);

const generic_data_manager_t *
generic_tree_table_value_manager(const generic_tree_table_t *);

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_TREE_TABLE_H */

