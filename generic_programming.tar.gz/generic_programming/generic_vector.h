/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericVector
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Dynamic array whose element shall be copyable.
 */

/** @example test_generic_vector.c */

#if !defined(GENERIC_VECTOR_H)
#define GENERIC_VECTOR_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef generic_pointer_iterator_t generic_vector_iterator_t;
typedef generic_pointer_iterator_api_t generic_vector_iterator_api_t;
typedef struct generic_vector_t generic_vector_t;
typedef struct generic_vector_api_t generic_vector_api_t;

/** @brief Get API of generic vector iterator. */
const generic_vector_iterator_api_t *generic_vector_iterator_api(void);

/** @brief Get API of generic vector. */
const generic_vector_api_t *generic_vector_api(void);

/** @brief API of generic vector. */
struct generic_vector_api_t {
    /**
     * @brief Construct one empty vector.
     * @return Upon successful completion, It shall return 0.
     */
    int (*construct)(generic_vector_t *,
            generic_memory_manager_t *, const generic_data_manager_t *);

    /** @brief Destruct the vector. */
    void (*destruct)(generic_vector_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_vector_t *);

    /** @brief Test if vector is empty or not. */
    int (*empty)(const generic_vector_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_vector_iterator_t (*begin)(generic_vector_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_vector_iterator_t (*end)(generic_vector_t *);

    /** @brief Get the address of the first element. */
    void *(*front)(generic_vector_t *);

    /** @brief Get the address of the last element. */
    void *(*back)(generic_vector_t *);

    /** @brief Get the starting address of the low level array. */
    void *(*data)(generic_vector_t *);

    /** @brief Get the address of the nth element without range check. */
    void *(*get)(generic_vector_t *, size_t);

    /**
     * @brief Get the address of the nth element with range check.
     * @return It shall return 0 if element index is out of range.
     */
    void *(*at)(generic_vector_t *, size_t);

    /**
     * @brief Reserve enough memory to be able to hold @a n elements.
     * @return Upon successful completion, It shall return 0.
     */
    int (*reserve)(generic_vector_t *, size_t n);

    /**
     * @brief Insert one element at the back.
     * @return Upon successful completion, It shall return 0.
     */
    int (*push_back)(generic_vector_t *, const void *);

    /** @brief Erase the last element. */
    void (*pop_back)(generic_vector_t *);

    /** @brief Erase all elements. */
    void (*clear)(generic_vector_t *);

    /** @brief Get the memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_vector_t *);

    /** @brief Get the data manager. */
    const generic_data_manager_t *(*data_manager)(const generic_vector_t *);
};

/**
 * @brief Representation of generic vector.
 * @attention All members are private.
 */
struct generic_vector_t {
    generic_memory_manager_t *gmm;
    const generic_data_manager_t *gdm;
    char *data;
    size_t size; /* number of data */
    size_t capacity;
};

#if defined(__cplusplus)
}
#endif

#endif  /* GENERIC_VECTOR_H */

/** @} */

