#include <assert.h>
#include "../generic_utility.h"
#include "../generic_forward_list.h"

int main(int argc, char *argv[]) {
    generic_forward_list_iterator_t iter, last;
    generic_forward_list_t gfl;
    const unsigned long long size = 10ull;
    unsigned long long i;
    unsigned long long *p;
    const generic_forward_list_api_t *api = generic_forward_list_api(); 

    api->construct(&gfl, std_memory_manager(), ulonglong_data_manager());

    for (i = 0; i < size; ++i) {
        api->push_front(&gfl, &i);
    }

    assert(api->size(&gfl) == size);

    iter = api->begin(&gfl);
    last = api->end(&gfl);
    i = size;
    while (!iter.api->equal(&iter, &last)) {
        --i;
        p = (unsigned long long *)(iter.api->deref(&iter));
        assert(i == *p);
        iter.api->next(&iter);
    }
    assert(i == 0);

    i = size;
    while (!api->empty(&gfl)) {
        --i;
        p = (unsigned long long *)(api->front(&gfl));
        assert(i == *p);
        api->pop_front(&gfl);
    }
    assert(i == 0);

    assert(api->size(&gfl) == 0);

    iter = api->before_begin(&gfl);
    for (i = 0; i < size; ++i) {
        iter = api->insert_after(&gfl, &iter, &i);
    }

    assert(api->size(&gfl) == size);

    iter = api->begin(&gfl);
    last = api->end(&gfl);
    i = 0;
    while (!iter.api->equal(&iter, &last)) {
        p = (unsigned long long *)(iter.api->deref(&iter));
        assert(i == *p);
        iter.api->next(&iter);
        ++i;
    }
    assert(i == size);

    api->clear(&gfl);
    assert(api->size(&gfl) == 0);

    api->destruct(&gfl);
    
    return 0;
}

