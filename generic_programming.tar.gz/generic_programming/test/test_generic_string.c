#include <string.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_string.h"

int main(int argc, char *argv[]) {
    const generic_string_api_t *api = generic_string_api();
    generic_string_t gs;
    api->construct(&gs, std_memory_manager());

    api->assign_cstr(&gs, "hello");
    assert(api->size(&gs) == strlen("hello"));
    assert(api->front(&gs) == 'h');
    assert(api->back(&gs) == 'o');

    api->append_cstr(&gs, "!");
    assert(strcmp(api->c_str(&gs), "hello!") == 0);

    api->destruct(&gs);
    return 0;
}

