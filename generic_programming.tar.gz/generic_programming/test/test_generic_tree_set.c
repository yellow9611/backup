#include <stddef.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_tree_set.h"

static void test_tree_set() {
    generic_tree_set_iterator_t iter;
    generic_tree_set_t gts;
    const unsigned long long size = 100ull;
    unsigned long long i;
    const unsigned long long *k;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_tree_set_api_t *api = generic_tree_set_api();

    api->construct(&gts, std_memory_manager(), gkm);

    for (i = 0; i < size; ++i) {
        api->insert(&gts, &i);
    }

    for (i = 0; i < size; ++i) {
        api->insert(&gts, &i);
    }

    assert(api->size(&gts) == size);

    i = 0;
    assert(api->count(&gts, &i) == 1);
    assert(api->remove(&gts, &i) == 1);
    assert(api->count(&gts, &i) == 0);

    assert(api->size(&gts) == size - 1);

    i = 1;
    iter = api->find(&gts, &i);
    k = (const unsigned long long *)(iter.api->deref(&iter));
    assert(*k == i);
    api->erase(&gts, &iter);
    assert(!api->count(&gts, &i));

    assert(api->size(&gts) == size - 2);

    api->clear(&gts);

    assert(api->size(&gts) == 0);

    api->destruct(&gts);
}

static void test_tree_multiset() {
    generic_tree_multiset_iterator_t iter;
    generic_tree_multiset_iterator_t last;
    generic_tree_multiset_t gts;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    const unsigned long long *k;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_tree_multiset_api_t *api = generic_tree_multiset_api();
    
    api->construct(&gts, std_memory_manager(), gkm);

    for (i = 0; i < size; ++i) {
        api->insert(&gts, &i);
    }

    for (i = 0; i < size; ++i) {
        api->insert(&gts, &i);
    }

    assert(api->size(&gts) == 2 * size);

    i = 0;
    assert(api->count(&gts, &i) == 2);
    assert(api->remove(&gts, &i) == 2);
    assert(api->count(&gts, &i) == 0);
    assert(api->size(&gts) == 2 * size - 2);

    i = 1;
    iter = api->find(&gts, &i);
    k = (const unsigned long long *)(iter.api->deref(&iter));
    assert(*k == i);
    api->erase(&gts, &iter);
    assert(api->count(&gts, &i));
    iter = api->find(&gts, &i);
    api->erase(&gts, &iter);
    assert(!api->count(&gts, &i));
    assert(api->size(&gts) == 2 * size - 4);

    i = 2;
    j = 0;
    api->equal_range(&gts, &i, &iter, &last);
    while (!iter.api->equal(&iter, &last)) {
        k = (const unsigned long long *)(iter.api->deref(&iter));
        assert(*k == i);
        iter.api->next(&iter);
        ++j;
    }
    assert(j == 2);

    api->clear(&gts);

    assert(api->size(&gts) == 0);

    api->destruct(&gts);
}

int main(int argc, char *argv[]) {
    test_tree_set();
    test_tree_multiset();

    return 0;
}

