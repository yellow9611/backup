#include <assert.h>
#include "../generic_utility.h"
#include "../generic_list.h"

int main(int argc, char *argv[]) {
    generic_list_iterator_t iter, last;
    generic_list_t gl;
    const unsigned long long size = 10ull;
    unsigned long long i;
    unsigned long long *p;
    const generic_list_api_t *api = generic_list_api();

    api->construct(&gl, std_memory_manager(), ulonglong_data_manager());

    for (i = 0; i < size; ++i) {
        api->push_front(&gl, &i);
    }

    assert(api->size(&gl) == size);

    iter = api->begin(&gl);
    last = api->end(&gl);
    i = size;
    while (!iter.api->equal(&iter, &last)) {
        --i;
        p = (unsigned long long *)(iter.api->deref(&iter));
        assert(i == *p);
        iter.api->next(&iter);
    }
    assert(i == 0);

    i = size;
    while (!api->empty(&gl)) {
        --i;
        p = (unsigned long long *)(api->front(&gl));
        assert(i == *p);
        api->pop_front(&gl);
    }
    assert(i == 0);

    assert(api->size(&gl) == 0);

    for (i = 0; i < size; ++i) {
        api->push_back(&gl, &i);
    }

    assert(api->size(&gl) == size);

    iter = api->begin(&gl);
    last = api->end(&gl);
    i = 0;
    while (!iter.api->equal(&iter, &last)) {
        p = (unsigned long long *)(iter.api->deref(&iter));
        assert(i == *p);
        iter.api->next(&iter);
        ++i;
    }
    assert(i == size);

    i = size;
    while (!api->empty(&gl)) {
        --i;
        p = (unsigned long long *)(api->back(&gl));
        assert(i == *p);
        api->pop_back(&gl);
    }
    assert(i == 0);

    assert(api->size(&gl) == 0);

    last = api->end(&gl);
    i = 1;
    iter = api->insert(&gl, &last, &i);
    i = 2;
    api->insert(&gl, &last, &i);

    assert(api->size(&gl) == 2);

    api->erase(&gl, &iter); /* erase 1 */

    assert(api->size(&gl) == 1);

    p = (unsigned long long *)(api->back(&gl));
    assert (2 == *p);

    api->clear(&gl);
    assert(api->size(&gl) == 0);

    api->destruct(&gl);
    
    return 0;
}

