#include <stddef.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_tree_map.h"

static void test_tree_map() {
    generic_tree_map_iterator_t iter;
    generic_tree_map_iterator_t last;
    generic_tree_map_t gtm;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    generic_tree_map_data_t *d;
    const unsigned long long *k;
    unsigned long long *v;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_data_manager_t *gvm = ulonglong_data_manager();
    const generic_tree_map_api_t *api = generic_tree_map_api();
    unsigned long long data[size];

    api->construct(&gtm, std_memory_manager(), gkm, gvm);

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&gtm, &i, &j);
    }

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&gtm, &i, &j);
    }

    assert(api->size(&gtm) == size);

    i = 0;
    assert(api->count(&gtm, &i) == 1);
    assert(api->remove(&gtm, &i) == 1);
    assert(api->count(&gtm, &i) == 0);

    assert(api->size(&gtm) == size - 1);

    i = 1;
    iter = api->find(&gtm, &i);
    d = iter.api->deref(&iter);
    k = (const unsigned long long *)(d->key);
    v = (unsigned long long *)(d->value);
    assert(*k == i && *v == i + 1);
    api->erase(&gtm, &iter);
    assert(!api->count(&gtm, &i));

    assert(api->size(&gtm) == size - 2);

    i = 2;
    v = (unsigned long long *)(api->at(&gtm, &i));
    assert(*v == i + 1);

    api->clear(&gtm);

    assert(api->size(&gtm) == 0);

    for (i = 0; i < size; ++i) {
        data[i] = i;
    }
    for (i = 0; i < size; ++i) {
        api->insert(&gtm, &i, &i);
    }
    i = 0;
    iter = api->begin(&gtm);
    last = api->end(&gtm);
    while (!iter.api->equal(&iter, &last)) {
        d = iter.api->deref(&iter);
        k = (const unsigned long long *)(d->key);
        assert(*k == data[i]);
        ++i;
        iter.api->next(&iter);
    }

    api->destruct(&gtm);
}

static void test_tree_multimap() {
    generic_tree_multimap_iterator_t iter;
    generic_tree_multimap_iterator_t last;
    generic_tree_multimap_t gtm;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    generic_tree_multimap_data_t *d;
    const unsigned long long *k;
    unsigned long long *v;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_data_manager_t *gvm = ulonglong_data_manager();
    const generic_tree_multimap_api_t *api = generic_tree_multimap_api();
    unsigned long long data[2 * size];

    api->construct(&gtm, std_memory_manager(), gkm, gvm);

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&gtm, &i, &j);
    }

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&gtm, &i, &j);
    }

    assert(api->size(&gtm) == 2 * size);

    i = 0;
    assert(api->count(&gtm, &i) == 2);
    assert(api->remove(&gtm, &i) == 2);
    assert(api->count(&gtm, &i) == 0);
    assert(api->size(&gtm) == 2 * size - 2);

    i = 1;
    iter = api->find(&gtm, &i);
    d = iter.api->deref(&iter);
    k = (const unsigned long long *)(d->key);
    v = (unsigned long long *)(d->value);
    assert(*k == i && *v == i + 1);
    api->erase(&gtm, &iter);
    assert(api->count(&gtm, &i));
    iter = api->find(&gtm, &i);
    api->erase(&gtm, &iter);
    assert(!api->count(&gtm, &i));
    assert(api->size(&gtm) == 2 * size - 4);

    j = 0;
    i = 2;
    api->equal_range(&gtm, &i, &iter, &last);
    while (!iter.api->equal(&iter, &last)) {
        d = iter.api->deref(&iter);
        k = (const unsigned long long *)(d->key);
        assert(*k == i);
        iter.api->next(&iter);
        ++j;
    }
    assert(j == 2);

    api->clear(&gtm);

    assert(api->size(&gtm) == 0);

    for (i = 0; i < size; ++i) {
        data[2 * i] = i;
        data[2 * i + 1] = i;
    }
    for (i = 0; i < size; ++i) {
        api->insert(&gtm, &i, &i);
    }
    for (i = 0; i < size; ++i) {
        api->insert(&gtm, &i, &i);
    }
    i = 0;
    iter = api->begin(&gtm);
    last = api->end(&gtm);
    while (!iter.api->equal(&iter, &last)) {
        d = iter.api->deref(&iter);
        k = (const unsigned long long *)(d->key);
        assert(*k == data[i]);
        ++i;
        iter.api->next(&iter);
    }

    api->destruct(&gtm);
}

int main(int argc, char *argv[]) {
    test_tree_map();
    test_tree_multimap();

    return 0;
}

