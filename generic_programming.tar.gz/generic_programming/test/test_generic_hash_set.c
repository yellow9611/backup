#include <stddef.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_hash_set.h"

static size_t ulonglong_hash(const void *key) {
    return *(const unsigned long long *)(key);
}

static void test_hash_set() {
    generic_hash_set_iterator_t iter;
    generic_hash_set_t ghs;
    const unsigned long long size = 100ull;
    unsigned long long i;
    const unsigned long long *k;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_hash_set_api_t *api = generic_hash_set_api();

    api->construct(&ghs, 10, std_memory_manager(), gkm, ulonglong_hash);

    for (i = 0; i < size; ++i) {
        api->insert(&ghs, &i);
    }

    for (i = 0; i < size; ++i) {
        api->insert(&ghs, &i);
    }

    assert(api->size(&ghs) == size);

    i = 0;
    assert(api->count(&ghs, &i) == 1);
    assert(api->remove(&ghs, &i) == 1);
    assert(api->count(&ghs, &i) == 0);

    assert(api->size(&ghs) == size - 1);

    i = 1;
    iter = api->find(&ghs, &i);
    k = (const unsigned long long *)(iter.api->deref(&iter));
    assert(*k == i);
    api->erase(&ghs, &iter);
    assert(!api->count(&ghs, &i));

    assert(api->size(&ghs) == size - 2);

    api->clear(&ghs);

    assert(api->size(&ghs) == 0);

    api->destruct(&ghs);
}

static void test_hash_multiset() {
    generic_hash_multiset_iterator_t iter;
    generic_hash_multiset_iterator_t last;
    generic_hash_multiset_t ghs;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    const unsigned long long *k;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_hash_multiset_api_t *api = generic_hash_multiset_api();
    
    api->construct(&ghs, 10, std_memory_manager(), gkm, ulonglong_hash);

    for (i = 0; i < size; ++i) {
        api->insert(&ghs, &i);
    }

    for (i = 0; i < size; ++i) {
        api->insert(&ghs, &i);
    }

    assert(api->size(&ghs) == 2 * size);

    i = 0;
    assert(api->count(&ghs, &i) == 2);
    assert(api->remove(&ghs, &i) == 2);
    assert(api->count(&ghs, &i) == 0);
    assert(api->size(&ghs) == 2 * size - 2);

    i = 1;
    iter = api->find(&ghs, &i);
    k = (const unsigned long long *)(iter.api->deref(&iter));
    assert(*k == i);
    api->erase(&ghs, &iter);
    assert(api->count(&ghs, &i));
    iter = api->find(&ghs, &i);
    api->erase(&ghs, &iter);
    assert(!api->count(&ghs, &i));
    assert(api->size(&ghs) == 2 * size - 4);

    i = 2;
    j = 0;
    api->equal_range(&ghs, &i, &iter, &last);
    while (!iter.api->equal(&iter, &last)) {
        k = (const unsigned long long *)(iter.api->deref(&iter));
        assert(*k == i);
        iter.api->next(&iter);
        ++j;
    }
    assert(j == 2);

    api->clear(&ghs);

    assert(api->size(&ghs) == 0);

    api->destruct(&ghs);
}

int main(int argc, char *argv[]) {
    test_hash_set();
    test_hash_multiset();

    return 0;
}

