#include <stddef.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_config.h"
#include "../generic_forward_list.h"
#include "../generic_list.h"
#include "../generic_hash_table.h"
#include "../generic_tree_table.h"

#define universal 8

static void test_forward_list_32(void) {
    size_t size;
    generic_data_manager_t gdm;
    generic_forward_list_t gfl;
    gfl.gdm = &gdm;

    size_t data_offset[universal + 1] = {
        0, /* dummy */
        0, 0, 0, 0, 0, 0, 0, 4
    };

    size_t item_size[universal + 1] = {
        sizeof(void *) + 1, /* dummy */
        sizeof(void *) + 1, sizeof(void *) + 2, sizeof(void *) + 3, sizeof(void *) + 4,
        sizeof(void *) + 5, sizeof(void *) + 6, sizeof(void *) + 7, 2 * sizeof(void *) + 8
    };

    for (size = 1; size <= universal; ++size) {
        gdm.size = size;
        generic_forward_list_config(&gfl);
        assert(gfl.data_offset == data_offset[size]);
        assert(gfl.item_size == item_size[size]);
    }
}

static void test_forward_list_64(void) {
    size_t size;
    generic_data_manager_t gdm;
    generic_forward_list_t gfl;
    gfl.gdm = &gdm;

    size_t data_offset[universal + 1] = {
        0, /* dummy */
        0, 0, 0, 0, 0, 0, 0, 0
    };

    size_t item_size[universal + 1] = {
        sizeof(void *) + 1, /* dummy */
        sizeof(void *) + 1, sizeof(void *) + 2, sizeof(void *) + 3, sizeof(void *) + 4,
        sizeof(void *) + 5, sizeof(void *) + 6, sizeof(void *) + 7, sizeof(void *) + 8
    };

    for (size = 1; size <= universal; ++size) {
        gdm.size = size;
        generic_forward_list_config(&gfl);
        assert(gfl.data_offset == data_offset[size]);
        assert(gfl.item_size == item_size[size]);
    }
}

static void test_forward_list(void) {
    if (sizeof(void *) == 4) {
        test_forward_list_32();
    } else if (sizeof(void *) == 8) {
        test_forward_list_64();
    } else { /* skip */
    }
}

static void test_list(void) {
    size_t size;
    generic_data_manager_t gdm;
    generic_list_t gl;
    gl.gdm = &gdm;

    size_t data_offset[universal + 1] = {
        0, /* dummy */
        0, 0, 0, 0, 0, 0, 0, 0
    };

    size_t item_size[universal + 1] = {
        2 * sizeof(void *) + 1, /* dummy */
        2 * sizeof(void *) + 1, 2 * sizeof(void *) + 2, 2 * sizeof(void *) + 3, 2 * sizeof(void *) + 4,
        2 * sizeof(void *) + 5, 2 * sizeof(void *) + 6, 2 * sizeof(void *) + 7, 2 * sizeof(void *) + 8
    };

    if (sizeof(void *) != 4 && sizeof(void *) != 8) {
        return;
    }

    for (size = 1; size <= universal; ++size) {
        gdm.size = size;
        generic_list_config(&gl);
        assert(gl.data_offset == data_offset[size]);
        assert(gl.item_size == item_size[size]);
    }
}

static void test_hash_table_32(void) {
    size_t key_size;
    size_t value_size;
    generic_data_manager_t gkm;
    generic_data_manager_t gvm;
    generic_hash_table_t ght;

    size_t key_offset[universal + 1] = {
        0, /* dummy */
        0, 0, 0, 0, 0, 0, 0, 4
    };
    size_t value_offset[universal + 1][universal + 1] = {
        { 0 }, /* dummy */
        {
            1, /* equivalent to hash table without value */
            1, 2, 2, 4, 4, 4, 4, 4
        }, /* key size: 1 */
        {
            2,
            2, 2, 2, 4, 4, 4, 4, 4
        }, /* key size: 2 */
        {
            3,
            3, 4, 4, 4, 4, 4, 4, 4
        }, /* key size: 3 */
        {
            4,
            4, 4, 4, 4, 4, 4, 4, 4
        }, /* key size: 4 */
        {
            5,
            5, 6, 6, 8, 8, 8, 8, 12
        }, /* key size: 5 */
        {
            6,
            6, 6, 6, 8, 8, 8, 8, 12
        }, /* key size: 6 */
        {
            7,
            7, 8, 8, 8, 8, 8, 8, 12
        }, /* key size: 7 */
        {
            12,
            12, 12, 12, 12, 12, 12, 12, 12
        } /* key size: 8 */
    };
    size_t item_size[universal + 1][universal + 1];
    for (key_size = 1; key_size <= universal; ++key_size) {
        for (value_size = 0; value_size <= universal; ++value_size) {
            item_size[key_size][value_size] = sizeof(void *) + value_offset[key_size][value_size] + value_size;
        }
    }

    ght.gkm = &gkm;
    ght.gvm = &gvm;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        for (value_size = 1; value_size <= universal; ++value_size) {
            gvm.size = value_size;
            generic_hash_table_config(&ght);
            assert(ght.key_offset == key_offset[key_size]);
            assert(ght.value_offset == value_offset[key_size][value_size]);
            assert(ght.item_size == item_size[key_size][value_size]);
        }
    }

    ght.gkm = &gkm;
    ght.gvm = 0;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        generic_hash_table_config(&ght);
        assert(ght.key_offset == key_offset[key_size]);
        assert(ght.item_size == item_size[key_size][0]);
    }
}

static void test_hash_table_64(void) {
    size_t key_size;
    size_t value_size;
    generic_data_manager_t gkm;
    generic_data_manager_t gvm;
    generic_hash_table_t ght;

    size_t key_offset[universal + 1] = {
        0, /* dummy */
        0, 0, 0, 0, 0, 0, 0, 0
    };
    size_t value_offset[universal + 1][universal + 1] = {
        { 0 }, /* dummy */
        {
            1, /* equivalent to hash table without value */
            1, 2, 2, 4, 4, 4, 4, 8
        }, /* key size: 1 */
        {
            2,
            2, 2, 2, 4, 4, 4, 4, 8
        }, /* key size: 2 */
        {
            3,
            3, 4, 4, 4, 4, 4, 4, 8
        }, /* key size: 3 */
        {
            4,
            4, 4, 4, 4, 4, 4, 4, 8
        }, /* key size: 4 */
        {
            5,
            5, 6, 6, 8, 8, 8, 8, 8
        }, /* key size: 5 */
        {
            6,
            6, 6, 6, 8, 8, 8, 8, 8
        }, /* key size: 6 */
        {
            7,
            7, 8, 8, 8, 8, 8, 8, 8
        }, /* key size: 7 */
        {
            8,
            8, 8, 8, 8, 8, 8, 8, 8
        } /* key size: 8 */
    };
    size_t item_size[universal + 1][universal + 1];
    for (key_size = 1; key_size <= universal; ++key_size) {
        for (value_size = 0; value_size <= universal; ++value_size) {
            item_size[key_size][value_size] = sizeof(void *) + value_offset[key_size][value_size] + value_size;
        }
    }

    ght.gkm = &gkm;
    ght.gvm = &gvm;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        for (value_size = 1; value_size <= universal; ++value_size) {
            gvm.size = value_size;
            generic_hash_table_config(&ght);
            assert(ght.key_offset == key_offset[key_size]);
            assert(ght.value_offset == value_offset[key_size][value_size]);
            assert(ght.item_size == item_size[key_size][value_size]);
        }
    }

    ght.gkm = &gkm;
    ght.gvm = 0;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        generic_hash_table_config(&ght);
        assert(ght.key_offset == key_offset[key_size]);
        assert(ght.item_size == item_size[key_size][0]);
    }
}

static void test_hash_table(void) {
    if (sizeof(void *) == 4) {
        test_hash_table_32();
    } else if (sizeof(void *) == 8) {
        test_hash_table_64();
    } else { /* skip */
    }
}

static void test_tree_table_32(void) {
    size_t key_size;
    size_t value_size;
    generic_data_manager_t gkm;
    generic_data_manager_t gvm;
    generic_tree_table_t gtt;
    size_t base = offsetof(generic_tree_table_item_t, data);

    size_t key_offset[universal + 1] = {
        0, /* dummy */
        0, 1, 1, 3, 3, 3, 3, 3
    };
    size_t value_offset[universal + 1][universal + 1] = {
        { 0 }, /* dummy */
        {
            1, /* equivalent to tree table without value */
            1, 1, 1, 3, 3, 3, 3, 3
        }, /* key size: 1 */
        {
            3,
            3, 3, 3, 3, 3, 3, 3, 3
        }, /* key size: 2 */
        {
            4,
            4, 5, 5, 7, 7, 7, 7, 11
        }, /* key size: 3 */
        {
            7,
            7, 7, 7, 7, 7, 7, 7, 11
        }, /* key size: 4 */
        {
            8,
            8, 9, 9, 11, 11, 11, 11, 11
        }, /* key size: 5 */
        {
            9,
            9, 9, 9, 11, 11, 11, 11, 11
        }, /* key size: 6 */
        {
            10,
            10, 11, 11, 11, 11, 11, 11, 11
        }, /* key size: 7 */
        {
            11,
            11, 11, 11, 11, 11, 11, 11, 11
        } /* key size: 8 */
    };
    size_t item_size[universal + 1][universal + 1];
    for (key_size = 1; key_size <= universal; ++key_size) {
        for (value_size = 0; value_size <= universal; ++value_size) {
            item_size[key_size][value_size] = base + value_offset[key_size][value_size] + value_size;
        }
    }

    gtt.gkm = &gkm;
    gtt.gvm = &gvm;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        for (value_size = 1; value_size <= universal; ++value_size) {
            gvm.size = value_size;
            generic_tree_table_config(&gtt);
            assert(gtt.key_offset == key_offset[key_size]);
            assert(gtt.value_offset == value_offset[key_size][value_size]);
            assert(gtt.item_size == item_size[key_size][value_size]);
        }
    }

    gtt.gkm = &gkm;
    gtt.gvm = 0;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        generic_tree_table_config(&gtt);
        assert(gtt.key_offset == key_offset[key_size]);
        assert(gtt.item_size == item_size[key_size][0]);
    }
}

static void test_tree_table_64(void) {
    size_t key_size;
    size_t value_size;
    generic_data_manager_t gkm;
    generic_data_manager_t gvm;
    generic_tree_table_t gtt;
    size_t base = offsetof(generic_tree_table_item_t, data);

    size_t key_offset[universal + 1] = {
        0, /* dummy */
        0, 1, 1, 3, 3, 3, 3, 7
    };
    size_t value_offset[universal + 1][universal + 1] = {
        { 0 }, /* dummy */
        {
            1, /* equivalent to tree table without value */
            1, 1, 1, 3, 3, 3, 3, 7
        }, /* key size: 1 */
        {
            3,
            3, 3, 3, 3, 3, 3, 3, 7
        }, /* key size: 2 */
        {
            4,
            4, 5, 5, 7, 7, 7, 7, 7
        }, /* key size: 3 */
        {
            7,
            7, 7, 7, 7, 7, 7, 7, 7
        }, /* key size: 4 */
        {
            8,
            8, 9, 9, 11, 11, 11, 11, 15
        }, /* key size: 5 */
        {
            9,
            9, 9, 9, 11, 11, 11, 11, 15
        }, /* key size: 6 */
        {
            10,
            10, 11, 11, 11, 11, 11, 11, 15
        }, /* key size: 7 */
        {
            15,
            15, 15, 15, 15, 15, 15, 15, 15
        } /* key size: 8 */
    };
    size_t item_size[universal + 1][universal + 1];
    for (key_size = 1; key_size <= universal; ++key_size) {
        for (value_size = 0; value_size <= universal; ++value_size) {
            item_size[key_size][value_size] = base + value_offset[key_size][value_size] + value_size;
        }
    }

    gtt.gkm = &gkm;
    gtt.gvm = &gvm;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        for (value_size = 1; value_size <= universal; ++value_size) {
            gvm.size = value_size;
            generic_tree_table_config(&gtt);
            assert(gtt.key_offset == key_offset[key_size]);
            assert(gtt.value_offset == value_offset[key_size][value_size]);
            assert(gtt.item_size == item_size[key_size][value_size]);
        }
    }

    gtt.gkm = &gkm;
    gtt.gvm = 0;
    for (key_size = 1; key_size <= universal; ++key_size) {
        gkm.size = key_size;
        generic_tree_table_config(&gtt);
        assert(gtt.key_offset == key_offset[key_size]);
        assert(gtt.item_size == item_size[key_size][0]);
    }
}

static void test_tree_table(void) {
    if (sizeof(void *) == 4) {
        test_tree_table_32();
    } else if (sizeof(void *) == 8) {
        test_tree_table_64();
    } else { /* skip */
    }
}

int main(int argc, char *argv[]) {
    test_forward_list();
    test_list();
    test_hash_table();
    test_tree_table();
    return 0;
}

