#include <stddef.h>
#include <assert.h>
#include "../generic_utility.h"
#include "../generic_hash_map.h"

static size_t ulonglong_hash(const void *key) {
    return *(const unsigned long long *)(key);
}

static void test_hash_map() {
    generic_hash_map_iterator_t iter;
    generic_hash_map_t ghm;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    generic_hash_map_data_t *d;
    const unsigned long long *k;
    unsigned long long *v;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_data_manager_t *gvm = ulonglong_data_manager();
    const generic_hash_map_api_t *api = generic_hash_map_api();

    api->construct(&ghm, 10, std_memory_manager(), gkm, gvm, ulonglong_hash);

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&ghm, &i, &j);
    }

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&ghm, &i, &j);
    }

    assert(api->size(&ghm) == size);

    i = 0;
    assert(api->count(&ghm, &i) == 1);
    assert(api->remove(&ghm, &i) == 1);
    assert(api->count(&ghm, &i) == 0);

    assert(api->size(&ghm) == size - 1);

    i = 1;
    iter = api->find(&ghm, &i);
    d = iter.api->deref(&iter);
    k = (const unsigned long long *)(d->key);
    v = (unsigned long long *)(d->value);
    assert(*k == i && *v == i + 1);
    api->erase(&ghm, &iter);
    assert(!api->count(&ghm, &i));
    assert(api->size(&ghm) == size - 2);

    i = 2;
    v = (unsigned long long *)(api->at(&ghm, &i));
    assert(*v == i + 1);

    api->clear(&ghm);

    assert(api->size(&ghm) == 0);

    api->destruct(&ghm);
}

static void test_hash_multimap() {
    size_t bucket_count;
    generic_hash_multimap_iterator_t iter;
    generic_hash_multimap_iterator_t last;
    generic_hash_multimap_local_iterator_t local_iter;
    generic_hash_multimap_local_iterator_t local_last;
    generic_hash_multimap_t ghm;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long j;
    generic_hash_multimap_data_t *d;
    const unsigned long long *k;
    unsigned long long *v;
    const generic_data_manager_t *gkm = ulonglong_data_manager();
    const generic_data_manager_t *gvm = ulonglong_data_manager();
    const generic_hash_multimap_api_t *api = generic_hash_multimap_api();

    api->construct(&ghm, 10, std_memory_manager(), gkm, gvm, ulonglong_hash);

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&ghm, &i, &j);
    }

    for (i = 0; i < size; ++i) {
        j = i + 1;
        api->insert(&ghm, &i, &j);
    }

    assert(api->size(&ghm) == 2 * size);

    i = 0;
    assert(api->count(&ghm, &i) == 2);
    assert(api->remove(&ghm, &i) == 2);
    assert(api->count(&ghm, &i) == 0);
    assert(api->size(&ghm) == 2 * size - 2);

    i = 1;
    iter = api->find(&ghm, &i);
    d = iter.api->deref(&iter);
    k = (const unsigned long long *)(d->key);
    v = (unsigned long long *)(d->value);
    assert(*k == i && *v == i + 1);
    api->erase(&ghm, &iter);
    assert(api->count(&ghm, &i));
    iter = api->find(&ghm, &i);
    api->erase(&ghm, &iter);
    assert(!api->count(&ghm, &i));
    assert(api->size(&ghm) == 2 * size - 4);

    bucket_count = api->bucket_count(&ghm);
    api->set_max_load_factor(&ghm, api->get_max_load_factor(&ghm) / 2);
    assert(api->bucket_count(&ghm) > bucket_count);

    j = 0;
    i = 2;
    bucket_count = api->bucket_count(&ghm);
    if (bucket_count > i) {
        size_t bucket = api->bucket(&ghm, &i);
        assert(bucket == 2);
        assert(api->bucket_size(&ghm, bucket) == 2);
        local_iter = api->local_begin(&ghm, bucket);
        local_last = api->local_end(&ghm, bucket);
        while (!local_iter.api->equal(&local_iter, &local_last)) {
            d = local_iter.api->deref(&local_iter);
            k = (const unsigned long long *)(d->key);
            assert(*k == i);
            local_iter.api->next(&local_iter);
            ++j;
        }
        assert(j == 2);
    }

    j = 0;
    i = 2;
    api->equal_range(&ghm, &i, &iter, &last);
    while (!iter.api->equal(&iter, &last)) {
        d = iter.api->deref(&iter);
        k = (const unsigned long long *)(d->key);
        assert(*k == i);
        iter.api->next(&iter);
        ++j;
    }
    assert(j == 2);

    api->clear(&ghm);

    assert(api->size(&ghm) == 0);

    api->destruct(&ghm);
}

int main(int argc, char *argv[]) {
    test_hash_map();
    test_hash_multimap();

    return 0;
}

