#include <assert.h>
#include "../generic_utility.h"
#include "../generic_vector.h"

int main(int argc, char *argv[]) {
    generic_vector_iterator_t iter, last;
    generic_vector_t gv;
    const unsigned long long size = 100ull;
    unsigned long long i;
    unsigned long long *p;
    const generic_vector_api_t *api = generic_vector_api();

    api->construct(&gv, std_memory_manager(), ulonglong_data_manager());

    for (i = 0; i < size; ++i) {
        api->push_back(&gv, &i);
    }

    assert(api->size(&gv) == size);

    iter = api->begin(&gv);
    last = api->end(&gv);
    i = 0;
    while (!iter.api->equal(&iter, &last)) {
        p = (unsigned long long *)(iter.api->deref(&iter));
        assert(i == *p);
        iter.api->next(&iter);
        ++i;
    }
    assert(i == size);

    i = size;
    while (!api->empty(&gv)) {
        --i;
        p = (unsigned long long *)(api->back(&gv));
        assert(i == *p);
        api->pop_back(&gv);
    }
    assert(i == 0);

    assert(api->size(&gv) == 0);

    i = 1;
    api->push_back(&gv, &i);
    i = 2;
    api->push_back(&gv, &i);

    p = (unsigned long long *)(api->front(&gv));
    assert (1 == *p);

    api->clear(&gv);
    assert(api->size(&gv) == 0);

    for (i = 0; i < size; ++i) {
        api->push_back(&gv, &i);
    }
    iter = api->begin(&gv);
    iter.api->move(&iter, 10);
    p = (unsigned long long *)(iter.api->deref(&iter));
    assert(*p == 10);
    iter.api->move(&iter, -5);
    p = (unsigned long long *)(iter.api->deref(&iter));
    assert(*p == 5);

    api->destruct(&gv);
    
    return 0;
}

