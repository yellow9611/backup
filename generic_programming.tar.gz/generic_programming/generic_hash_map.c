/** @addtogroup GenericHashMap */

/** @{ */

/**
 * @file
 * @brief Implementation of hash map and hash multimap.
 */

#include "generic_hash_map.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void
generic_hash_map_iterator_next(generic_hash_map_iterator_t *iter) {
    generic_hash_table_iterator_next(&iter->imp);
}

static generic_hash_map_data_t *
generic_hash_map_iterator_deref(generic_hash_map_iterator_t *iter) {
    return (generic_hash_map_data_t *)(generic_hash_table_iterator_deref(&iter->imp));
}

static int
generic_hash_map_iterator_equal(const generic_hash_map_iterator_t *lhs,
        const generic_hash_map_iterator_t *rhs) {
    return generic_hash_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_map_iterator_category(void) {
    return generic_hash_table_iterator_category();
}

static size_t generic_hash_map_iterator_size(void) {
    return sizeof(generic_hash_map_iterator_t);
}

static generic_hash_map_iterator_api_t g_generic_hash_map_iterator_api = {
    &generic_hash_map_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_map_iterator_deref,
    &generic_hash_map_iterator_equal,
    0, /* sub */
    &generic_hash_map_iterator_category,
    &generic_hash_map_iterator_size
};

static inline void
generic_hash_map_iterator_init(generic_hash_map_iterator_t *iter) {
    iter->api = &g_generic_hash_map_iterator_api;
}

static void
generic_hash_map_local_iterator_next(generic_hash_map_local_iterator_t *iter) {
    generic_hash_table_local_iterator_next(&iter->imp);
}

static generic_hash_map_data_t *
generic_hash_map_local_iterator_deref(generic_hash_map_local_iterator_t *iter) {
    return (generic_hash_map_data_t *)(generic_hash_table_local_iterator_deref(&iter->imp));
}

static int
generic_hash_map_local_iterator_equal(const generic_hash_map_local_iterator_t *lhs,
        const generic_hash_map_local_iterator_t *rhs) {
    return generic_hash_table_local_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_map_local_iterator_category(void) {
    return generic_hash_table_local_iterator_category();
}

static size_t generic_hash_map_local_iterator_size(void) {
    return sizeof(generic_hash_map_local_iterator_t);
}

static generic_hash_map_local_iterator_api_t g_generic_hash_map_local_iterator_api = {
    &generic_hash_map_local_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_map_local_iterator_deref,
    &generic_hash_map_local_iterator_equal,
    0, /* sub */
    &generic_hash_map_local_iterator_category,
    &generic_hash_map_local_iterator_size
};

static inline void
generic_hash_map_local_iterator_init(generic_hash_map_local_iterator_t *iter) {
    iter->api = &g_generic_hash_map_local_iterator_api;
}

static int generic_hash_map_construct(generic_hash_map_t *ghm,
        size_t bucket_hint, generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm,
        generic_hash_fp_t hash) {
    return generic_hash_table_construct(&ghm->imp, bucket_hint,
            gmm, gkm, gvm, hash, 1 /* unique */);
}

static void generic_hash_map_destruct(generic_hash_map_t *ghm) {
    generic_hash_table_destruct(&ghm->imp);
}

static size_t generic_hash_map_size(const generic_hash_map_t *ghm) {
    return generic_hash_table_size(&ghm->imp);
}

static int generic_hash_map_empty(const generic_hash_map_t *ghm) {
    return generic_hash_table_empty(&ghm->imp);
}

static generic_hash_map_iterator_t
generic_hash_map_begin(generic_hash_map_t *ghm) {
    generic_hash_map_iterator_t ret;
    generic_hash_map_iterator_init(&ret);
    generic_hash_table_begin(&ghm->imp, &ret.imp);
    return ret;
}

static generic_hash_map_iterator_t
generic_hash_map_end(generic_hash_map_t *ghm) {
    generic_hash_map_iterator_t ret;
    generic_hash_map_iterator_init(&ret);
    generic_hash_table_end(&ghm->imp, &ret.imp);
    return ret;
}

static generic_hash_map_iterator_t
generic_hash_map_find(generic_hash_map_t *ghm, const void *key) {
    generic_hash_map_iterator_t ret;
    generic_hash_map_iterator_init(&ret);
    generic_hash_table_find(&ghm->imp, key, &ret.imp);
    return ret;
}

static size_t generic_hash_map_count(const generic_hash_map_t *ghm,
        const void *key) {
    return generic_hash_table_count(&ghm->imp, key);
}

static void generic_hash_map_equal_range(generic_hash_map_t *ghm,
        const void *key, generic_hash_map_iterator_t *first,
        generic_hash_map_iterator_t *last) {
    generic_hash_map_iterator_init(first);
    generic_hash_map_iterator_init(last);
    generic_hash_table_equal_range(&ghm->imp, key, &first->imp, &last->imp);
}

static void *generic_hash_map_at(generic_hash_map_t *ghm, const void *key) {
    generic_hash_map_data_t *data;
    generic_hash_map_iterator_t iter;
    generic_hash_map_iterator_t end;

    iter = generic_hash_map_find(ghm, key);
    end = generic_hash_map_end(ghm);
    if (generic_hash_map_iterator_equal(&iter, &end)) {
        return 0;
    }

    data = generic_hash_map_iterator_deref(&iter);
    return data->value;
}

static generic_hash_map_local_iterator_t
generic_hash_map_local_begin(generic_hash_map_t *ghm, size_t bucket) {
    generic_hash_map_local_iterator_t ret;
    generic_hash_map_local_iterator_init(&ret);
    generic_hash_table_local_begin(&ghm->imp, bucket, &ret.imp);
    return ret;
}

static generic_hash_map_local_iterator_t
generic_hash_map_local_end(generic_hash_map_t *ghm, size_t bucket) {
    generic_hash_map_local_iterator_t ret;
    generic_hash_map_local_iterator_init(&ret);
    generic_hash_table_local_end(&ghm->imp, bucket, &ret.imp);
    return ret;
}

static size_t generic_hash_map_bucket_count(const generic_hash_map_t *ghm) {
    return generic_hash_table_bucket_count(&ghm->imp);
}

static size_t generic_hash_map_bucket_size(const generic_hash_map_t *ghm,
        size_t bucket) {
    return generic_hash_table_bucket_size(&ghm->imp, bucket);
}

static size_t generic_hash_map_bucket(const generic_hash_map_t *ghm,
        const void *key) {
    return generic_hash_table_bucket(&ghm->imp, key);
}

static float generic_hash_map_load_factor(const generic_hash_map_t *ghm) {
    return generic_hash_table_load_factor(&ghm->imp);
}

static float
generic_hash_map_get_max_load_factor(const generic_hash_map_t *ghm) {
    return generic_hash_table_get_max_load_factor(&ghm->imp);
}

static int generic_hash_map_set_max_load_factor(generic_hash_map_t *ghm,
        float max_load_factor) {
    return generic_hash_table_set_max_load_factor(&ghm->imp, max_load_factor);
}

static generic_hash_map_iterator_t
generic_hash_map_insert(generic_hash_map_t *ghm,
        const void *key, const void *value) {
    generic_hash_map_iterator_t ret;
    generic_hash_map_iterator_init(&ret);
    generic_hash_table_insert(&ghm->imp, key, value, &ret.imp);
    return ret;
}

static generic_hash_map_iterator_t
generic_hash_map_erase(generic_hash_map_t *ghm,
        const generic_hash_map_iterator_t *iter) {
    generic_hash_map_iterator_t ret;
    generic_hash_map_iterator_init(&ret);
    generic_hash_table_erase(&ghm->imp, &iter->imp, &ret.imp);
    return ret;
}

static generic_hash_map_local_iterator_t
generic_hash_map_lerase(generic_hash_map_t *ghm,
        const generic_hash_map_local_iterator_t *iter) {
    generic_hash_map_local_iterator_t ret;
    generic_hash_map_local_iterator_init(&ret);
    generic_hash_table_lerase(&ghm->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_hash_map_remove(generic_hash_map_t *ghm,
        const void *key) {
    return generic_hash_table_remove(&ghm->imp, key);
}

static void generic_hash_map_clear(generic_hash_map_t *ghm) {
    generic_hash_table_clear(&ghm->imp);
}

static generic_memory_manager_t *
generic_hash_map_memory_manager(const generic_hash_map_t *ghm) {
    return generic_hash_table_memory_manager(&ghm->imp);
}

static const generic_data_manager_t *
generic_hash_map_key_manager(const generic_hash_map_t *ghm) {
    return generic_hash_table_key_manager(&ghm->imp);
}

static const generic_data_manager_t *
generic_hash_map_value_manager(const generic_hash_map_t *ghm) {
    return generic_hash_table_value_manager(&ghm->imp);
}

static generic_hash_fp_t
generic_hash_map_hash(const generic_hash_map_t *ghm) {
    return generic_hash_table_hash(&ghm->imp);
}

static generic_hash_map_api_t g_generic_hash_map_api = {
    &generic_hash_map_construct,
    &generic_hash_map_destruct,
    &generic_hash_map_size,
    &generic_hash_map_empty,
    &generic_hash_map_begin,
    &generic_hash_map_end,
    &generic_hash_map_find,
    &generic_hash_map_count,
    &generic_hash_map_equal_range,
    &generic_hash_map_at,
    &generic_hash_map_local_begin,
    &generic_hash_map_local_end,
    &generic_hash_map_bucket_count,
    &generic_hash_map_bucket_size,
    &generic_hash_map_bucket,
    &generic_hash_map_load_factor,
    &generic_hash_map_get_max_load_factor,
    &generic_hash_map_set_max_load_factor,
    &generic_hash_map_insert,
    &generic_hash_map_erase,
    &generic_hash_map_lerase,
    &generic_hash_map_remove,
    &generic_hash_map_clear,
    &generic_hash_map_memory_manager,
    &generic_hash_map_key_manager,
    &generic_hash_map_value_manager,
    &generic_hash_map_hash
};

static void
generic_hash_multimap_iterator_next(generic_hash_multimap_iterator_t *iter) {
    generic_hash_table_iterator_next(&iter->imp);
}

static generic_hash_multimap_data_t *
generic_hash_multimap_iterator_deref(generic_hash_multimap_iterator_t *iter) {
    return (generic_hash_multimap_data_t *)(generic_hash_table_iterator_deref(&iter->imp));
}

static int
generic_hash_multimap_iterator_equal(const generic_hash_multimap_iterator_t *lhs,
        const generic_hash_multimap_iterator_t *rhs) {
    return generic_hash_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_multimap_iterator_category(void) {
    return generic_hash_table_iterator_category();
}

static size_t generic_hash_multimap_iterator_size(void) {
    return sizeof(generic_hash_multimap_iterator_t);
}

static generic_hash_multimap_iterator_api_t g_generic_hash_multimap_iterator_api = {
    &generic_hash_multimap_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_multimap_iterator_deref,
    &generic_hash_multimap_iterator_equal,
    0, /* sub */
    &generic_hash_multimap_iterator_category,
    &generic_hash_multimap_iterator_size
};

static inline void
generic_hash_multimap_iterator_init(generic_hash_multimap_iterator_t *iter) {
    iter->api = &g_generic_hash_multimap_iterator_api;
}

static void
generic_hash_multimap_local_iterator_next(generic_hash_multimap_local_iterator_t *iter) {
    generic_hash_table_local_iterator_next(&iter->imp);
}

static generic_hash_multimap_data_t *
generic_hash_multimap_local_iterator_deref(generic_hash_multimap_local_iterator_t *iter) {
    return (generic_hash_multimap_data_t *)(generic_hash_table_local_iterator_deref(&iter->imp));
}

static int
generic_hash_multimap_local_iterator_equal(const generic_hash_multimap_local_iterator_t *lhs,
        const generic_hash_multimap_local_iterator_t *rhs) {
    return generic_hash_table_local_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_multimap_local_iterator_category(void) {
    return generic_hash_table_local_iterator_category();
}

static size_t generic_hash_multimap_local_iterator_size(void) {
    return sizeof(generic_hash_multimap_local_iterator_t);
}

static generic_hash_multimap_local_iterator_api_t g_generic_hash_multimap_local_iterator_api = {
    &generic_hash_multimap_local_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_multimap_local_iterator_deref,
    &generic_hash_multimap_local_iterator_equal,
    0, /* sub */
    &generic_hash_multimap_local_iterator_category,
    &generic_hash_multimap_local_iterator_size
};

static inline void
generic_hash_multimap_local_iterator_init(generic_hash_multimap_local_iterator_t *iter) {
    iter->api = &g_generic_hash_multimap_local_iterator_api;
}

static int generic_hash_multimap_construct(generic_hash_multimap_t *ghm,
        size_t bucket_hint, generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm,
        generic_hash_fp_t hash) {
    return generic_hash_table_construct(&ghm->imp, bucket_hint,
            gmm, gkm, gvm, hash, 0 /* not unique */);
}

static void generic_hash_multimap_destruct(generic_hash_multimap_t *ghm) {
    generic_hash_table_destruct(&ghm->imp);
}

static size_t
generic_hash_multimap_size(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_size(&ghm->imp);
}

static int
generic_hash_multimap_empty(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_empty(&ghm->imp);
}

static generic_hash_multimap_iterator_t
generic_hash_multimap_begin(generic_hash_multimap_t *ghm) {
    generic_hash_multimap_iterator_t ret;
    generic_hash_multimap_iterator_init(&ret);
    generic_hash_table_begin(&ghm->imp, &ret.imp);
    return ret;
}

static generic_hash_multimap_iterator_t
generic_hash_multimap_end(generic_hash_multimap_t *ghm) {
    generic_hash_multimap_iterator_t ret;
    generic_hash_multimap_iterator_init(&ret);
    generic_hash_table_end(&ghm->imp, &ret.imp);
    return ret;
}

static generic_hash_multimap_iterator_t
generic_hash_multimap_find(generic_hash_multimap_t *ghm, const void *key) {
    generic_hash_multimap_iterator_t ret;
    generic_hash_multimap_iterator_init(&ret);
    generic_hash_table_find(&ghm->imp, key, &ret.imp);
    return ret;
}

static size_t generic_hash_multimap_count(const generic_hash_multimap_t *ghm,
        const void *key) {
    return generic_hash_table_count(&ghm->imp, key);
}

static void generic_hash_multimap_equal_range(generic_hash_multimap_t *ghm,
        const void *key, generic_hash_multimap_iterator_t *first,
        generic_hash_multimap_iterator_t *last) {
    generic_hash_multimap_iterator_init(first);
    generic_hash_multimap_iterator_init(last);
    generic_hash_table_equal_range(&ghm->imp, key, &first->imp, &last->imp);
}

static generic_hash_multimap_local_iterator_t
generic_hash_multimap_local_begin(generic_hash_multimap_t *ghm,
        size_t bucket) {
    generic_hash_multimap_local_iterator_t ret;
    generic_hash_multimap_local_iterator_init(&ret);
    generic_hash_table_local_begin(&ghm->imp, bucket, &ret.imp);
    return ret;
}

static generic_hash_multimap_local_iterator_t
generic_hash_multimap_local_end(generic_hash_multimap_t *ghm, size_t bucket) {
    generic_hash_multimap_local_iterator_t ret;
    generic_hash_multimap_local_iterator_init(&ret);
    generic_hash_table_local_end(&ghm->imp, bucket, &ret.imp);
    return ret;
}

static size_t
generic_hash_multimap_bucket_count(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_bucket_count(&ghm->imp);
}

static size_t
generic_hash_multimap_bucket_size(const generic_hash_multimap_t *ghm,
        size_t bucket) {
    return generic_hash_table_bucket_size(&ghm->imp, bucket);
}

static size_t
generic_hash_multimap_bucket(const generic_hash_multimap_t *ghm,
        const void *key) {
    return generic_hash_table_bucket(&ghm->imp, key);
}

static float
generic_hash_multimap_load_factor(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_load_factor(&ghm->imp);
}

static float
generic_hash_multimap_get_max_load_factor(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_get_max_load_factor(&ghm->imp);
}

static int
generic_hash_multimap_set_max_load_factor(generic_hash_multimap_t *ghm,
        float max_load_factor) {
    return generic_hash_table_set_max_load_factor(&ghm->imp, max_load_factor);
}

static generic_hash_multimap_iterator_t
generic_hash_multimap_insert(generic_hash_multimap_t *ghm,
        const void *key, const void *value) {
    generic_hash_multimap_iterator_t ret;
    generic_hash_multimap_iterator_init(&ret);
    generic_hash_table_insert(&ghm->imp, key, value, &ret.imp);
    return ret;
}

static generic_hash_multimap_iterator_t
generic_hash_multimap_erase(generic_hash_multimap_t *ghm,
        const generic_hash_multimap_iterator_t *iter) {
    generic_hash_multimap_iterator_t ret;
    generic_hash_multimap_iterator_init(&ret);
    generic_hash_table_erase(&ghm->imp, &iter->imp, &ret.imp);
    return ret;
}

static generic_hash_multimap_local_iterator_t
generic_hash_multimap_lerase(generic_hash_multimap_t *ghm,
        const generic_hash_multimap_local_iterator_t *iter) {
    generic_hash_multimap_local_iterator_t ret;
    generic_hash_multimap_local_iterator_init(&ret);
    generic_hash_table_lerase(&ghm->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_hash_multimap_remove(generic_hash_multimap_t *ghm,
        const void *key) {
    return generic_hash_table_remove(&ghm->imp, key);
}

static void generic_hash_multimap_clear(generic_hash_multimap_t *ghm) {
    generic_hash_table_clear(&ghm->imp);
}

static generic_memory_manager_t *
generic_hash_multimap_memory_manager(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_memory_manager(&ghm->imp);
}

static const generic_data_manager_t *
generic_hash_multimap_key_manager(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_key_manager(&ghm->imp);
}

static const generic_data_manager_t *
generic_hash_multimap_value_manager(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_value_manager(&ghm->imp);
}

static generic_hash_fp_t
generic_hash_multimap_hash(const generic_hash_multimap_t *ghm) {
    return generic_hash_table_hash(&ghm->imp);
}

static generic_hash_multimap_api_t g_generic_hash_multimap_api = {
    &generic_hash_multimap_construct,
    &generic_hash_multimap_destruct,
    &generic_hash_multimap_size,
    &generic_hash_multimap_empty,
    &generic_hash_multimap_begin,
    &generic_hash_multimap_end,
    &generic_hash_multimap_find,
    &generic_hash_multimap_count,
    &generic_hash_multimap_equal_range,
    &generic_hash_multimap_local_begin,
    &generic_hash_multimap_local_end,
    &generic_hash_multimap_bucket_count,
    &generic_hash_multimap_bucket_size,
    &generic_hash_multimap_bucket,
    &generic_hash_multimap_load_factor,
    &generic_hash_multimap_get_max_load_factor,
    &generic_hash_multimap_set_max_load_factor,
    &generic_hash_multimap_insert,
    &generic_hash_multimap_erase,
    &generic_hash_multimap_lerase,
    &generic_hash_multimap_remove,
    &generic_hash_multimap_clear,
    &generic_hash_multimap_memory_manager,
    &generic_hash_multimap_key_manager,
    &generic_hash_multimap_value_manager,
    &generic_hash_multimap_hash
};

#if defined(__cplusplus)
}
#endif

const generic_hash_map_iterator_api_t *generic_hash_map_iterator_api(void) {
    return &g_generic_hash_map_iterator_api;
}

const generic_hash_map_local_iterator_api_t *generic_hash_map_local_iterator_api(void) {
    return &g_generic_hash_map_local_iterator_api;
}

const generic_hash_map_api_t *generic_hash_map_api(void) {
    return &g_generic_hash_map_api;
}

const generic_hash_multimap_iterator_api_t *generic_hash_multimap_iterator_api(void) {
    return &g_generic_hash_multimap_iterator_api;
}

const generic_hash_multimap_local_iterator_api_t *generic_hash_multimap_local_iterator_api(void) {
    return &g_generic_hash_multimap_local_iterator_api;
}

const generic_hash_multimap_api_t *generic_hash_multimap_api(void) {
    return &g_generic_hash_multimap_api;
}

/** @} */

