/**
 * @file
 * @brief Hash table that facilitates to implement hash map and hash set.
 * @internal
 */

#include <string.h>
#include "generic_config.h"
#include "generic_hash_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

static inline char *
generic_hash_table_item_key(const generic_hash_table_t *ght,
        generic_hash_table_item_t *item) {
    return item->data + ght->key_offset;
}
static inline char *
generic_hash_table_item_value(const generic_hash_table_t *ght,
        generic_hash_table_item_t *item) {
    return item->data + ght->value_offset;
}

static void
generic_hash_table_iterator_incr_bucket(generic_hash_table_iterator_t *iter) {
    ++iter->bucket;
    /* buckets have one non-null sentry.
     * see generic_hash_table_create_buckets
     */
    while (!iter->ght->buckets[iter->bucket]) {
        ++iter->bucket;
    }
    /* first item of next non-empty bucket */
    iter->item = iter->ght->buckets[iter->bucket];
}

static void generic_hash_table_iterator_init(generic_hash_table_iterator_t *iter,
        const generic_hash_table_t *ght,
        size_t bucket, generic_hash_table_item_t *item) {
    iter->ght = ght;
    iter->bucket = bucket;
    iter->item = item;
}

static void generic_hash_table_local_iterator_init(generic_hash_table_local_iterator_t *iter,
        const generic_hash_table_t *ght,
        generic_hash_table_item_t *item) {
    iter->ght = ght;
    iter->item = item;
}

static generic_hash_table_item_t *
generic_hash_table_create_item(generic_hash_table_t *ght, 
        const void *key, const void *value) {
    generic_memory_manager_t *gmm = ght->gmm;
    const generic_data_manager_t *gkm = ght->gkm;
    const generic_data_manager_t *gvm = ght->gvm;
    generic_hash_table_item_t *item;
    void *item_key;
    void *item_value;

    item = (generic_hash_table_item_t *)(gmm->allocate(gmm, ght->item_size));
    if (!item) {
        return 0;
    }

    item_key = generic_hash_table_item_key(ght, item);
    if (gkm->copy(item_key, key)) {
        gmm->deallocate(gmm, item, ght->item_size);
        return 0;
    }

    if (gvm) {
        item_value = generic_hash_table_item_value(ght, item);
        if (gvm->copy(item_value, value)) {
            if (gkm->destruct) {
                gkm->destruct(item_key);
            }
            gmm->deallocate(gmm, item, ght->item_size);
            return 0;
        }
    }

    return item;
}

static void generic_hash_table_destroy_item(generic_hash_table_t *ght,
        generic_hash_table_item_t *item) {
    if (ght->gkm->destruct) {
        ght->gkm->destruct(generic_hash_table_item_key(ght, item));
    }
    if (ght->gvm && ght->gvm->destruct) {
        ght->gvm->destruct(generic_hash_table_item_value(ght, item));
    }
    ght->gmm->deallocate(ght->gmm, item, ght->item_size);
}

static void generic_hash_table_destroy_items(generic_hash_table_t *ght,
        generic_hash_table_item_t *first,
        generic_hash_table_item_t *last) {
    generic_hash_table_item_t *item = first;
    if (ght->gkm->destruct) {
        if (ght->gvm && ght->gvm->destruct) {
            while (item != last) {
                generic_hash_table_item_t *next = item->next;
                ght->gkm->destruct(generic_hash_table_item_key(ght, item));
                ght->gvm->destruct(generic_hash_table_item_value(ght, item));
                ght->gmm->deallocate(ght->gmm, item, ght->item_size);
                item = next;
            }
        } else {
            while (item != last) {
                generic_hash_table_item_t *next = item->next;
                ght->gkm->destruct(generic_hash_table_item_key(ght, item));
                ght->gmm->deallocate(ght->gmm, item, ght->item_size);
                item = next;
            }
        }
    } else if (ght->gvm && ght->gvm->destruct) {
        while (item != last) {
            generic_hash_table_item_t *next = item->next;
            ght->gvm->destruct(generic_hash_table_item_value(ght, item));
            ght->gmm->deallocate(ght->gmm, item, ght->item_size);
            item = next;
        }
    } else {
        while (item != last) {
            generic_hash_table_item_t *next = item->next;
            ght->gmm->deallocate(ght->gmm, item, ght->item_size);
            item = next;
        }
    }
}

static size_t generic_hash_table_next_bucket_count(generic_hash_table_t *ght,
        size_t bucket_hint) {
    static unsigned long prime[] = {
        53ul,         97ul,         193ul,       389ul,       769ul,
        1543ul,       3079ul,       6151ul,      12289ul,     24593ul,
        49157ul,      98317ul,      196613ul,    393241ul,    786433ul,
        1572869ul,    3145739ul,    6291469ul,   12582917ul,  25165843ul,
        50331653ul,   100663319ul,  201326611ul, 402653189ul, 805306457ul,
        1610612741ul, 3221225473ul, 4294967291ul
    };
    const unsigned count = sizeof(prime) / sizeof(prime[0]);
    unsigned u;
    /* linear search is good enough because it's rarely called. */
    for (u = 0; u < count; ++u) {
        if (prime[u] >= bucket_hint) {
            return prime[u];
        }
    }
    return prime[count - 1];
}

static generic_hash_table_item_t **
generic_hash_table_create_buckets(generic_hash_table_t *ght,
        size_t bucket_count) {
    generic_hash_table_item_t **buckets;
    size_t size;

    size = (bucket_count + 1) * sizeof(generic_hash_table_item_t *);
    buckets = (generic_hash_table_item_t **)(ght->gmm->allocate(ght->gmm, size));
    if (buckets) {
        memset(buckets, 0, size);
        /* initialize sentry */
        buckets[bucket_count] = (generic_hash_table_item_t *)(0x1);
    }

    return buckets;
}

static void generic_hash_table_destroy_buckets(generic_hash_table_t *ght,
        generic_hash_table_item_t **buckets, size_t bucket_count) {
    size_t size = (bucket_count + 1) * sizeof(generic_hash_table_item_t *);
    ght->gmm->deallocate(ght->gmm, buckets, size);
}

static inline size_t
generic_hash_table_bucket_index(const generic_hash_table_t *ght,
        const void *key, size_t bucket_count) {
    return ght->hash(key) % bucket_count;
}

static generic_hash_table_item_t **
generic_hash_table_find_in_bucket(const generic_hash_table_t *ght,
        size_t bucket, const void *key) {
    generic_hash_table_item_t **item = &ght->buckets[bucket];
    while (*item) {
        if (ght->gkm->equal(generic_hash_table_item_key(ght, *item), key)) {
            return item;
        }
        item = &((*item)->next);
    }
    return 0;
}

static int generic_hash_table_rehash(generic_hash_table_t *ght) {
    generic_hash_table_item_t **new_buckets;
    size_t new_bucket_count;
    size_t bucket;

    if (ght->item_count <= ght->rehash_threshold) { /* load factor is low */
        return 0;
    }

    if (!ght->rehashable) {
        return -1;
    }

    /* max_load_factor cannot be 0 */
    new_bucket_count = ght->item_count / ght->max_load_factor; /* recommended */
    /* possible deviation due to floating point */
    if (new_bucket_count <= ght->bucket_count) {
        ++new_bucket_count;
    }
    new_bucket_count = generic_hash_table_next_bucket_count(ght,
            new_bucket_count);

    if (new_bucket_count <= ght->bucket_count) { /* can't enlarge buckets any more */
        ght->rehashable = 0;
        return -1;
    }

    new_buckets = generic_hash_table_create_buckets(ght, new_bucket_count);
    if (!new_buckets) {
        return -1;
    }

    ght->begin_bucket = new_bucket_count;

    for (bucket = 0; bucket < ght->bucket_count; ++bucket) {
        while (ght->buckets[bucket]) {
            generic_hash_table_item_t *item = ght->buckets[bucket];
            size_t new_bucket = generic_hash_table_bucket_index(ght,
                    generic_hash_table_item_key(ght, item), new_bucket_count);
            ght->buckets[bucket] = item->next;
            item->next = new_buckets[new_bucket];
            new_buckets[new_bucket] = item;
            if (new_bucket < ght->begin_bucket) {
                ght->begin_bucket = new_bucket;
            }
        }
    }

    generic_hash_table_destroy_buckets(ght, ght->buckets, ght->bucket_count);
    ght->bucket_count = new_bucket_count;
    ght->buckets = new_buckets;

    /* update rehash threshold */
    ght->rehash_threshold = ght->bucket_count * ght->max_load_factor;
    return 0;
}

static int generic_hash_table_insert_in_bucket(generic_hash_table_t *ght,
        size_t bucket, generic_hash_table_item_t **next_of_prev,
        const void *key, const void *value,
        generic_hash_table_iterator_t *ret) {
    generic_hash_table_item_t *item;
    item = generic_hash_table_create_item(ght, key, value);
    if (!item) {
        generic_hash_table_end(ght, ret);
        return -1;
    }

    item->next = *next_of_prev;
    *next_of_prev = item;

    if (bucket < ght->begin_bucket) {
        ght->begin_bucket = bucket;
    }

    generic_hash_table_iterator_init(ret, ght, bucket, item);

    ++ght->item_count;

    generic_hash_table_rehash(ght);

    return 0;
}

#if defined(__cplusplus)
}
#endif

void
generic_hash_table_iterator_next(generic_hash_table_iterator_t *iter) {
    iter->item = iter->item->next;
    if (!iter->item) { /* end of this bucket */
        generic_hash_table_iterator_incr_bucket(iter);
    }
}

generic_hash_table_data_t *
generic_hash_table_iterator_deref(generic_hash_table_iterator_t *iter) {
    iter->data.key = generic_hash_table_item_key(iter->ght, iter->item);
    iter->data.value = generic_hash_table_item_value(iter->ght, iter->item);
    return &(iter->data);
}

int
generic_hash_table_iterator_equal(const generic_hash_table_iterator_t *lhs,
        const generic_hash_table_iterator_t *rhs) {
    return lhs->item == rhs->item;
}

generic_iterator_tag_t generic_hash_table_iterator_category(void) {
    return generic_forward_iterator_tag;
}

void
generic_hash_table_local_iterator_next(generic_hash_table_local_iterator_t *iter) {
    iter->item = iter->item->next;
}

generic_hash_table_data_t *
generic_hash_table_local_iterator_deref(generic_hash_table_local_iterator_t *iter) {
    iter->data.key = generic_hash_table_item_key(iter->ght, iter->item);
    iter->data.value = generic_hash_table_item_value(iter->ght, iter->item);
    return &(iter->data);
}

int
generic_hash_table_local_iterator_equal(const generic_hash_table_local_iterator_t *lhs,
        const generic_hash_table_local_iterator_t *rhs) {
    return lhs->item == rhs->item;
}

generic_iterator_tag_t generic_hash_table_local_iterator_category(void) {
    return generic_forward_iterator_tag;
}

int generic_hash_table_construct(generic_hash_table_t *ght,
        size_t bucket_hint, generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm,
        generic_hash_fp_t hash, int unique) {
    ght->gmm = gmm;
    ght->gkm = gkm;
    ght->gvm = gvm;
    ght->bucket_count = generic_hash_table_next_bucket_count(ght, bucket_hint);
    ght->buckets = generic_hash_table_create_buckets(ght, ght->bucket_count);
    if (!ght->buckets) {
        return -1;
    }
    ght->item_count = 0;
    ght->begin_bucket = ght->bucket_count;
    ght->hash = hash;
    ght->unique = unique;
    ght->rehashable = 1;
    ght->max_load_factor = 1; /* may be 0.8 is better */
    ght->rehash_threshold = ght->bucket_count * ght->max_load_factor;
    generic_hash_table_config(ght);
    return 0;
}

void generic_hash_table_destruct(generic_hash_table_t *ght) {
    generic_hash_table_clear(ght);
    generic_hash_table_destroy_buckets(ght, ght->buckets, ght->bucket_count);
}

size_t generic_hash_table_size(const generic_hash_table_t *ght) {
    return ght->item_count;
}

int generic_hash_table_empty(const generic_hash_table_t *ght) {
    return ght->item_count == 0;
}

void generic_hash_table_begin(generic_hash_table_t *ght,
        generic_hash_table_iterator_t *ret) {
    size_t bucket = ght->begin_bucket;
    generic_hash_table_item_t *item = ght->buckets[bucket];
    generic_hash_table_iterator_init(ret, ght, bucket, item);
}

void generic_hash_table_end(generic_hash_table_t *ght,
        generic_hash_table_iterator_t *ret) {
    size_t bucket = ght->bucket_count;
    generic_hash_table_item_t *item = ght->buckets[bucket];
    generic_hash_table_iterator_init(ret, ght, bucket, item);
}

int generic_hash_table_find(generic_hash_table_t *ght, const void *key,
        generic_hash_table_iterator_t *ret) {
    generic_hash_table_item_t **item;
    size_t bucket;
    bucket = generic_hash_table_bucket_index(ght, key, ght->bucket_count);
    item = generic_hash_table_find_in_bucket(ght, bucket, key);
    if (item) {
        generic_hash_table_iterator_init(ret, ght, bucket, *item);
        return 1;
    }
    generic_hash_table_end(ght, ret);
    return 0;
}

size_t generic_hash_table_count(const generic_hash_table_t *ght,
        const void *key) {
    size_t bucket;
    generic_hash_table_item_t **item;
    bucket = generic_hash_table_bucket_index(ght, key, ght->bucket_count);
    item = generic_hash_table_find_in_bucket(ght, bucket, key);
    if (item) {
        size_t count = 1;
        item = &((*item)->next);
        while (*item
                && ght->gkm->equal(generic_hash_table_item_key(ght, *item), key)) {
            ++count;
            item = &((*item)->next);
        }
        return count;
    }
    return 0;
}

void generic_hash_table_equal_range(generic_hash_table_t *ght,
        const void *key, generic_hash_table_iterator_t *first,
        generic_hash_table_iterator_t *last) {
    generic_hash_table_item_t **item;
    size_t bucket;
    bucket = generic_hash_table_bucket_index(ght, key, ght->bucket_count);
    item = generic_hash_table_find_in_bucket(ght, bucket, key);

    if (item) {
        generic_hash_table_item_t *next = (*item)->next;
        while (next) {
            if (!ght->gkm->equal(generic_hash_table_item_key(ght, next), key)) {
                break;
            }
            next = next->next;
        }
        generic_hash_table_iterator_init(first, ght, bucket, *item);
        generic_hash_table_iterator_init(last, ght, bucket, next);
        if (!next) {
            generic_hash_table_iterator_incr_bucket(last);
        }
        return;
    }

    generic_hash_table_end(ght, first);
    generic_hash_table_end(ght, last);
}

size_t generic_hash_table_bucket_count(const generic_hash_table_t *ght) {
    return ght->bucket_count;
}

void generic_hash_table_local_begin(generic_hash_table_t *ght, size_t bucket,
        generic_hash_table_local_iterator_t *ret) {
    generic_hash_table_local_iterator_init(ret, ght, ght->buckets[bucket]);
}

void generic_hash_table_local_end(generic_hash_table_t *ght, size_t bucket,
        generic_hash_table_local_iterator_t *ret) {
    generic_hash_table_local_iterator_init(ret, ght, 0);
}

size_t generic_hash_table_bucket_size(const generic_hash_table_t *ght,
        size_t bucket) {
    size_t count = 0;
    generic_hash_table_item_t *item = ght->buckets[bucket];
    while (item) {
        item = item->next;
        ++count;
    }
    return count;
}

size_t generic_hash_table_bucket(const generic_hash_table_t *ght,
        const void *key) {
    return generic_hash_table_bucket_index(ght, key, ght->bucket_count);
}

float generic_hash_table_load_factor(const generic_hash_table_t *ght) {
    return (float)(ght->item_count) / ght->bucket_count;
}

float
generic_hash_table_get_max_load_factor(const generic_hash_table_t *ght) {
    return ght->max_load_factor;
}

int generic_hash_table_set_max_load_factor(generic_hash_table_t *ght,
        float max_load_factor) {
    if (max_load_factor < 0.01) { /* too small */
        return -1;
    }
    ght->max_load_factor = max_load_factor;
    ght->rehash_threshold = ght->bucket_count * ght->max_load_factor;
    return generic_hash_table_rehash(ght);
}

int generic_hash_table_insert(generic_hash_table_t *ght,
        const void *key, const void *value,
        generic_hash_table_iterator_t *ret) {
    generic_hash_table_item_t **item;
    size_t bucket;
    bucket = generic_hash_table_bucket_index(ght, key, ght->bucket_count);
    item = generic_hash_table_find_in_bucket(ght, bucket, key);

    if (item) { /* already existed */
        if (ght->unique) {
            generic_hash_table_iterator_init(ret, ght, bucket, *item);
            return 1;
        }
        return generic_hash_table_insert_in_bucket(ght, bucket, item,
                key, value, ret);
    }

    return generic_hash_table_insert_in_bucket(ght, bucket,
            &ght->buckets[bucket], key, value, ret);
}

/* Be careful: iter and ret may be same */
void generic_hash_table_erase(generic_hash_table_t *ght,
        const generic_hash_table_iterator_t *iter,
        generic_hash_table_iterator_t *ret) {
    generic_hash_table_item_t *item = iter->item;
    size_t bucket = iter->bucket;
    generic_hash_table_item_t *head = ght->buckets[bucket];
    generic_hash_table_iterator_init(ret, ght, bucket, item);
    generic_hash_table_iterator_next(ret);

    /* do not use iter any more */

    if (head == item) {
        ght->buckets[bucket] = item->next;
        if (!ght->buckets[ght->begin_bucket]) {
            ght->begin_bucket = ret->bucket;
        }
    } else {
        generic_hash_table_item_t *curr = head;
        while (curr->next != item) {
            curr = curr->next;
        }
        curr->next = item->next;
    }

    generic_hash_table_destroy_item(ght, item);
    --ght->item_count;
}

/* Be careful: local_iter and local_ret may be same */
void generic_hash_table_lerase(generic_hash_table_t *ght,
        const generic_hash_table_local_iterator_t *local_iter,
        generic_hash_table_local_iterator_t *local_ret) {
    generic_hash_table_item_t *item;
    size_t bucket;
    generic_hash_table_iterator_t iter;

    item = local_iter->item;
    bucket = generic_hash_table_bucket_index(ght,
                generic_hash_table_item_key(ght, item), ght->bucket_count);

    generic_hash_table_iterator_init(&iter, ght, bucket, item);

    generic_hash_table_local_iterator_init(local_ret, ght, item->next);

    /* do not use local_iter any more */

    generic_hash_table_erase(ght, &iter, &iter);
}

size_t generic_hash_table_remove(generic_hash_table_t *ght,
        const void *key) {
    size_t count;
    size_t bucket;
    generic_hash_table_item_t **next_of_prev;
    generic_hash_table_item_t *first;
    generic_hash_table_item_t *last;

    bucket = generic_hash_table_bucket_index(ght, key, ght->bucket_count);

    next_of_prev = generic_hash_table_find_in_bucket(ght, bucket, key);
    if (!next_of_prev) {
        return 0;
    }

    count = 1;
    first = *next_of_prev;
    last = first->next;
    while (last) {
        if (!ght->gkm->equal(generic_hash_table_item_key(ght, last), key)) {
            break;
        }
        last = last->next;
        ++count;
    }

    /* Be careful: key may come from [first, last).
     *
     * Deleting item (may destroy key simulataneiously) while searching
     * matching item is dangerous without extra effort.
     *
     * So, the naive, but safe approach is to determine [first, last),
     * then delete each item.
     *
     */

    *next_of_prev = last;
    generic_hash_table_destroy_items(ght, first, last);

    ght->item_count -= count;
    return count;
}

void generic_hash_table_clear(generic_hash_table_t *ght) {
    size_t bucket;
    for (bucket = 0; bucket < ght->bucket_count; ++bucket) {
        if (ght->buckets[bucket]) {
            generic_hash_table_destroy_items(ght, ght->buckets[bucket], 0);
            ght->buckets[bucket] = 0;
        }
    }
    ght->item_count = 0;
    ght->begin_bucket = ght->bucket_count;
}

generic_hash_fp_t generic_hash_table_hash(const generic_hash_table_t *ght) {
    return ght->hash;
}

generic_memory_manager_t *
generic_hash_table_memory_manager(const generic_hash_table_t *ght) {
    return ght->gmm;
}

const generic_data_manager_t *
generic_hash_table_key_manager(const generic_hash_table_t *ght) {
    return ght->gkm;
}

const generic_data_manager_t *
generic_hash_table_value_manager(const generic_hash_table_t *ght) {
    return ght->gvm;
}

