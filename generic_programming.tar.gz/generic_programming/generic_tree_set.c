/** @addtogroup GenericContainer */

/** @{ */

/**
 * @file
 * @brief Implementatio of tree set and tree multiset.
 */

#include "generic_tree_set.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void
generic_tree_set_iterator_next(generic_tree_set_iterator_t *iter) {
    generic_tree_table_iterator_next(&iter->imp);
}

static void
generic_tree_set_iterator_prev(generic_tree_set_iterator_t *iter) {
    generic_tree_table_iterator_prev(&iter->imp);
}

static const void *
generic_tree_set_iterator_deref(generic_tree_set_iterator_t *iter) {
    return generic_tree_table_iterator_deref(&iter->imp)->key;
}

static int
generic_tree_set_iterator_equal(const generic_tree_set_iterator_t *lhs,
        const generic_tree_set_iterator_t *rhs) {
    return generic_tree_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_tree_set_iterator_category(void) {
    return generic_tree_table_iterator_category();
}

static size_t generic_tree_set_iterator_size(void) {
    return sizeof(generic_tree_set_iterator_t);
}

static generic_tree_set_iterator_api_t g_generic_tree_set_iterator_api = {
    &generic_tree_set_iterator_next,
    &generic_tree_set_iterator_prev,
    0, /* move */
    &generic_tree_set_iterator_deref,
    &generic_tree_set_iterator_equal,
    0, /* sub */
    &generic_tree_set_iterator_category,
    &generic_tree_set_iterator_size
};

static inline void
generic_tree_set_iterator_init(generic_tree_set_iterator_t *iter) {
    iter->api = &g_generic_tree_set_iterator_api;
}

static int generic_tree_set_construct(generic_tree_set_t *gts,
        generic_memory_manager_t *gmm, const generic_data_manager_t *gkm) {
    return generic_tree_table_construct(&gts->imp,
            gmm, gkm, 0 /* no value */, 1 /* unique */);
}

static void generic_tree_set_destruct(generic_tree_set_t *gts) {
    generic_tree_table_destruct(&gts->imp);
}

static size_t generic_tree_set_size(const generic_tree_set_t *gts) {
    return generic_tree_table_size(&gts->imp);
}

static int generic_tree_set_empty(const generic_tree_set_t *gts) {
    return generic_tree_table_empty(&gts->imp);
}

static generic_tree_set_iterator_t
generic_tree_set_begin(generic_tree_set_t *gts) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_begin(&gts->imp, &ret.imp);
    return ret;
}

static generic_tree_set_iterator_t
generic_tree_set_end(generic_tree_set_t *gts) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_end(&gts->imp, &ret.imp);
    return ret;
}

static generic_tree_set_iterator_t
generic_tree_set_find(generic_tree_set_t *gts, const void *key) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_find(&gts->imp, key, &ret.imp);
    return ret;
}

static size_t generic_tree_set_count(const generic_tree_set_t *gts,
        const void *key) {
    return generic_tree_table_count(&gts->imp, key);
}

static void generic_tree_set_equal_range(generic_tree_set_t *gts,
        const void *key, generic_tree_set_iterator_t *first,
        generic_tree_set_iterator_t *last) {
    generic_tree_set_iterator_init(first);
    generic_tree_set_iterator_init(last);
    generic_tree_table_equal_range(&gts->imp, key, &first->imp, &last->imp);
}

static generic_tree_set_iterator_t 
generic_tree_set_lower_bound(generic_tree_set_t *gts, const void *key) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_lower_bound(&gts->imp, key, &ret.imp);
    return ret;
}

static generic_tree_set_iterator_t
generic_tree_set_upper_bound(generic_tree_set_t *gts, const void *key) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_upper_bound(&gts->imp, key, &ret.imp);
    return ret;
}

static generic_tree_set_iterator_t
generic_tree_set_insert(generic_tree_set_t *gts, const void *key) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_insert(&gts->imp, key, 0, &ret.imp);
    return ret;
}

static generic_tree_set_iterator_t
generic_tree_set_erase(generic_tree_set_t *gts,
        const generic_tree_set_iterator_t *iter) {
    generic_tree_set_iterator_t ret;
    generic_tree_set_iterator_init(&ret);
    generic_tree_table_erase(&gts->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_tree_set_remove(generic_tree_set_t *gts,
        const void *key) {
    return generic_tree_table_remove(&gts->imp, key);
}

static void generic_tree_set_clear(generic_tree_set_t *gts) {
    generic_tree_table_clear(&gts->imp);
}

static generic_memory_manager_t *
generic_tree_set_memory_manager(const generic_tree_set_t *gts) {
    return generic_tree_table_memory_manager(&gts->imp);
}

static const generic_data_manager_t *
generic_tree_set_data_manager(const generic_tree_set_t *gts) {
    return generic_tree_table_key_manager(&gts->imp);
}

static generic_tree_set_api_t g_generic_tree_set_api = {
    &generic_tree_set_construct,
    &generic_tree_set_destruct,
    &generic_tree_set_size,
    &generic_tree_set_empty,
    &generic_tree_set_begin,
    &generic_tree_set_end,
    &generic_tree_set_find,
    &generic_tree_set_count,
    &generic_tree_set_equal_range,
    &generic_tree_set_lower_bound,
    &generic_tree_set_upper_bound,
    &generic_tree_set_insert,
    &generic_tree_set_erase,
    &generic_tree_set_remove,
    &generic_tree_set_clear,
    &generic_tree_set_memory_manager,
    &generic_tree_set_data_manager
};

static void
generic_tree_multiset_iterator_next(generic_tree_multiset_iterator_t *iter) {
    generic_tree_table_iterator_next(&iter->imp);
}

static void
generic_tree_multiset_iterator_prev(generic_tree_multiset_iterator_t *iter) {
    generic_tree_table_iterator_prev(&iter->imp);
}

static const void *
generic_tree_multiset_iterator_deref(generic_tree_multiset_iterator_t *iter) {
    return generic_tree_table_iterator_deref(&iter->imp)->key;
}

static int
generic_tree_multiset_iterator_equal(const generic_tree_multiset_iterator_t *lhs,
        const generic_tree_multiset_iterator_t *rhs) {
    return generic_tree_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_tree_multiset_iterator_category(void) {
    return generic_tree_table_iterator_category();
}

static size_t generic_tree_multiset_iterator_size(void) {
    return sizeof(generic_tree_multiset_iterator_t);
}

static generic_tree_multiset_iterator_api_t g_generic_tree_multiset_iterator_api = {
    &generic_tree_multiset_iterator_next,
    &generic_tree_multiset_iterator_prev,
    0, /* move */
    &generic_tree_multiset_iterator_deref,
    &generic_tree_multiset_iterator_equal,
    0, /* sub */
    &generic_tree_multiset_iterator_category,
    &generic_tree_multiset_iterator_size
};

static inline void
generic_tree_multiset_iterator_init(generic_tree_multiset_iterator_t *iter) {
    iter->api = &g_generic_tree_multiset_iterator_api;
}

static int generic_tree_multiset_construct(generic_tree_multiset_t *gts,
        generic_memory_manager_t *gmm, const generic_data_manager_t *gkm) {
    return generic_tree_table_construct(&gts->imp,
            gmm, gkm, 0 /* no value */, 0 /* not unique */);
}

static void generic_tree_multiset_destruct(generic_tree_multiset_t *gts) {
    generic_tree_table_destruct(&gts->imp);
}

static size_t
generic_tree_multiset_size(const generic_tree_multiset_t *gts) {
    return generic_tree_table_size(&gts->imp);
}

static int
generic_tree_multiset_empty(const generic_tree_multiset_t *gts) {
    return generic_tree_table_empty(&gts->imp);
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_begin(generic_tree_multiset_t *gts) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_begin(&gts->imp, &ret.imp);
    return ret;
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_end(generic_tree_multiset_t *gts) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_end(&gts->imp, &ret.imp);
    return ret;
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_find(generic_tree_multiset_t *gts, const void *key) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_find(&gts->imp, key, &ret.imp);
    return ret;
}

static size_t generic_tree_multiset_count(const generic_tree_multiset_t *gts,
        const void *key) {
    return generic_tree_table_count(&gts->imp, key);
}

static void generic_tree_multiset_equal_range(generic_tree_multiset_t *gts,
        const void *key, generic_tree_multiset_iterator_t *first,
        generic_tree_multiset_iterator_t *last) {
    generic_tree_multiset_iterator_init(first);
    generic_tree_multiset_iterator_init(last);
    generic_tree_table_equal_range(&gts->imp, key, &first->imp, &last->imp);
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_lower_bound(generic_tree_multiset_t *gts,
        const void *key) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_lower_bound(&gts->imp, key, &ret.imp);
    return ret;
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_upper_bound(generic_tree_multiset_t *gts,
        const void *key) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_upper_bound(&gts->imp, key, &ret.imp);
    return ret;
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_insert(generic_tree_multiset_t *gts, const void *key) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_insert(&gts->imp, key, 0, &ret.imp);
    return ret;
}

static generic_tree_multiset_iterator_t
generic_tree_multiset_erase(generic_tree_multiset_t *gts,
        const generic_tree_multiset_iterator_t *iter) {
    generic_tree_multiset_iterator_t ret;
    generic_tree_multiset_iterator_init(&ret);
    generic_tree_table_erase(&gts->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_tree_multiset_remove(generic_tree_multiset_t *gts,
        const void *key) {
    return generic_tree_table_remove(&gts->imp, key);
}

static void generic_tree_multiset_clear(generic_tree_multiset_t *gts) {
    generic_tree_table_clear(&gts->imp);
}

static generic_memory_manager_t *
generic_tree_multiset_memory_manager(const generic_tree_multiset_t *gts) {
    return generic_tree_table_memory_manager(&gts->imp);
}

static const generic_data_manager_t *
generic_tree_multiset_data_manager(const generic_tree_multiset_t *gts) {
    return generic_tree_table_key_manager(&gts->imp);
}

static generic_tree_multiset_api_t g_generic_tree_multiset_api = {
    &generic_tree_multiset_construct,
    &generic_tree_multiset_destruct,
    &generic_tree_multiset_size,
    &generic_tree_multiset_empty,
    &generic_tree_multiset_begin,
    &generic_tree_multiset_end,
    &generic_tree_multiset_find,
    &generic_tree_multiset_count,
    &generic_tree_multiset_equal_range,
    &generic_tree_multiset_lower_bound,
    &generic_tree_multiset_upper_bound,
    &generic_tree_multiset_insert,
    &generic_tree_multiset_erase,
    &generic_tree_multiset_remove,
    &generic_tree_multiset_clear,
    &generic_tree_multiset_memory_manager,
    &generic_tree_multiset_data_manager
};

#if defined(__cplusplus)
}
#endif

const generic_tree_set_iterator_api_t *generic_tree_set_iterator_api(void) {
    return &g_generic_tree_set_iterator_api;
}

const generic_tree_set_api_t *generic_tree_set_api(void) {
    return &g_generic_tree_set_api;
}

const generic_tree_multiset_iterator_api_t *generic_tree_multiset_iterator_api(void) {
    return &g_generic_tree_multiset_iterator_api;
}

const generic_tree_multiset_api_t *generic_tree_multiset_api(void) {
    return &g_generic_tree_multiset_api;
}

/** @} */

