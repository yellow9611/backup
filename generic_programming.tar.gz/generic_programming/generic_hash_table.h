/**
 * @file
 * @brief Hash table that facilitates to implement hash map and hash set.
 * @internal
 */

#if !defined(GENERIC_HASH_TABLE_H)
#define GENERIC_HASH_TABLE_H

#include <stddef.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_hash_table_t generic_hash_table_t;
typedef struct generic_hash_table_iterator_t generic_hash_table_iterator_t;
typedef struct generic_hash_table_local_iterator_t generic_hash_table_local_iterator_t;
typedef struct generic_hash_table_item_t generic_hash_table_item_t;
typedef struct generic_hash_table_data_t generic_hash_table_data_t;

struct generic_hash_table_item_t {
    generic_hash_table_item_t *next;
    char data[1];
};

struct generic_hash_table_data_t {
    const void *key;
    void *value;
};

struct generic_hash_table_iterator_t {
    const generic_hash_table_t *ght;
    size_t bucket;
    generic_hash_table_item_t *item;
    generic_hash_table_data_t data;
};

void generic_hash_table_iterator_next(generic_hash_table_iterator_t *);

generic_hash_table_data_t *
generic_hash_table_iterator_deref(generic_hash_table_iterator_t *);

int generic_hash_table_iterator_equal(const generic_hash_table_iterator_t *,
        const generic_hash_table_iterator_t *);

generic_iterator_tag_t generic_hash_table_iterator_category(void);

struct generic_hash_table_local_iterator_t {
    const generic_hash_table_t *ght;
    generic_hash_table_item_t *item;
    generic_hash_table_data_t data;
};

void
generic_hash_table_local_iterator_next(generic_hash_table_local_iterator_t *);

generic_hash_table_data_t *
generic_hash_table_local_iterator_deref(generic_hash_table_local_iterator_t *);

int generic_hash_table_local_iterator_equal(const generic_hash_table_local_iterator_t *,
        const generic_hash_table_local_iterator_t *);

generic_iterator_tag_t generic_hash_table_local_iterator_category(void);

struct generic_hash_table_t {
    generic_memory_manager_t *gmm;
    const generic_data_manager_t *gkm;
    const generic_data_manager_t *gvm;
    generic_hash_table_item_t **buckets;
    size_t bucket_count;
    size_t item_count;
    size_t begin_bucket; /* index of first non-empty bucket */
    size_t item_size; /* each item size in bytes */
    generic_hash_fp_t hash;
    size_t key_offset; /* key offset relative to item->data */
    size_t value_offset; /* value offset relative to item->data */
    int unique; /* indicate whether or not multiple elements with the same key are allowed. */
    int rehashable;
    float max_load_factor;
    size_t rehash_threshold; /* rehash kicks in if item_count > rehash_threshold */
};

int generic_hash_table_construct(generic_hash_table_t *, size_t,
        generic_memory_manager_t *, const generic_data_manager_t *,
        const generic_data_manager_t *, generic_hash_fp_t, int);

void generic_hash_table_destruct(generic_hash_table_t *);

size_t generic_hash_table_size(const generic_hash_table_t *);

int generic_hash_table_empty(const generic_hash_table_t *);

void generic_hash_table_begin(generic_hash_table_t *,
        generic_hash_table_iterator_t *);

void generic_hash_table_end(generic_hash_table_t *,
        generic_hash_table_iterator_t *);

int generic_hash_table_find(generic_hash_table_t *,
        const void *, generic_hash_table_iterator_t *);

size_t generic_hash_table_count(const generic_hash_table_t *,
        const void *);

void generic_hash_table_equal_range(generic_hash_table_t *, const void *,
        generic_hash_table_iterator_t *,
        generic_hash_table_iterator_t *);

size_t generic_hash_table_bucket_count(const generic_hash_table_t *);

size_t generic_hash_table_bucket_size(const generic_hash_table_t *, size_t);

size_t generic_hash_table_bucket(const generic_hash_table_t *, const void *);

void generic_hash_table_local_begin(generic_hash_table_t *, size_t,
        generic_hash_table_local_iterator_t *);

void generic_hash_table_local_end(generic_hash_table_t *, size_t,
        generic_hash_table_local_iterator_t *);

float generic_hash_table_load_factor(const generic_hash_table_t *);

float generic_hash_table_get_max_load_factor(const generic_hash_table_t *);

int generic_hash_table_set_max_load_factor(generic_hash_table_t *, float);

int generic_hash_table_insert(generic_hash_table_t *,
        const void *, const void *, generic_hash_table_iterator_t *);

void generic_hash_table_erase(generic_hash_table_t *,
        const generic_hash_table_iterator_t *,
        generic_hash_table_iterator_t *);

void generic_hash_table_lerase(generic_hash_table_t *,
        const generic_hash_table_local_iterator_t *,
        generic_hash_table_local_iterator_t *);

size_t generic_hash_table_remove(generic_hash_table_t *, const void *);

void generic_hash_table_clear(generic_hash_table_t *);

generic_hash_fp_t generic_hash_table_hash(const generic_hash_table_t *);

generic_memory_manager_t *
generic_hash_table_memory_manager(const generic_hash_table_t *);

const generic_data_manager_t *
generic_hash_table_key_manager(const generic_hash_table_t *);

const generic_data_manager_t *
generic_hash_table_value_manager(const generic_hash_table_t *);

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_HASH_TABLE_H */

