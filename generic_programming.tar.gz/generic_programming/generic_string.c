/** @addtogroup GenericString */

/** @{ */

/**
 * @file
 * @brief Implementation of string.
 */

#include <string.h>
#include "generic_string.h"

#if defined(__cplusplus)
extern "C" {
#endif

static char g_empty_str[256];

static int generic_string_append_data(generic_string_t *,
        const void *, size_t);
static int generic_string_append_char(generic_string_t *,
        size_t, char);
static int generic_string_assign_data(generic_string_t *,
        const void *, size_t);

static inline void
generic_string_iterator_init(generic_string_iterator_t *iter,
        const generic_string_t *gs, char *p) {
    generic_pointer_iterator_init(iter, p, sizeof(char));
}

static size_t generic_string_next_capacity(const generic_string_t *gs,
        size_t delta) {
    const size_t maximum = (size_t)(-1);
    size_t base;
    if (maximum - gs->size <= delta) {
        return maximum;
    }
    base = gs->size + delta;
    if (maximum - base <= base) {
        return maximum;
    }

    return 2 * base;
    /* invariant:
     * ret >= gs->size
     * ret >= delta
     */
}

static char *generic_string_allocate(generic_memory_manager_t *gmm,
        size_t capacity) {
    if (capacity == (size_t)(-1)) {
        return 0;
    }
    /* We need to allocate one more byte for terminator '\0' */
    return (char *)(gmm->allocate(gmm, capacity + 1));
}

static void generic_string_deallocate(generic_memory_manager_t *gmm,
        char *data, size_t capacity) {
    gmm->deallocate(gmm, data, capacity + 1);
}

static void generic_string_swap(generic_string_t *x, generic_string_t *y) {
    generic_string_t tmp = *x;
    *x = *y;
    *y = tmp;
}

static int generic_string_construct(generic_string_t *gs,
        generic_memory_manager_t *gmm) {
    gs->gmm = gmm;
    gs->data = g_empty_str;
    gs->size = 0;
    gs->capacity = 0;
    return 0;
}

static void generic_string_destruct(generic_string_t *gs) {
    if (gs->data != g_empty_str) {
        generic_string_deallocate(gs->gmm, gs->data, gs->capacity);
    }
}

static size_t generic_string_size(const generic_string_t *gs) {
    return gs->size;
}

static size_t generic_string_length(const generic_string_t *gs) {
    return gs->size;
}

static int generic_string_empty(const generic_string_t *gs) {
    return gs->size == 0;
}

static generic_string_iterator_t generic_string_begin(generic_string_t *gs) {
    generic_string_iterator_t iter;
    generic_string_iterator_init(&iter, gs, gs->data);
    return iter;
}

static generic_string_iterator_t generic_string_end(generic_string_t *gs) {
    generic_string_iterator_t iter;
    generic_string_iterator_init(&iter, gs, gs->data + gs->size);
    return iter;
}

static char generic_string_front(const generic_string_t *gs) {
    return gs->data[0];
}

static char generic_string_back(const generic_string_t *gs) {
    return gs->data[gs->size - 1];
}

static const char *generic_string_data(const generic_string_t *gs) {
    return gs->data;
}

static const char *generic_string_c_str(const generic_string_t *gs) {
    return gs->data;
}

static char generic_string_get(const generic_string_t *gs, size_t n) {
    return gs->data[n];
}

static void generic_string_set(generic_string_t *gs, size_t n, char c) {
    gs->data[n] = c;
}

static int generic_string_reserve(generic_string_t *gs, size_t n) {
    char *data;
    size_t capacity;
    generic_memory_manager_t *gmm;

    if (n <= gs->capacity) {
        return 0;
    }

    gmm = gs->gmm;
    capacity = n;

    data = generic_string_allocate(gmm, capacity);
    if (!data) {
        return -1;
    }

    memcpy(data, gs->data, gs->size);

    if (gs->data != g_empty_str) {
        gmm->deallocate(gmm, gs->data, gs->capacity);
    }

    gs->data = data;
    gs->capacity = capacity;
    gs->data[gs->size] = '\0';
    return 0;
}

static int generic_string_push_back(generic_string_t *gs, char c) {
    return generic_string_append_char(gs, 1, c);
}

static void generic_string_pop_back(generic_string_t *gs) {
    --gs->size;
    gs->data[gs->size] = '\0';
}

static void generic_string_clear(generic_string_t *gs) {
    gs->size = 0;
    gs->data[0] = '\0';
}

static int generic_string_append_data(generic_string_t *gs,
        const void *src, size_t len) {
    if (len > gs->capacity - gs->size) {
        generic_string_t ngs;
        size_t capacity = generic_string_next_capacity(gs, len);
        if (capacity - gs->size < len) {
            return -1;
        }
        if (generic_string_construct(&ngs, gs->gmm)) {
            return -1;
        }
        if (generic_string_reserve(&ngs, capacity)) {
            generic_string_destruct(&ngs);
            return -1;
        }
        generic_string_assign_data(&ngs, gs->data, gs->size);
        generic_string_append_data(&ngs, src, len);
        generic_string_swap(gs, &ngs);
        generic_string_destruct(&ngs);
        return 0;
    }
    memcpy(gs->data + gs->size, src, len);
    gs->size += len;
    gs->data[gs->size] = '\0';
    return 0;
}

static int generic_string_append_gstr(generic_string_t *gs,
        const generic_string_t *src) {
    return generic_string_append_data(gs, src->data, src->size);
}

static int generic_string_append_cstr(generic_string_t *gs, const char *src) {
    return generic_string_append_data(gs, src, strlen(src));
}

static int generic_string_append_char(generic_string_t *gs,
        size_t len, char c) {
    if (len > gs->capacity - gs->size) {
        generic_string_t ngs;
        size_t capacity = generic_string_next_capacity(gs, len);
        if (capacity - gs->size < len) {
            return -1;
        }
        if (generic_string_construct(&ngs, gs->gmm)) {
            return -1;
        }
        if (generic_string_reserve(&ngs, capacity)) {
            generic_string_destruct(&ngs);
            return -1;
        }
        generic_string_assign_data(&ngs, gs->data, gs->size);
        generic_string_append_char(&ngs, len, c);
        generic_string_swap(gs, &ngs);
        generic_string_destruct(&ngs);
        return 0;
    }
    memset(gs->data + gs->size, c, len);
    gs->size += len;
    gs->data[gs->size] = '\0';
    return 0;
}

static int generic_string_assign_data(generic_string_t *gs,
        const void *src, size_t len) {
    if (len > gs->capacity) {
        generic_string_t ngs;
        size_t capacity;
        if (generic_string_construct(&ngs, gs->gmm)) {
            return -1;
        }
        capacity = generic_string_next_capacity(&ngs, len);
        if (generic_string_reserve(&ngs, capacity)) {
            generic_string_destruct(&ngs);
            return -1;
        }
        generic_string_assign_data(&ngs, src, len);
        generic_string_swap(gs, &ngs);
        generic_string_destruct(&ngs);
        return 0;
    }

    memcpy(gs->data, src, len);
    gs->size = len;
    gs->data[gs->size] = '\0';
    return 0;
}

static int generic_string_assign_gstr(generic_string_t *gs,
        const generic_string_t *src) {
    return generic_string_assign_data(gs, src->data, src->size);
}

static int generic_string_assign_cstr(generic_string_t *gs, const char *src) {
    return generic_string_assign_data(gs, src, strlen(src));
}

static generic_memory_manager_t *
generic_string_memory_manager(const generic_string_t *gs) {
    return gs->gmm;
}

static generic_string_api_t g_generic_string_api = {
    &generic_string_construct,
    &generic_string_destruct,
    &generic_string_size,
    &generic_string_length,
    &generic_string_empty,
    &generic_string_begin,
    &generic_string_end,
    &generic_string_front,
    &generic_string_back,
    &generic_string_data,
    &generic_string_c_str,
    &generic_string_get,
    &generic_string_set,
    &generic_string_reserve,
    &generic_string_push_back,
    &generic_string_pop_back,
    &generic_string_clear,
    &generic_string_append_data,
    &generic_string_append_gstr,
    &generic_string_append_cstr,
    &generic_string_append_char,
    &generic_string_assign_data,
    &generic_string_assign_gstr,
    &generic_string_assign_cstr,
    &generic_string_memory_manager
};

#if defined(__cplusplus)
}
#endif

const generic_string_iterator_api_t *generic_string_iterator_api(void) {
    return generic_pointer_iterator_api();
}

const generic_string_api_t *generic_string_api(void) {
    return &g_generic_string_api;
}

/** @} */

