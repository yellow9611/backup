/**
 * @file
 * @brief Configure forward list, list, hash table and tree table.
 * @internal
 */

#include <stddef.h>
#include "generic_config.h"

/* Assumption:
 * 1. Universal alignment is suitable for any data.
 * 2. Dynamically allocated memory at least meets universal alignment.
 */

#if defined(__cplusplus)
extern "C" {
#endif

static inline size_t generic_alignment(size_t size) {
    const size_t universal = 8;
    static const size_t alignment[8] = {
        1, 1,
        2, 2,
        4, 4, 4, 4
    };
    if (size < universal) {
        return alignment[size];
    }
    return universal;
}

/* alignment must be power of 2 */
static inline size_t generic_upper_round(size_t size, size_t alignment) {
    return (size + alignment - 1) & ~(alignment - 1);
}

#if defined(__cplusplus)
}
#endif

void generic_forward_list_config(generic_forward_list_t *gfl) {
    gfl->data_offset = generic_upper_round(offsetof(generic_forward_list_item_t, data),
            generic_alignment(gfl->gdm->size)) - offsetof(generic_forward_list_item_t, data);
    gfl->item_size = offsetof(generic_forward_list_item_t, data) + gfl->data_offset + gfl->gdm->size;
}

void generic_list_config(generic_list_t *gl) {
    gl->data_offset = generic_upper_round(offsetof(generic_list_item_t, data),
            generic_alignment(gl->gdm->size)) - offsetof(generic_list_item_t, data);
    gl->item_size = offsetof(generic_list_item_t, data) + gl->data_offset + gl->gdm->size;
}

void generic_hash_table_config(generic_hash_table_t *ght) {
    ght->key_offset = generic_upper_round(offsetof(generic_hash_table_item_t, data),
            generic_alignment(ght->gkm->size)) - offsetof(generic_hash_table_item_t, data);
    if (ght->gvm) {
        ght->value_offset = generic_upper_round(offsetof(generic_hash_table_item_t, data)
                + ght->key_offset + ght->gkm->size, generic_alignment(ght->gvm->size))
                - offsetof(generic_hash_table_item_t, data);
        ght->item_size = offsetof(generic_hash_table_item_t, data) + ght->value_offset + ght->gvm->size;
    } else {
        ght->item_size = offsetof(generic_hash_table_item_t, data) + ght->key_offset + ght->gkm->size;
    }
}

void generic_tree_table_config(generic_tree_table_t *gtt) {
    gtt->key_offset = generic_upper_round(offsetof(generic_tree_table_item_t, data),
            generic_alignment(gtt->gkm->size)) - offsetof(generic_tree_table_item_t, data);
    if (gtt->gvm) {
        gtt->value_offset = generic_upper_round(offsetof(generic_tree_table_item_t, data)
                + gtt->key_offset + gtt->gkm->size, generic_alignment(gtt->gvm->size))
                - offsetof(generic_tree_table_item_t, data);
        gtt->item_size = offsetof(generic_tree_table_item_t, data) + gtt->value_offset + gtt->gvm->size;
    } else {
        gtt->item_size = offsetof(generic_tree_table_item_t, data) + gtt->key_offset + gtt->gkm->size;
    }
}

