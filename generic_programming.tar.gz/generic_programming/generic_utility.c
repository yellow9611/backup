/** @addtogroup GenericUtility */

/** @{ */

/**
 * @file
 * @brief Utility for C generic programming.
 */

#include <stdlib.h>
#include "generic_utility.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void *std_allocate(generic_memory_manager_t *gmm, size_t size) {
    return malloc(size);
}

static void std_deallocate(generic_memory_manager_t *gmm, void *p,
        size_t size) {
    free(p);
}

static int uint_equal(const unsigned *lhs, const unsigned *rhs) {
    return *lhs == *rhs;
}

static int uint_less(const unsigned *lhs, const unsigned *rhs) {
    return *lhs < *rhs;
}

static int uint_copy(unsigned *lhs, const unsigned *rhs) {
    *lhs = *rhs;
    return 0;
}

static int uint_assign(unsigned *lhs, const unsigned *rhs) {
    *lhs = *rhs;
    return 0;
}

static void uint_swap(unsigned *a, unsigned *b) {
    unsigned x = *a;
    *a = *b;
    *b = x;
}

static int ulonglong_equal(const unsigned long long *lhs,
        const unsigned long long *rhs) {
    return *lhs == *rhs;
}

static int ulonglong_less(const unsigned long long *lhs,
        const unsigned long long *rhs) {
    return *lhs < *rhs;
}

static int ulonglong_copy(unsigned long long *lhs,
        const unsigned long long *rhs) {
    *lhs = *rhs;
    return 0;
}

static int ulonglong_assign(unsigned long long *lhs,
        const unsigned long long *rhs) {
    *lhs = *rhs;
    return 0;
}

static void ulonglong_swap(unsigned long long *a, unsigned long long *b) {
    unsigned long long x = *a;
    *a = *b;
    *b = x;
}

static int pointer_equal(void **lhs, void **rhs) {
    return *lhs == *rhs;
}

static int pointer_less(void **lhs, void **rhs) {
    return *lhs < *rhs;
}

static int pointer_copy(void **lhs, void **rhs) {
    *lhs = *rhs;
    return 0;
}

static int pointer_assign(void **lhs, void **rhs) {
    *lhs = *rhs;
    return 0;
}

static void pointer_swap(void **a, void **b) {
    void *x = *a;
    *a = *b;
    *b = x;
}

static generic_memory_manager_t g_std_memory_manager = {
    &std_allocate,
    &std_deallocate
};

static generic_data_manager_t g_uint_data_manager = {
    (generic_equal_fp_t)(&uint_equal),
    (generic_less_fp_t)(&uint_less),
    (generic_copy_fp_t)(&uint_copy),
    (generic_assign_fp_t)(&uint_assign),
    (generic_swap_fp_t)(&uint_swap),
    0, /* destruct */
    sizeof(unsigned)
};

static generic_data_manager_t g_ulonglong_data_manager = {
    (generic_equal_fp_t)(&ulonglong_equal),
    (generic_less_fp_t)(&ulonglong_less),
    (generic_copy_fp_t)(&ulonglong_copy),
    (generic_assign_fp_t)(&ulonglong_assign),
    (generic_swap_fp_t)(&ulonglong_swap),
    0, /* destruct */
    sizeof(unsigned long long)
};

static generic_data_manager_t g_pointer_data_manager = {
    (generic_equal_fp_t)(&pointer_equal),
    (generic_less_fp_t)(&pointer_less),
    (generic_copy_fp_t)(&pointer_copy),
    (generic_assign_fp_t)(&pointer_assign),
    (generic_swap_fp_t)(&pointer_swap),
    0, /* destruct */
    sizeof(void *)
};

static void
generic_pointer_iterator_next(generic_pointer_iterator_t *iter) {
    iter->data += iter->size;
}

static void
generic_pointer_iterator_prev(generic_pointer_iterator_t *iter) {
    iter->data -= iter->size;
}

static void
generic_pointer_iterator_move(generic_pointer_iterator_t *iter,
        ptrdiff_t distance) {
    iter->data += iter->size * distance;
}

static void *
generic_pointer_iterator_deref(generic_pointer_iterator_t *iter) {
    return iter->data;
}

static int
generic_pointer_iterator_equal(const generic_pointer_iterator_t *lhs,
        const generic_pointer_iterator_t *rhs) {
    return lhs->data == rhs->data;
}

static ptrdiff_t
generic_pointer_iterator_sub(const generic_pointer_iterator_t *lhs,
        const generic_pointer_iterator_t *rhs) {
    return (lhs->data - rhs->data) / lhs->size;
}

static generic_iterator_tag_t generic_pointer_iterator_category(void) {
    return generic_random_iterator_tag;
}

static size_t generic_pointer_iterator_size(void) {
    return sizeof(generic_pointer_iterator_t);
}

static generic_pointer_iterator_api_t g_generic_pointer_iterator_api = {
    &generic_pointer_iterator_next,
    &generic_pointer_iterator_prev,
    &generic_pointer_iterator_move,
    &generic_pointer_iterator_deref,
    &generic_pointer_iterator_equal,
    &generic_pointer_iterator_sub,
    &generic_pointer_iterator_category,
    &generic_pointer_iterator_size
};

#if defined(__cplusplus)
}
#endif

generic_memory_manager_t *std_memory_manager(void) {
    return &g_std_memory_manager;
}

const generic_data_manager_t *uint_data_manager(void) {
    return &g_uint_data_manager;
}

const generic_data_manager_t *ulonglong_data_manager(void) {
    return &g_ulonglong_data_manager;
}

const generic_data_manager_t *pointer_data_manager(void) {
    return &g_pointer_data_manager;
}

void generic_pointer_iterator_init(generic_pointer_iterator_t *iter,
        void *data, size_t size) {
    iter->api = &g_generic_pointer_iterator_api;
    iter->data = (char *)(data);
    iter->size = size;
}

const generic_pointer_iterator_api_t *generic_pointer_iterator_api(void) {
    return &g_generic_pointer_iterator_api;
}

/*
 * http://en.wikipedia.org/wiki/Fowler_Noll_Vo_hash
 * http://www.isthe.com/chongo/tech/comp/fnv/index.html
 */
static const size_t FNV32_OFFSET_BASIS = 2166136261UL;
static const size_t FNV32_PRIME = 16777619UL; /* 2^24 + 2^8 + 2^7 + 2^4 + 2^1 + 2^0 */
size_t generic_fnv1a32(const void *buf, size_t size) {
    const unsigned char *first = (const unsigned char *)(buf);
    const unsigned char *last = first + size;
    const unsigned char *p = first;
    size_t hash = FNV32_OFFSET_BASIS;
    while (p < last) {
        hash ^= *p;
        hash *= FNV32_PRIME;
        ++p;
    }
    return hash;
}

size_t ucstr_fnv1a32(const unsigned char *buf) {
    size_t hash = FNV32_OFFSET_BASIS;
    const unsigned char *p = buf;
    while (*p) {
        hash ^= *p;
        hash *= FNV32_PRIME;
        ++p;
    }
    return hash;
}

size_t cstr_fnv1a32(const char *buf) {
    return ucstr_fnv1a32((const unsigned char *)(buf));
}

/** @} */

