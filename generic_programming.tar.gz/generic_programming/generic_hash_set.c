/** @addtogroup GenericHashSet */

/** @{ */

/**
 * @file
 * @brief Implementation of hash set and hash multiset.
 */

#include "generic_hash_set.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void
generic_hash_set_iterator_next(generic_hash_set_iterator_t *iter) {
    generic_hash_table_iterator_next(&iter->imp);
}

static const void *
generic_hash_set_iterator_deref(generic_hash_set_iterator_t *iter) {
    return generic_hash_table_iterator_deref(&iter->imp)->key;
}

static int
generic_hash_set_iterator_equal(const generic_hash_set_iterator_t *lhs,
        const generic_hash_set_iterator_t *rhs) {
    return generic_hash_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_set_iterator_category(void) {
    return generic_hash_table_iterator_category();
}

static size_t generic_hash_set_iterator_size(void) {
    return sizeof(generic_hash_set_iterator_t);
}

static generic_hash_set_iterator_api_t g_generic_hash_set_iterator_api = {
    &generic_hash_set_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_set_iterator_deref,
    &generic_hash_set_iterator_equal,
    0, /* sub */
    &generic_hash_set_iterator_category,
    &generic_hash_set_iterator_size
};

static inline void
generic_hash_set_iterator_init(generic_hash_set_iterator_t *iter) {
    iter->api = &g_generic_hash_set_iterator_api;
}

static void
generic_hash_set_local_iterator_next(generic_hash_set_local_iterator_t *iter) {
    generic_hash_table_local_iterator_next(&iter->imp);
}

static const void *
generic_hash_set_local_iterator_deref(generic_hash_set_local_iterator_t *iter) {
    return generic_hash_table_local_iterator_deref(&iter->imp)->key;
}

static int
generic_hash_set_local_iterator_equal(const generic_hash_set_local_iterator_t *lhs,
        const generic_hash_set_local_iterator_t *rhs) {
    return generic_hash_table_local_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_set_local_iterator_category(void) {
    return generic_hash_table_local_iterator_category();
}

static size_t generic_hash_set_local_iterator_size(void) {
    return sizeof(generic_hash_set_local_iterator_t);
}

static generic_hash_set_local_iterator_api_t g_generic_hash_set_local_iterator_api = {
    &generic_hash_set_local_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_set_local_iterator_deref,
    &generic_hash_set_local_iterator_equal,
    0, /* sub */
    &generic_hash_set_local_iterator_category,
    &generic_hash_set_local_iterator_size
};

static inline void
generic_hash_set_local_iterator_init(generic_hash_set_local_iterator_t *iter) {
    iter->api = &g_generic_hash_set_local_iterator_api;
}

static int generic_hash_set_construct(generic_hash_set_t *ghs,
        size_t bucket_hint, generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, generic_hash_fp_t hash) {
    return generic_hash_table_construct(&ghs->imp, bucket_hint,
            gmm, gkm, 0 /* no value */, hash, 1 /* unique */);
}

static void generic_hash_set_destruct(generic_hash_set_t *ghs) {
    generic_hash_table_destruct(&ghs->imp);
}

static size_t generic_hash_set_size(const generic_hash_set_t *ghs) {
    return generic_hash_table_size(&ghs->imp);
}

static int generic_hash_set_empty(const generic_hash_set_t *ghs) {
    return generic_hash_table_empty(&ghs->imp);
}

static generic_hash_set_iterator_t
generic_hash_set_begin(generic_hash_set_t *ghs) {
    generic_hash_set_iterator_t ret;
    generic_hash_set_iterator_init(&ret);
    generic_hash_table_begin(&ghs->imp, &ret.imp);
    return ret;
}

static generic_hash_set_iterator_t
generic_hash_set_end(generic_hash_set_t *ghs) {
    generic_hash_set_iterator_t ret;
    generic_hash_set_iterator_init(&ret);
    generic_hash_table_end(&ghs->imp, &ret.imp);
    return ret;
}

static generic_hash_set_iterator_t
generic_hash_set_find(generic_hash_set_t *ghs, const void *key) {
    generic_hash_set_iterator_t ret;
    generic_hash_set_iterator_init(&ret);
    generic_hash_table_find(&ghs->imp, key, &ret.imp);
    return ret;
}

static size_t generic_hash_set_count(const generic_hash_set_t *ghs,
        const void *key) {
    return generic_hash_table_count(&ghs->imp, key);
}

static void generic_hash_set_equal_range(generic_hash_set_t *ghs,
        const void *key, generic_hash_set_iterator_t *first,
        generic_hash_set_iterator_t *last) {
    generic_hash_set_iterator_init(first);
    generic_hash_set_iterator_init(last);
    generic_hash_table_equal_range(&ghs->imp, key, &first->imp, &last->imp);
}

static generic_hash_set_local_iterator_t
generic_hash_set_local_begin(generic_hash_set_t *ghs, size_t bucket) {
    generic_hash_set_local_iterator_t ret;
    generic_hash_set_local_iterator_init(&ret);
    generic_hash_table_local_begin(&ghs->imp, bucket, &ret.imp);
    return ret;
}

static generic_hash_set_local_iterator_t
generic_hash_set_local_end(generic_hash_set_t *ghs, size_t bucket) {
    generic_hash_set_local_iterator_t ret;
    generic_hash_set_local_iterator_init(&ret);
    generic_hash_table_local_end(&ghs->imp, bucket, &ret.imp);
    return ret;
}

static size_t generic_hash_set_bucket_count(const generic_hash_set_t *ghs) {
    return generic_hash_table_bucket_count(&ghs->imp);
}

static size_t generic_hash_set_bucket_size(const generic_hash_set_t *ghs,
        size_t bucket) {
    return generic_hash_table_bucket_size(&ghs->imp, bucket);
}

static size_t generic_hash_set_bucket(const generic_hash_set_t *ghs,
        const void *key) {
    return generic_hash_table_bucket(&ghs->imp, key);
}

static float generic_hash_set_load_factor(const generic_hash_set_t *ghs) {
    return generic_hash_table_load_factor(&ghs->imp);
}

static float
generic_hash_set_get_max_load_factor(const generic_hash_set_t *ghs) {
    return generic_hash_table_get_max_load_factor(&ghs->imp);
}

static int generic_hash_set_set_max_load_factor(generic_hash_set_t *ghs,
        float max_load_factor) {
    return generic_hash_table_set_max_load_factor(&ghs->imp, max_load_factor);
}

static generic_hash_set_iterator_t
generic_hash_set_insert(generic_hash_set_t *ghs, const void *key) {
    generic_hash_set_iterator_t ret;
    generic_hash_set_iterator_init(&ret);
    generic_hash_table_insert(&ghs->imp, key, 0, &ret.imp);
    return ret;
}

static generic_hash_set_iterator_t
generic_hash_set_erase(generic_hash_set_t *ghs,
        const generic_hash_set_iterator_t *iter) {
    generic_hash_set_iterator_t ret;
    generic_hash_set_iterator_init(&ret);
    generic_hash_table_erase(&ghs->imp, &iter->imp, &ret.imp);
    return ret;
}

static generic_hash_set_local_iterator_t
generic_hash_set_lerase(generic_hash_set_t *ghs,
        const generic_hash_set_local_iterator_t *iter) {
    generic_hash_set_local_iterator_t ret;
    generic_hash_set_local_iterator_init(&ret);
    generic_hash_table_lerase(&ghs->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_hash_set_remove(generic_hash_set_t *ghs,
        const void *key) {
    return generic_hash_table_remove(&ghs->imp, key);
}

static void generic_hash_set_clear(generic_hash_set_t *ghs) {
    generic_hash_table_clear(&ghs->imp);
}

static generic_memory_manager_t *
generic_hash_set_memory_manager(const generic_hash_set_t *ghs) {
    return generic_hash_table_memory_manager(&ghs->imp);
}

static const generic_data_manager_t *
generic_hash_set_data_manager(const generic_hash_set_t *ghs) {
    return generic_hash_table_key_manager(&ghs->imp);
}

static generic_hash_fp_t
generic_hash_set_hash(const generic_hash_set_t *ghs) {
    return generic_hash_table_hash(&ghs->imp);
}

static generic_hash_set_api_t g_generic_hash_set_api = {
    &generic_hash_set_construct,
    &generic_hash_set_destruct,
    &generic_hash_set_size,
    &generic_hash_set_empty,
    &generic_hash_set_begin,
    &generic_hash_set_end,
    &generic_hash_set_find,
    &generic_hash_set_count,
    &generic_hash_set_equal_range,
    &generic_hash_set_local_begin,
    &generic_hash_set_local_end,
    &generic_hash_set_bucket_count,
    &generic_hash_set_bucket_size,
    &generic_hash_set_bucket,
    &generic_hash_set_load_factor,
    &generic_hash_set_get_max_load_factor,
    &generic_hash_set_set_max_load_factor,
    &generic_hash_set_insert,
    &generic_hash_set_erase,
    &generic_hash_set_lerase,
    &generic_hash_set_remove,
    &generic_hash_set_clear,
    &generic_hash_set_memory_manager,
    &generic_hash_set_data_manager,
    &generic_hash_set_hash
};

static void
generic_hash_multiset_iterator_next(generic_hash_multiset_iterator_t *iter) {
    generic_hash_table_iterator_next(&iter->imp);
}

static const void *
generic_hash_multiset_iterator_deref(generic_hash_multiset_iterator_t *iter) {
    return generic_hash_table_iterator_deref(&iter->imp)->key;
}

static int
generic_hash_multiset_iterator_equal(const generic_hash_multiset_iterator_t *lhs,
        const generic_hash_multiset_iterator_t *rhs) {
    return generic_hash_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_multiset_iterator_category(void) {
    return generic_hash_table_iterator_category();
}

static size_t generic_hash_multiset_iterator_size(void) {
    return sizeof(generic_hash_multiset_iterator_t);
}

static generic_hash_multiset_iterator_api_t g_generic_hash_multiset_iterator_api = {
    &generic_hash_multiset_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_multiset_iterator_deref,
    &generic_hash_multiset_iterator_equal,
    0, /* sub */
    &generic_hash_multiset_iterator_category,
    &generic_hash_multiset_iterator_size
};

static inline void
generic_hash_multiset_iterator_init(generic_hash_multiset_iterator_t *iter) {
    iter->api = &g_generic_hash_multiset_iterator_api;
}

static void
generic_hash_multiset_local_iterator_next(generic_hash_multiset_local_iterator_t *iter) {
    generic_hash_table_local_iterator_next(&iter->imp);
}

static const void *
generic_hash_multiset_local_iterator_deref(generic_hash_multiset_local_iterator_t *iter) {
    return generic_hash_table_local_iterator_deref(&iter->imp)->key;
}

static int
generic_hash_multiset_local_iterator_equal(const generic_hash_multiset_local_iterator_t *lhs,
        const generic_hash_multiset_local_iterator_t *rhs) {
    return generic_hash_table_local_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_hash_multiset_local_iterator_category(void) {
    return generic_hash_table_local_iterator_category();
}


static size_t generic_hash_multiset_local_iterator_size(void) {
    return sizeof(generic_hash_multiset_local_iterator_t);
}

static generic_hash_multiset_local_iterator_api_t g_generic_hash_multiset_local_iterator_api = {
    &generic_hash_multiset_local_iterator_next,
    0, /* prev */
    0, /* move */
    &generic_hash_multiset_local_iterator_deref,
    &generic_hash_multiset_local_iterator_equal,
    0, /* sub */
    &generic_hash_multiset_local_iterator_category,
    &generic_hash_multiset_local_iterator_size
};

static inline void
generic_hash_multiset_local_iterator_init(generic_hash_multiset_local_iterator_t *iter) {
    iter->api = &g_generic_hash_multiset_local_iterator_api;
}

static int generic_hash_multiset_construct(generic_hash_multiset_t *ghs,
        size_t bucket_hint, generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, generic_hash_fp_t hash) {
    return generic_hash_table_construct(&ghs->imp, bucket_hint,
            gmm, gkm, 0 /* no value */, hash, 0 /* not unique */);
}

static void generic_hash_multiset_destruct(generic_hash_multiset_t *ghs) {
    generic_hash_table_destruct(&ghs->imp);
}

static size_t
generic_hash_multiset_size(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_size(&ghs->imp);
}

static int
generic_hash_multiset_empty(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_empty(&ghs->imp);
}

static generic_hash_multiset_iterator_t
generic_hash_multiset_begin(generic_hash_multiset_t *ghs) {
    generic_hash_multiset_iterator_t ret;
    generic_hash_multiset_iterator_init(&ret);
    generic_hash_table_begin(&ghs->imp, &ret.imp);
    return ret;
}

static generic_hash_multiset_iterator_t
generic_hash_multiset_end(generic_hash_multiset_t *ghs) {
    generic_hash_multiset_iterator_t ret;
    generic_hash_multiset_iterator_init(&ret);
    generic_hash_table_end(&ghs->imp, &ret.imp);
    return ret;
}

static generic_hash_multiset_iterator_t
generic_hash_multiset_find(generic_hash_multiset_t *ghs, const void *key) {
    generic_hash_multiset_iterator_t ret;
    generic_hash_multiset_iterator_init(&ret);
    generic_hash_table_find(&ghs->imp, key, &ret.imp);
    return ret;
}

static size_t generic_hash_multiset_count(const generic_hash_multiset_t *ghs,
        const void *key) {
    return generic_hash_table_count(&ghs->imp, key);
}

static void generic_hash_multiset_equal_range(generic_hash_multiset_t *ghs,
        const void *key, generic_hash_multiset_iterator_t *first,
        generic_hash_multiset_iterator_t *last) {
    generic_hash_multiset_iterator_init(first);
    generic_hash_multiset_iterator_init(last);
    generic_hash_table_equal_range(&ghs->imp, key, &first->imp, &last->imp);
}

static generic_hash_multiset_local_iterator_t
generic_hash_multiset_local_begin(generic_hash_multiset_t *ghs,
        size_t bucket) {
    generic_hash_multiset_local_iterator_t ret;
    generic_hash_multiset_local_iterator_init(&ret);
    generic_hash_table_local_begin(&ghs->imp, bucket, &ret.imp);
    return ret;
}

static generic_hash_multiset_local_iterator_t
generic_hash_multiset_local_end(generic_hash_multiset_t *ghs,
        size_t bucket) {
    generic_hash_multiset_local_iterator_t ret;
    generic_hash_multiset_local_iterator_init(&ret);
    generic_hash_table_local_end(&ghs->imp, bucket, &ret.imp);
    return ret;
}

static size_t
generic_hash_multiset_bucket_count(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_bucket_count(&ghs->imp);
}

static size_t
generic_hash_multiset_bucket_size(const generic_hash_multiset_t *ghs,
        size_t bucket) {
    return generic_hash_table_bucket_size(&ghs->imp, bucket);
}

static size_t generic_hash_multiset_bucket(const generic_hash_multiset_t *ghs,
        const void *key) {
    return generic_hash_table_bucket(&ghs->imp, key);
}

static float
generic_hash_multiset_load_factor(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_load_factor(&ghs->imp);
}

static float
generic_hash_multiset_get_max_load_factor(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_get_max_load_factor(&ghs->imp);
}

static int
generic_hash_multiset_set_max_load_factor(generic_hash_multiset_t *ghs,
        float max_load_factor) {
    return generic_hash_table_set_max_load_factor(&ghs->imp, max_load_factor);
}

static generic_hash_multiset_iterator_t
generic_hash_multiset_insert(generic_hash_multiset_t *ghs, const void *key) {
    generic_hash_multiset_iterator_t ret;
    generic_hash_multiset_iterator_init(&ret);
    generic_hash_table_insert(&ghs->imp, key, 0, &ret.imp);
    return ret;
}

static generic_hash_multiset_iterator_t
generic_hash_multiset_erase(generic_hash_multiset_t *ghs,
        const generic_hash_multiset_iterator_t *iter) {
    generic_hash_multiset_iterator_t ret;
    generic_hash_multiset_iterator_init(&ret);
    generic_hash_table_erase(&ghs->imp, &iter->imp, &ret.imp);
    return ret;
}

static generic_hash_multiset_local_iterator_t
generic_hash_multiset_lerase(generic_hash_multiset_t *ghs,
        const generic_hash_multiset_local_iterator_t *iter) {
    generic_hash_multiset_local_iterator_t ret;
    generic_hash_multiset_local_iterator_init(&ret);
    generic_hash_table_lerase(&ghs->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_hash_multiset_remove(generic_hash_multiset_t *ghs,
        const void *key) {
    return generic_hash_table_remove(&ghs->imp, key);
}

static void generic_hash_multiset_clear(generic_hash_multiset_t *ghs) {
    generic_hash_table_clear(&ghs->imp);
}

static generic_memory_manager_t *
generic_hash_multiset_memory_manager(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_memory_manager(&ghs->imp);
}

static const generic_data_manager_t *
generic_hash_multiset_data_manager(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_key_manager(&ghs->imp);
}

static generic_hash_fp_t
generic_hash_multiset_hash(const generic_hash_multiset_t *ghs) {
    return generic_hash_table_hash(&ghs->imp);
}

static generic_hash_multiset_api_t g_generic_hash_multiset_api = {
    &generic_hash_multiset_construct,
    &generic_hash_multiset_destruct,
    &generic_hash_multiset_size,
    &generic_hash_multiset_empty,
    &generic_hash_multiset_begin,
    &generic_hash_multiset_end,
    &generic_hash_multiset_find,
    &generic_hash_multiset_count,
    &generic_hash_multiset_equal_range,
    &generic_hash_multiset_local_begin,
    &generic_hash_multiset_local_end,
    &generic_hash_multiset_bucket_count,
    &generic_hash_multiset_bucket_size,
    &generic_hash_multiset_bucket,
    &generic_hash_multiset_load_factor,
    &generic_hash_multiset_get_max_load_factor,
    &generic_hash_multiset_set_max_load_factor,
    &generic_hash_multiset_insert,
    &generic_hash_multiset_erase,
    &generic_hash_multiset_lerase,
    &generic_hash_multiset_remove,
    &generic_hash_multiset_clear,
    &generic_hash_multiset_memory_manager,
    &generic_hash_multiset_data_manager,
    &generic_hash_multiset_hash
};

#if defined(__cplusplus)
}
#endif

const generic_hash_set_iterator_api_t *generic_hash_set_iterator_api(void) {
    return &g_generic_hash_set_iterator_api;
}

const generic_hash_set_local_iterator_api_t *generic_hash_set_local_iterator_api(void) {
    return &g_generic_hash_set_local_iterator_api;
}

const generic_hash_set_api_t *generic_hash_set_api(void) {
    return &g_generic_hash_set_api;
}

const generic_hash_multiset_iterator_api_t *generic_hash_multiset_iterator_api(void) {
    return &g_generic_hash_multiset_iterator_api;
}

const generic_hash_multiset_local_iterator_api_t *generic_hash_multiset_local_iterator_api(void) {
    return &g_generic_hash_multiset_local_iterator_api;
}

const generic_hash_multiset_api_t *generic_hash_multiset_api(void) {
    return &g_generic_hash_multiset_api;
}

/** @} */

