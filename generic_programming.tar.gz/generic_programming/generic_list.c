/** @addtogroup GenericList */

/** @{ */

/**
 * @file
 * @brief Implementation of double list.
 */

#include "generic_config.h"
#include "generic_list.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void generic_list_clear(generic_list_t *);

static inline char *generic_list_item_data(const generic_list_t *gl,
        generic_list_item_t *item) {
    return item->data + gl->data_offset;
}

static void generic_list_iterator_next(generic_list_iterator_t *iter) {
    iter->item = iter->item->next;
}

static void generic_list_iterator_prev(generic_list_iterator_t *iter) {
    iter->item = iter->item->prev;
}

static void *generic_list_iterator_deref(generic_list_iterator_t *iter) {
    return generic_list_item_data(iter->gl, iter->item);
}

static int generic_list_iterator_equal(const generic_list_iterator_t *lhs,
        const generic_list_iterator_t *rhs) {
    return lhs->item == rhs->item;
}

static generic_iterator_tag_t generic_list_iterator_category(void) {
    return generic_bidirectional_iterator_tag;
}

static size_t generic_list_iterator_size(void) {
    return sizeof(generic_list_iterator_t);
}

static generic_list_iterator_api_t g_generic_list_iterator_api = {
    &generic_list_iterator_next,
    &generic_list_iterator_prev,
    0, /* move */
    &generic_list_iterator_deref,
    &generic_list_iterator_equal,
    0, /* sub */
    &generic_list_iterator_category,
    &generic_list_iterator_size
};

static void generic_list_iterator_init(generic_list_iterator_t *iter,
        const generic_list_t *gl, generic_list_item_t *item) {
    iter->api = &g_generic_list_iterator_api;
    iter->gl = gl;
    iter->item = item;
}

static generic_list_item_t *generic_list_create_item(generic_list_t *gl,
        const void *data) {
    generic_memory_manager_t *gmm = gl->gmm;
    const generic_data_manager_t *gdm = gl->gdm;
    generic_list_item_t *item;

    item = (generic_list_item_t *)(gmm->allocate(gmm, gl->item_size));
    if (!item) {
        return 0;
    }

    if (gdm->copy(generic_list_item_data(gl, item), data)) {
        gmm->deallocate(gmm, item, gl->item_size);
        return 0;
    }

    return item;
}

static void generic_list_destroy_item(generic_list_t *gl,
        generic_list_item_t *item) {
    if (gl->gdm->destruct) {
        gl->gdm->destruct(generic_list_item_data(gl, item));
    }
    gl->gmm->deallocate(gl->gmm, item, gl->item_size);
}

static void generic_list_destroy_items(generic_list_t *gl,
        generic_list_item_t *first, generic_list_item_t *last) {
    generic_list_item_t *item = first;
    if (gl->gdm->destruct) {
        while (item != last) {
            generic_list_item_t *next = item->next;
            gl->gdm->destruct(generic_list_item_data(gl, item));
            gl->gmm->deallocate(gl->gmm, item, gl->item_size);
            item = next;
        }
    } else {
        while (item != last) {
            generic_list_item_t *next = item->next;
            gl->gmm->deallocate(gl->gmm, item, gl->item_size);
            item = next;
        }
    }
}

static int generic_list_construct(generic_list_t *gl,
        generic_memory_manager_t *gmm, const generic_data_manager_t *gdm) {
    gl->gmm = gmm;
    gl->gdm = gdm;
    gl->sentry.next = &gl->sentry;
    gl->sentry.prev = &gl->sentry;
    gl->item_count = 0;
    generic_list_config(gl);
    return 0;
}

static void generic_list_destruct(generic_list_t *gl) {
    generic_list_clear(gl);
}

static size_t generic_list_size(const generic_list_t *gl) {
    return gl->item_count;
}

static int generic_list_empty(const generic_list_t *gl) {
    return gl->item_count == 0;
}

static generic_list_iterator_t generic_list_begin(generic_list_t *gl) {
    generic_list_iterator_t ret;
    generic_list_iterator_init(&ret, gl, gl->sentry.next);
    return ret;
}

static generic_list_iterator_t generic_list_end(generic_list_t *gl) {
    generic_list_iterator_t ret;
    generic_list_iterator_init(&ret, gl, &gl->sentry);
    return ret;
}

static void *generic_list_front(generic_list_t *gl) {
    return generic_list_item_data(gl, gl->sentry.next);
}

static void *generic_list_back(generic_list_t *gl) {
    return generic_list_item_data(gl, gl->sentry.prev);
}

static generic_list_iterator_t generic_list_insert(generic_list_t *gl,
        const generic_list_iterator_t *iter, const void *data) {
    generic_list_iterator_t ret;
    generic_list_item_t *item;

    item = generic_list_create_item(gl, data);
    if (!item) {
        return generic_list_end(gl);
    }

    item->next = iter->item;
    item->prev = iter->item->prev;
    item->prev->next = item;
    item->next->prev = item;
    ++gl->item_count;

    generic_list_iterator_init(&ret, gl, item);
    return ret;
}

static generic_list_iterator_t generic_list_erase(generic_list_t *gl,
        const generic_list_iterator_t *iter) {
    generic_list_iterator_t ret;
    generic_list_item_t *deletion = iter->item;

    deletion->prev->next = deletion->next;
    deletion->next->prev = deletion->prev;

    generic_list_destroy_item(gl, deletion);
    --gl->item_count;

    generic_list_iterator_init(&ret, gl, iter->item->next);
    return ret;
}

static int generic_list_push_front(generic_list_t *gl,
        const void *data) {
    generic_list_iterator_t begin;
    generic_list_iterator_t iter;
    generic_list_iterator_t end;

    begin = generic_list_begin(gl);
    iter = generic_list_insert(gl, &begin, data);
    end = generic_list_end(gl);

    return generic_list_iterator_equal(&iter, &end);
}

static void generic_list_pop_front(generic_list_t *gl) {
    generic_list_iterator_t begin;
    begin = generic_list_begin(gl);
    generic_list_erase(gl, &begin);
}

static int generic_list_push_back(generic_list_t *gl,
        const void *data) {
    generic_list_iterator_t iter;
    generic_list_iterator_t end;

    end = generic_list_end(gl);
    iter = generic_list_insert(gl, &end, data);

    return generic_list_iterator_equal(&iter, &end);
}

static void generic_list_pop_back(generic_list_t *gl) {
    generic_list_iterator_t iter;
    iter = generic_list_end(gl);
    generic_list_iterator_prev(&iter); /* the last element */
    generic_list_erase(gl, &iter);
}

static void generic_list_clear(generic_list_t *gl) {
    generic_list_destroy_items(gl, gl->sentry.next, &gl->sentry);
    gl->sentry.next = &gl->sentry;
    gl->sentry.prev = &gl->sentry;
    gl->item_count = 0;
}

static generic_memory_manager_t *
generic_list_memory_manager(const generic_list_t *gl) {
    return gl->gmm;
}

static const generic_data_manager_t *
generic_list_data_manager(const generic_list_t *gl) {
    return gl->gdm;
}

static generic_list_api_t g_generic_list_api = {
    &generic_list_construct,
    &generic_list_destruct,
    &generic_list_size,
    &generic_list_empty,
    &generic_list_begin,
    &generic_list_end,
    &generic_list_front,
    &generic_list_back,
    &generic_list_insert,
    &generic_list_erase,
    &generic_list_push_front,
    &generic_list_pop_front,
    &generic_list_push_back,
    &generic_list_pop_back,
    &generic_list_clear,
    &generic_list_memory_manager,
    &generic_list_data_manager
};

#if defined(__cplusplus)
}
#endif

const generic_list_iterator_api_t *generic_list_iterator_api(void) {
    return &g_generic_list_iterator_api;
}

const generic_list_api_t *generic_list_api(void) {
    return &g_generic_list_api;
}

/** @} */

