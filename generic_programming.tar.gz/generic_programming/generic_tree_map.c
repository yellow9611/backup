/** @addtogroup GenericTreeMap */

/** @{ */

/**
 * @file
 * @brief Implementation of tree map and tree multimap.
 */

#include "generic_tree_map.h"

#if defined(__cplusplus)
extern "C" {
#endif

static void
generic_tree_map_iterator_next(generic_tree_map_iterator_t *iter) {
    generic_tree_table_iterator_next(&iter->imp);
}

static void
generic_tree_map_iterator_prev(generic_tree_map_iterator_t *iter) {
    generic_tree_table_iterator_prev(&iter->imp);
}

static generic_tree_map_data_t *
generic_tree_map_iterator_deref(generic_tree_map_iterator_t *iter) {
    return (generic_tree_map_data_t *)(generic_tree_table_iterator_deref(&iter->imp));
}

static int
generic_tree_map_iterator_equal(const generic_tree_map_iterator_t *lhs,
        const generic_tree_map_iterator_t *rhs) {
    return generic_tree_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_tree_map_iterator_category(void) {
    return generic_tree_table_iterator_category();
}

static size_t generic_tree_map_iterator_size(void) {
    return sizeof(generic_tree_map_iterator_t);
}

static generic_tree_map_iterator_api_t g_generic_tree_map_iterator_api = {
    &generic_tree_map_iterator_next,
    &generic_tree_map_iterator_prev,
    0, /* move */
    &generic_tree_map_iterator_deref,
    &generic_tree_map_iterator_equal,
    0, /* sub */
    &generic_tree_map_iterator_category,
    &generic_tree_map_iterator_size,
};

static inline void
generic_tree_map_iterator_init(generic_tree_map_iterator_t *iter) {
    iter->api = &g_generic_tree_map_iterator_api;
}

static int generic_tree_map_construct(generic_tree_map_t *gtm,
        generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm) {
    return generic_tree_table_construct(&gtm->imp,
            gmm, gkm, gvm, 1 /* unique */);
}

static void generic_tree_map_destruct(generic_tree_map_t *gtm) {
    generic_tree_table_destruct(&gtm->imp);
}

static size_t generic_tree_map_size(const generic_tree_map_t *gtm) {
    return generic_tree_table_size(&gtm->imp);
}

static int generic_tree_map_empty(const generic_tree_map_t *gtm) {
    return generic_tree_table_empty(&gtm->imp);
}

static generic_tree_map_iterator_t
generic_tree_map_begin(generic_tree_map_t *gtm) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_begin(&gtm->imp, &ret.imp);
    return ret;
}

static generic_tree_map_iterator_t
generic_tree_map_end(generic_tree_map_t *gtm) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_end(&gtm->imp, &ret.imp);
    return ret;
}

static generic_tree_map_iterator_t
generic_tree_map_find(generic_tree_map_t *gtm, const void *key) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_find(&gtm->imp, key, &ret.imp);
    return ret;
}

static size_t generic_tree_map_count(const generic_tree_map_t *gtm,
        const void *key) {
    return generic_tree_table_count(&gtm->imp, key);
}

static void generic_tree_map_equal_range(generic_tree_map_t *gtm,
        const void *key, generic_tree_map_iterator_t *first,
        generic_tree_map_iterator_t *last) {
    generic_tree_map_iterator_init(first);
    generic_tree_map_iterator_init(last);
    generic_tree_table_equal_range(&gtm->imp, key, &first->imp, &last->imp);
}

static generic_tree_map_iterator_t
generic_tree_map_lower_bound(generic_tree_map_t *gtm, const void *key) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_lower_bound(&gtm->imp, key, &ret.imp);
    return ret;
}

static generic_tree_map_iterator_t
generic_tree_map_upper_bound(generic_tree_map_t *gtm, const void *key) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_upper_bound(&gtm->imp, key, &ret.imp);
    return ret;
}

static void *generic_tree_map_at(generic_tree_map_t *gtm, const void *key) {
    generic_tree_map_data_t *data;
    generic_tree_map_iterator_t iter;
    generic_tree_map_iterator_t end;

    iter = generic_tree_map_find(gtm, key);
    if (generic_tree_map_iterator_equal(&iter, &end)) {
        return 0;
    }

    data = generic_tree_map_iterator_deref(&iter);
    return data->value;
}

static generic_tree_map_iterator_t
generic_tree_map_insert(generic_tree_map_t *gtm,
        const void *key, const void *value) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_insert(&gtm->imp, key, value, &ret.imp);
    return ret;
}

static generic_tree_map_iterator_t
generic_tree_map_erase(generic_tree_map_t *gtm,
        const generic_tree_map_iterator_t *iter) {
    generic_tree_map_iterator_t ret;
    generic_tree_map_iterator_init(&ret);
    generic_tree_table_erase(&gtm->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_tree_map_remove(generic_tree_map_t *gtm,
        const void *key) {
    return generic_tree_table_remove(&gtm->imp, key);
}

static void generic_tree_map_clear(generic_tree_map_t *gtm) {
    generic_tree_table_clear(&gtm->imp);
}

static generic_memory_manager_t *
generic_tree_map_memory_manager(const generic_tree_map_t *gtm) {
    return generic_tree_table_memory_manager(&gtm->imp);
}

static const generic_data_manager_t *
generic_tree_map_key_manager(const generic_tree_map_t *gtm) {
    return generic_tree_table_key_manager(&gtm->imp);
}

static const generic_data_manager_t *
generic_tree_map_value_manager(const generic_tree_map_t *gtm) {
    return generic_tree_table_value_manager(&gtm->imp);
}

static generic_tree_map_api_t g_generic_tree_map_api = {
    &generic_tree_map_construct,
    &generic_tree_map_destruct,
    &generic_tree_map_size,
    &generic_tree_map_empty,
    &generic_tree_map_begin,
    &generic_tree_map_end,
    &generic_tree_map_find,
    &generic_tree_map_count,
    &generic_tree_map_equal_range,
    &generic_tree_map_lower_bound,
    &generic_tree_map_upper_bound,
    &generic_tree_map_at,
    &generic_tree_map_insert,
    &generic_tree_map_erase,
    &generic_tree_map_remove,
    &generic_tree_map_clear,
    &generic_tree_map_memory_manager,
    &generic_tree_map_key_manager,
    &generic_tree_map_value_manager
};

static void
generic_tree_multimap_iterator_next(generic_tree_multimap_iterator_t *iter) {
    generic_tree_table_iterator_next(&iter->imp);
}

static void
generic_tree_multimap_iterator_prev(generic_tree_multimap_iterator_t *iter) {
    generic_tree_table_iterator_prev(&iter->imp);
}

static generic_tree_multimap_data_t *
generic_tree_multimap_iterator_deref(generic_tree_multimap_iterator_t *iter) {
    return (generic_tree_multimap_data_t *)(generic_tree_table_iterator_deref(&iter->imp));
}

static int
generic_tree_multimap_iterator_equal(const generic_tree_multimap_iterator_t *lhs,
        const generic_tree_multimap_iterator_t *rhs) {
    return generic_tree_table_iterator_equal(&lhs->imp, &rhs->imp);
}

static generic_iterator_tag_t generic_tree_multimap_iterator_category(void) {
    return generic_tree_table_iterator_category();
}

static size_t generic_tree_multimap_iterator_size(void) {
    return sizeof(generic_tree_multimap_iterator_t);
}

static generic_tree_multimap_iterator_api_t g_generic_tree_multimap_iterator_api = {
    &generic_tree_multimap_iterator_next,
    &generic_tree_multimap_iterator_prev,
    0, /* move */
    &generic_tree_multimap_iterator_deref,
    &generic_tree_multimap_iterator_equal,
    0, /* sub */
    &generic_tree_multimap_iterator_category,
    &generic_tree_multimap_iterator_size
};

static inline void
generic_tree_multimap_iterator_init(generic_tree_multimap_iterator_t *iter) {
    iter->api = &g_generic_tree_multimap_iterator_api;
}

static int generic_tree_multimap_construct(generic_tree_multimap_t *gtm,
        generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm) {
    return generic_tree_table_construct(&gtm->imp,
            gmm, gkm, gvm, 0 /* not unique */);
}

static void generic_tree_multimap_destruct(generic_tree_multimap_t *gtm) {
    generic_tree_table_destruct(&gtm->imp);
}

static size_t
generic_tree_multimap_size(const generic_tree_multimap_t *gtm) {
    return generic_tree_table_size(&gtm->imp);
}

static int
generic_tree_multimap_empty(const generic_tree_multimap_t *gtm) {
    return generic_tree_table_empty(&gtm->imp);
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_begin(generic_tree_multimap_t *gtm) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_begin(&gtm->imp, &ret.imp);
    return ret;
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_end(generic_tree_multimap_t *gtm) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_end(&gtm->imp, &ret.imp);
    return ret;
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_find(generic_tree_multimap_t *gtm, const void *key) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_find(&gtm->imp, key, &ret.imp);
    return ret;
}

static size_t generic_tree_multimap_count(const generic_tree_multimap_t *gtm,
        const void *key) {
    return generic_tree_table_count(&gtm->imp, key);
}

static void generic_tree_multimap_equal_range(generic_tree_multimap_t *gtm,
        const void *key, generic_tree_multimap_iterator_t *first,
        generic_tree_multimap_iterator_t *last) {
    generic_tree_multimap_iterator_init(first);
    generic_tree_multimap_iterator_init(last);
    generic_tree_table_equal_range(&gtm->imp, key, &first->imp, &last->imp);
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_lower_bound(generic_tree_multimap_t *gtm,
        const void *key) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_lower_bound(&gtm->imp, key, &ret.imp);
    return ret;
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_upper_bound(generic_tree_multimap_t *gtm,
        const void *key) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_upper_bound(&gtm->imp, key, &ret.imp);
    return ret;
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_insert(generic_tree_multimap_t *gtm,
        const void *key, const void *value) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_insert(&gtm->imp, key, value, &ret.imp);
    return ret;
}

static generic_tree_multimap_iterator_t
generic_tree_multimap_erase(generic_tree_multimap_t *gtm,
        const generic_tree_multimap_iterator_t *iter) {
    generic_tree_multimap_iterator_t ret;
    generic_tree_multimap_iterator_init(&ret);
    generic_tree_table_erase(&gtm->imp, &iter->imp, &ret.imp);
    return ret;
}

static size_t generic_tree_multimap_remove(generic_tree_multimap_t *gtm,
        const void *key) {
    return generic_tree_table_remove(&gtm->imp, key);
}

static void generic_tree_multimap_clear(generic_tree_multimap_t *gtm) {
    generic_tree_table_clear(&gtm->imp);
}

static generic_memory_manager_t *
generic_tree_multimap_memory_manager(const generic_tree_multimap_t *gtm) {
    return generic_tree_table_memory_manager(&gtm->imp);
}

static const generic_data_manager_t *
generic_tree_multimap_key_manager(const generic_tree_multimap_t *gtm) {
    return generic_tree_table_key_manager(&gtm->imp);
}

static const generic_data_manager_t *
generic_tree_multimap_value_manager(const generic_tree_multimap_t *gtm) {
    return generic_tree_table_value_manager(&gtm->imp);
}

static generic_tree_multimap_api_t g_generic_tree_multimap_api = {
    &generic_tree_multimap_construct,
    &generic_tree_multimap_destruct,
    &generic_tree_multimap_size,
    &generic_tree_multimap_empty,
    &generic_tree_multimap_begin,
    &generic_tree_multimap_end,
    &generic_tree_multimap_find,
    &generic_tree_multimap_count,
    &generic_tree_multimap_equal_range,
    &generic_tree_multimap_lower_bound,
    &generic_tree_multimap_upper_bound,
    &generic_tree_multimap_insert,
    &generic_tree_multimap_erase,
    &generic_tree_multimap_remove,
    &generic_tree_multimap_clear,
    &generic_tree_multimap_memory_manager,
    &generic_tree_multimap_key_manager,
    &generic_tree_multimap_value_manager
};

#if defined(__cplusplus)
}
#endif

const generic_tree_map_iterator_api_t *generic_tree_map_iterator_api(void) {
    return &g_generic_tree_map_iterator_api;
}

const generic_tree_map_api_t *generic_tree_map_api(void) {
    return &g_generic_tree_map_api;
}

const generic_tree_multimap_iterator_api_t *generic_tree_multimap_iterator_api(void) {
    return &g_generic_tree_multimap_iterator_api;
}

const generic_tree_multimap_api_t *generic_tree_multimap_api(void) {
    return &g_generic_tree_multimap_api;
}

/** @} */

