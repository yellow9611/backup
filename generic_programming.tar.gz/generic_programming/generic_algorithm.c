/** @addtogroup GenericAlgorithm */

/** @{ */

/**
 * @file
 * @brief Implementation of generic algorithm.
 */

#include <string.h>
#include <assert.h>
#include "generic_algorithm.h"

void generic_for_each(const generic_iterator_t *first,
        const generic_iterator_t *last, generic_actor_t *actor) {
    const generic_iterator_api_t *api = first->api;
    generic_iterator_t iter;

    assert(sizeof(iter) >= api->size());
    memcpy(&iter, first, api->size());

    while (!api->equal(&iter, last)) {
        actor->act(actor, api->deref(&iter));
        api->next(&iter);
    }
}

void generic_find_if(const generic_iterator_t *first,
        const generic_iterator_t *last,
        const generic_predicator_t *predicator,
        generic_iterator_t *ret) {
    const generic_iterator_api_t *api = first->api;
    generic_iterator_t iter;

    assert(sizeof(iter) >= api->size());
    memcpy(&iter, first, api->size());

    while (!api->equal(&iter, last)) {
        if (predicator->predicate(predicator, api->deref(&iter))) {
            break;
        }
        api->next(&iter);
    }

    memcpy(ret, &iter, api->size());
}

ptrdiff_t generic_distance(const generic_iterator_t *first,
        const generic_iterator_t *last) {
    const generic_iterator_api_t *api = first->api;
    if (api->category() == generic_random_iterator_tag) {
        return api->sub(last, first);
    } else {
        size_t count = 0;
        generic_iterator_t iter;
        assert(sizeof(iter) >= api->size());
        memcpy(&iter, first, api->size());
        while (!api->equal(&iter, last)) {
            ++count;
            api->next(&iter);
        }
        return count;
    }
}

/** @} */

