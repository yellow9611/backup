/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericTreeMap
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Tree map and tree multimap.
 * @details Key and value shall be copyable.
 * Less operation shall be applicable to key.
 * Elemenst of the container are ordered.
 */

/** @example test_generic_tree_map.c */

#if !defined(GENERIC_TREE_MAP_H)
#define GENERIC_TREE_MAP_H

#include <stddef.h>
#include "generic_utility.h"
#include "generic_tree_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_tree_map_api_t generic_tree_map_api_t;
typedef struct generic_tree_map_t generic_tree_map_t;
typedef struct generic_tree_map_iterator_t generic_tree_map_iterator_t;
typedef struct generic_tree_map_iterator_api_t generic_tree_map_iterator_api_t;
typedef struct generic_tree_map_data_t generic_tree_map_data_t;

/** @brief Get API of generic tree map iterator. */
const generic_tree_map_iterator_api_t *generic_tree_map_iterator_api(void);

/** @brief Get API of generic tree map. */
const generic_tree_map_api_t *generic_tree_map_api(void);

/** @brief Element of tree map. */
struct generic_tree_map_data_t {
    const void *key;
    void *value;
};

/** @brief API of generic tree map iterator. */
struct generic_tree_map_iterator_api_t {
    void (*next)(generic_tree_map_iterator_t *);
    void (*prev)(generic_tree_map_iterator_t *);
    void (*move)(generic_tree_map_iterator_t *, ptrdiff_t); /* 0 */
    generic_tree_map_data_t *(*deref)(generic_tree_map_iterator_t *);
    int (*equal)(const generic_tree_map_iterator_t *,
            const generic_tree_map_iterator_t *);
    ptrdiff_t (*sub)(const generic_tree_map_iterator_t *,
            const generic_tree_map_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic tree map iterator.
 * @attention Only member @a api is public.
 */
struct generic_tree_map_iterator_t {
    const generic_tree_map_iterator_api_t *api;
    generic_tree_table_iterator_t imp;
};

/**
 * @brief API of generic tree map.
 * @attention Multiple elements with the same key are not allowed.
 */
struct generic_tree_map_api_t {
    /**
     * @brief Construct one empty tree map.
     * @return Upon successful completion, It shall return 0.
     * @param gkm Key manager.
     * @param gvm Value manager.
     */
    int (*construct)(generic_tree_map_t *,
            generic_memory_manager_t *, const generic_data_manager_t *gkm,
            const generic_data_manager_t *gvm);

    /** @brief Destruct the tree map. */
    void (*destruct)(generic_tree_map_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_tree_map_t *);

    /** @brief Test if tree map is empty or not. */
    int (*empty)(const generic_tree_map_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_tree_map_iterator_t (*begin)(generic_tree_map_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_tree_map_iterator_t (*end)(generic_tree_map_t *);

    /**
     * @brief Find the element that has @a key.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of tree map.
     */
    generic_tree_map_iterator_t (*find)(generic_tree_map_t *,
        const void *key);

    /** @brief Get the number of elements that have @a key. */
    size_t (*count)(const generic_tree_map_t *, const void *key);

    /**
     * @brief Get the range of elements that have @a key.
     * @param[out] begin Points to the first element that has @a key.
     * @param[out] end Points after the last element that has @a key.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_tree_map_t *, const void *key,
            generic_tree_map_iterator_t *begin,
            generic_tree_map_iterator_t *end);

    /**
     * @brief Get the iterator that points to the first element whose
     * key is not less than @a key.
     * @attention If no such element, it shall be end of tree map.
     */
    generic_tree_map_iterator_t (*lower_bound)(generic_tree_map_t *,
            const void *key);

    /**
     * @brief Get the iterator that points to the first element whose
     * key is greater than @a key.
     * @attention If no such element, it shall be end of tree map.
     */
    generic_tree_map_iterator_t (*upper_bound)(generic_tree_map_t *,
            const void *key);

    /**
     * @brief Get value address of the element that has @a key.
     * @return If no such element exists, it shall return 0.
     */
    void *(*at)(generic_tree_map_t *, const void *key);

    /**
     * @brief Insert one element with @a key and @a value.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of tree map.
     */
    generic_tree_map_iterator_t (*insert)(generic_tree_map_t *,
            const void *key, const void *value);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_tree_map_iterator_t (*erase)(generic_tree_map_t *,
            const generic_tree_map_iterator_t *iter);

    /**
     * @brief Erase all elements that have @a key.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_tree_map_t *, const void *key);

    /** @brief Erase all elements. */
    void (*clear)(generic_tree_map_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_tree_map_t *);

    /** @brief Get key manager. */
    const generic_data_manager_t *(*key_manager)(const generic_tree_map_t *);

    /** @brief Get value manager. */
    const generic_data_manager_t *(*value_manager)(const generic_tree_map_t *);
};

/**
 * @brief Representation of tree map.
 * @attention All members are private.
 */
struct generic_tree_map_t {
    generic_tree_table_t imp;
};

typedef struct generic_tree_multimap_api_t generic_tree_multimap_api_t;
typedef struct generic_tree_multimap_t generic_tree_multimap_t;
typedef struct generic_tree_multimap_iterator_t generic_tree_multimap_iterator_t;
typedef struct generic_tree_multimap_iterator_api_t generic_tree_multimap_iterator_api_t;
typedef struct generic_tree_multimap_data_t generic_tree_multimap_data_t;

/** @brief Get API of generic tree multimap iterator. */
const generic_tree_multimap_iterator_api_t *generic_tree_multimap_iterator_api(void);

/** @brief Get API of generic tree multimap. */
const generic_tree_multimap_api_t *generic_tree_multimap_api(void);

/** @brief Element of tree multimap. */
struct generic_tree_multimap_data_t {
    const void *key;
    void *value;
};

/** @brief API of generic tree multimap iterator. */
struct generic_tree_multimap_iterator_api_t {
    void (*next)(generic_tree_multimap_iterator_t *);
    void (*prev)(generic_tree_multimap_iterator_t *);
    void (*move)(generic_tree_multimap_iterator_t *, ptrdiff_t); /* 0 */
    generic_tree_multimap_data_t *(*deref)(generic_tree_multimap_iterator_t *);
    int (*equal)(const generic_tree_multimap_iterator_t *,
            const generic_tree_multimap_iterator_t *);
    ptrdiff_t (*sub)(const generic_tree_multimap_iterator_t *,
            const generic_tree_multimap_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic tree multimap iterator.
 * @attention Only member @a api is public.
 */
struct generic_tree_multimap_iterator_t {
    const generic_tree_multimap_iterator_api_t *api;
    generic_tree_table_iterator_t imp;
};

/**
 * @brief API of generic tree multimap.
 * @attention Multiple elements with the same key are allowed.
 */
struct generic_tree_multimap_api_t {
    /**
     * @brief Construct one empty tree multimap.
     * @return Upon successful completion, It shall return 0.
     * @param gkm Key manager.
     * @param gvm Value manager.
     */
    int (*construct)(generic_tree_multimap_t *,
            generic_memory_manager_t *, const generic_data_manager_t *gkm,
            const generic_data_manager_t *gvm);

    /** @brief Destruct the tree multimap. */
    void (*destruct)(generic_tree_multimap_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_tree_multimap_t *);

    /** @brief Test if tree multimap is empty or not. */
    int (*empty)(const generic_tree_multimap_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_tree_multimap_iterator_t (*begin)(generic_tree_multimap_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_tree_multimap_iterator_t (*end)(generic_tree_multimap_t *);

    /**
     * @brief Find one element that has @a key.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of tree multimap.
     */
    generic_tree_multimap_iterator_t (*find)(generic_tree_multimap_t *,
            const void *key);

    /** @brief Get the number of elements that have @a key. */
    size_t (*count)(const generic_tree_multimap_t *, const void *key);

    /**
     * @brief Get the range of elements that have @a key.
     * @param[out] begin Points to the first element that has @a key.
     * @param[out] end Points after the last element that has @a key.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_tree_multimap_t *, const void *key,
            generic_tree_multimap_iterator_t *begin,
            generic_tree_multimap_iterator_t *end);

    /**
     * @brief Get the iterator that points to the first element whose
     * key is not less than @a key.
     * @attention If no such element, it shall be end of tree multimap.
     */
    generic_tree_multimap_iterator_t (*lower_bound)(generic_tree_multimap_t *,
            const void *key);

    /**
     * @brief Get the iterator that points to the first element whose
     * key is greater than @a key.
     * @attention If no such element, it shall be end of tree multimap.
     */
    generic_tree_multimap_iterator_t (*upper_bound)(generic_tree_multimap_t *,
            const void *key);

    /**
     * @brief Insert one element with @a key and @a value.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of tree multimap.
     */
    generic_tree_multimap_iterator_t (*insert)(generic_tree_multimap_t *,
            const void *key, const void *value);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_tree_multimap_iterator_t (*erase)(generic_tree_multimap_t *,
            const generic_tree_multimap_iterator_t *iter);
    /**
     * @brief Erase all elements that have @a key.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_tree_multimap_t *, const void *);

    /** @brief Erase all elements. */
    void (*clear)(generic_tree_multimap_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_tree_multimap_t *);

    /** @brief Get key manager. */
    const generic_data_manager_t *(*key_manager)(const generic_tree_multimap_t *);

    /** @brief Get value manager. */
    const generic_data_manager_t *(*value_manager)(const generic_tree_multimap_t *);
};

/**
 * @brief Representation of tree multimap.
 * @attention All members are private.
 */
struct generic_tree_multimap_t {
    generic_tree_table_t imp;
};

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_TREE_MAP_H */

/** @} */

