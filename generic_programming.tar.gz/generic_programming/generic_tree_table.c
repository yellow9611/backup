/**
 * @file
 * @brief Tree table that facilitates to implement tree map and tree set.
 * @internal
 */

#include <assert.h>
#include "generic_config.h"
#include "generic_tree_table.h"

/* MIT: Introduction to Algorithm
 * Chapter: Red-Black Trees
 */

#if defined(__cplusplus)
extern "C" {
#endif

static inline char *generic_tree_table_item_key(const generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item->data + gtt->key_offset;
}

static inline char *generic_tree_table_item_value(const generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item->data + gtt->value_offset;
}

static void generic_tree_table_iterator_init(generic_tree_table_iterator_t *iter,
        generic_tree_table_t *gtt, generic_tree_table_item_t *item) {
    iter->gtt = gtt;
    iter->item = item;
}

/* root and nil are always black */

#define RED 0
#define BLACK 1

static inline generic_tree_table_item_t *
generic_tree_table_nil_item(generic_tree_table_t *gtt) {
    return &gtt->sentinel;
}

static inline generic_tree_table_item_t *
generic_tree_table_root_item(generic_tree_table_t *gtt) {
    return gtt->sentinel.parent;
}

static inline generic_tree_table_item_t *
generic_tree_table_leftmost_item(generic_tree_table_t *gtt) {
    return gtt->sentinel.left;
}

static inline generic_tree_table_item_t *
generic_tree_table_rightmost_item(generic_tree_table_t *gtt) {
    return gtt->sentinel.right;
}

static inline int
generic_tree_table_item_is_nil(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item == generic_tree_table_nil_item(gtt);
}

static inline int
generic_tree_table_item_is_root(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item == generic_tree_table_root_item(gtt);
}

static inline int
generic_tree_table_item_is_leftmost(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item == generic_tree_table_leftmost_item(gtt);
}

static inline int
generic_tree_table_item_is_rightmost(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    return item == generic_tree_table_rightmost_item(gtt);
}

static inline void generic_tree_table_set_root(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item)  {
    gtt->sentinel.parent = item;
}

static inline void generic_tree_table_set_leftmost(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item)  {
    gtt->sentinel.left = item;
}

static inline void generic_tree_table_set_rightmost(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item)  {
    gtt->sentinel.right = item;
}

static inline void
generic_tree_table_item_set_parent(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item,
        generic_tree_table_item_t *parent) {
    if (!generic_tree_table_item_is_nil(gtt, item)) {
        item->parent = parent;
    }
}

static inline void
generic_tree_table_item_set_color(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item,
        char color) {
    if (!generic_tree_table_item_is_nil(gtt, item)) {
        item->color = color;
    }
}

static inline int
generic_tree_table_item_is_red(generic_tree_table_item_t *item) {
    return item->color == RED;
}

static inline int
generic_tree_table_item_is_black(generic_tree_table_item_t *item) {
    return item->color == BLACK;
}

static void generic_tree_table_check_invariant(generic_tree_table_t *gtt) {
    assert(generic_tree_table_root_item(gtt)->color == BLACK);
    assert(generic_tree_table_nil_item(gtt)->color == BLACK);
    assert(generic_tree_table_root_item(gtt)->parent == generic_tree_table_nil_item(gtt));
}

static void generic_tree_table_init_invariant(generic_tree_table_t *gtt) {
    /* root is nil
     * root's parent is nil
     * root and nil are black
     */
    gtt->sentinel.parent = &gtt->sentinel; /* root */
    gtt->sentinel.color = BLACK;
}

/* x != nil && x->right != nil */
static void
generic_tree_table_left_rotate(generic_tree_table_t *gtt,
        generic_tree_table_item_t *x) {
    generic_tree_table_item_t *y;

    assert(!generic_tree_table_item_is_nil(gtt, x));

    y = x->right;
    assert(!generic_tree_table_item_is_nil(gtt, y));

    x->right = y->left;
    /* y->left may be nil */
    generic_tree_table_item_set_parent(gtt, y->left, x);
    y->parent = x->parent;
    if (generic_tree_table_item_is_root(gtt, x)) {
        generic_tree_table_set_root(gtt, y);
    } else {
        /* x->parent != nil */
        assert(!generic_tree_table_item_is_nil(gtt, x->parent));
        if (x == x->parent->left) {
            x->parent->left = y;
        } else {
            x->parent->right = y;
        }
    }
    y->left = x;
    x->parent = y;
}

/* y != nil && y->left != nil */
static void
generic_tree_table_right_rotate(generic_tree_table_t *gtt,
        generic_tree_table_item_t *y) {
    generic_tree_table_item_t *x;
    assert(!generic_tree_table_item_is_nil(gtt, y));
    
    x = y->left;
    assert(!generic_tree_table_item_is_nil(gtt, x));
    y->left = x->right;
    /* x->right may be nil */
    generic_tree_table_item_set_parent(gtt, x->right, y);
    x->parent = y->parent;
    if (generic_tree_table_item_is_root(gtt, y)) {
        generic_tree_table_set_root(gtt, x);
    } else {
        /* y->parent != nil */
        assert(!generic_tree_table_item_is_nil(gtt, y->parent));
        if (y == y->parent->left) {
            y->parent->left = x;
        } else {
            y->parent->right = x;
        }
    }
    x->right = y;
    y->parent = x;
}

static generic_tree_table_item_t *
generic_tree_table_next_item(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    generic_tree_table_item_t *parent;

    if (generic_tree_table_item_is_nil(gtt, item)) {
        return generic_tree_table_leftmost_item(gtt);
    }

    if (!generic_tree_table_item_is_nil(gtt, item->right)) {
        item = item->right;
        while (!generic_tree_table_item_is_nil(gtt, item->left)) {
            item = item->left;
        }
        return item;
    }

    if (generic_tree_table_item_is_rightmost(gtt, item)) {
        return generic_tree_table_nil_item(gtt);
    }

    /* So, item must belong to one left-sub tree and
     * the following loop is finite.
     */
    parent = item->parent;
    assert(!generic_tree_table_item_is_nil(gtt, parent));
    while (item == parent->right) {
        item = parent;
        parent = item->parent;
        assert(!generic_tree_table_item_is_nil(gtt, parent));
    }
    return parent;
}

static generic_tree_table_item_t *
generic_tree_table_prev_item(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    generic_tree_table_item_t *parent;

    if (generic_tree_table_item_is_nil(gtt, item)) {
        return generic_tree_table_rightmost_item(gtt);
    }

    if (!generic_tree_table_item_is_nil(gtt, item->left)) {
        item = item->left;
        while (!generic_tree_table_item_is_nil(gtt, item->right)) {
            item = item->right;
        }
        return item;
    }

    if (generic_tree_table_item_is_leftmost(gtt, item)) {
        return generic_tree_table_nil_item(gtt);
    }

    /* So, item must belong to one right-sub tree and
     * the following loop is finite.
     */
    parent = item->parent;
    assert(!generic_tree_table_item_is_nil(gtt, parent));
    while (item == parent->left) {
        item = parent;
        parent = item->parent;
        assert(!generic_tree_table_item_is_nil(gtt, parent));
    }
    return parent;
}

/* root != nil */
static generic_tree_table_item_t *
generic_tree_table_max_item(generic_tree_table_t *gtt,
    generic_tree_table_item_t *root) {
    assert(!generic_tree_table_item_is_nil(gtt, root));
    while (!generic_tree_table_item_is_nil(gtt, root->right)) {
        root = root->right;
    }
    return root;
}

/* root != nil */
static generic_tree_table_item_t *
generic_tree_table_min_item(generic_tree_table_t *gtt,
    generic_tree_table_item_t *root) {
    assert(!generic_tree_table_item_is_nil(gtt, root));
    while (!generic_tree_table_item_is_nil(gtt, root->left)) {
        root = root->left;
    }
    return root;
}

static generic_tree_table_item_t *
generic_tree_table_create_item(generic_tree_table_t *gtt, 
        const void *key, const void *value) {
    generic_memory_manager_t *gmm = gtt->gmm;
    const generic_data_manager_t *gkm = gtt->gkm;
    const generic_data_manager_t *gvm = gtt->gvm;
    generic_tree_table_item_t *item;
    void *item_key;
    void *item_value;

    item = (generic_tree_table_item_t *)(gmm->allocate(gmm, gtt->item_size));
    if (!item) {
        return 0;
    }

    item_key = generic_tree_table_item_key(gtt, item);
    if (gkm->copy(item_key, key)) {
        gmm->deallocate(gmm, item, gtt->item_size);
        return 0;
    }

    if (gvm) {
        item_value = generic_tree_table_item_value(gtt, item);
        if (gvm->copy(item_value, value)) {
            if (gkm->destruct) {
                gkm->destruct(item_key);
            }
            gmm->deallocate(gmm, item, gtt->item_size);
            return 0;
        }
    }

    return item;
}

static void generic_tree_table_destroy_item(generic_tree_table_t *gtt,
        generic_tree_table_item_t *item) {
    if (gtt->gkm->destruct) {
        gtt->gkm->destruct(generic_tree_table_item_key(gtt, item));
    }
    if (gtt->gvm && gtt->gvm->destruct) {
        gtt->gvm->destruct(generic_tree_table_item_value(gtt, item));
    }
    gtt->gmm->deallocate(gtt->gmm, item, gtt->item_size);
}

/* best and worst time are both lgn comparison */
static generic_tree_table_item_t *
generic_tree_table_lower_bound_item(generic_tree_table_t *gtt,
        generic_tree_table_item_t *x,
        generic_tree_table_item_t *y,
        const void *key) {
    while (!generic_tree_table_item_is_nil(gtt, x)) {
        if (!gtt->gkm->less(generic_tree_table_item_key(gtt, x), key)) {
            y = x;
            x = x->left;
        } else {
            x = x->right;
        }
    }
    return y;
}

/* best and worst time are both lgn comparision */
static generic_tree_table_item_t *
generic_tree_table_upper_bound_item(generic_tree_table_t *gtt,
        generic_tree_table_item_t *x,
        generic_tree_table_item_t *y,
        const void *key) {
    while (!generic_tree_table_item_is_nil(gtt, x)) {
        if (gtt->gkm->less(key, generic_tree_table_item_key(gtt, x))) {
            y = x;
            x = x->left;
        } else {
            x = x->right;
        }
    }
    return y;
}

static generic_tree_table_item_t *
generic_tree_table_find_insert_position(generic_tree_table_t *gtt,
        const void *key, int *less) {
    generic_tree_table_item_t *y = generic_tree_table_nil_item(gtt);
    generic_tree_table_item_t *x = generic_tree_table_root_item(gtt);
    while (!generic_tree_table_item_is_nil(gtt, x)) {
        y = x;
        *less = gtt->gkm->less(key, generic_tree_table_item_key(gtt, x));
        if (*less) {
            x = x->left;
        } else {
            x = x->right;
        }
    }
    return y;
}

static void
generic_tree_table_insert_fixup(generic_tree_table_t *gtt,
        generic_tree_table_item_t *z) {
    generic_tree_table_item_t *p;
    generic_tree_table_item_t *pp;
    generic_tree_table_item_t *y;

    /* z != nil */
    while (generic_tree_table_item_is_red(z->parent)) {
        /* z->parent cannot be root or nil because root or nil is black. */
        /* z->parent != root */
        /* z->parent != nil */

        p = z->parent;
        /* p != nil */
        assert(!generic_tree_table_item_is_nil(gtt, p));

        pp = p->parent;
        /* pp != nil */
        assert(!generic_tree_table_item_is_nil(gtt, pp));

        if (p == pp->left) {
            y = pp->right;
            /* y may be nil */
            if (generic_tree_table_item_is_red(y)) { /* case 1 */
                /* y != nil because it's red */
                assert(!generic_tree_table_item_is_nil(gtt, y));
                p->color = BLACK;
                y->color = BLACK;
                pp->color = RED;
                z = pp; /* z != nil */
            } else {
                if (z == p->right) { /* case 2 */
                    z = p; /* z != nil */
                    generic_tree_table_left_rotate(gtt, z);
                    p = z->parent; /* p = p->right */
                    /* p != nil */
                    assert(!generic_tree_table_item_is_nil(gtt, p));
                }
                /* case 3 */
                p->color = BLACK;
                pp->color = RED;
                generic_tree_table_right_rotate(gtt, pp);
                /* done */
            }
        } else { /* symmetric: exchange left and right */
            y = pp->left;
            if (generic_tree_table_item_is_red(y)) {
                assert(!generic_tree_table_item_is_nil(gtt, y));
                p->color = BLACK;
                y->color = BLACK;
                pp->color = RED;
                z = pp;
            } else {
                if (z == p->left) {
                    z = p;
                    generic_tree_table_right_rotate(gtt, z);
                    p = z->parent;
                    assert(!generic_tree_table_item_is_nil(gtt, p));
                }
                p->color = BLACK;
                pp->color = RED;
                generic_tree_table_left_rotate(gtt, pp);
            }
        }
    }

    /* root != nil */
    generic_tree_table_root_item(gtt)->color = BLACK;
}

/* y may be nil, It's z's parent */
static generic_tree_table_item_t * 
generic_tree_table_insert_and_rebalance(generic_tree_table_t *gtt,
        generic_tree_table_item_t *y, int less,
        const void *key, const void *value) {
    generic_tree_table_item_t *z; 

    z = generic_tree_table_create_item(gtt, key, value);
    if (!z) {
        return 0;
    }

    z->left = generic_tree_table_nil_item(gtt);
    z->right = generic_tree_table_nil_item(gtt);
    z->color = RED;
    z->parent = y;

    if (generic_tree_table_item_is_nil(gtt, y)) {
        /* insert first item */
        generic_tree_table_set_root(gtt, z);
        generic_tree_table_set_leftmost(gtt, z);
        generic_tree_table_set_rightmost(gtt, z);
    } else {
        if (less) {
            y->left = z;
            if (generic_tree_table_item_is_leftmost(gtt, y)) {
                generic_tree_table_set_leftmost(gtt, z);
            }
        } else {
            y->right = z;
            if (generic_tree_table_item_is_rightmost(gtt, y)) {
                generic_tree_table_set_rightmost(gtt, z);
            }
        }
    }

    generic_tree_table_insert_fixup(gtt, z);
    ++gtt->item_count;
    return z;
}

static int
generic_tree_table_insert_unique(generic_tree_table_t *gtt,
        const void *key, const void *value,
        generic_tree_table_iterator_t *ret) {
    int less;
    generic_tree_table_item_t *y; 
    generic_tree_table_item_t *z; 

    y = generic_tree_table_find_insert_position(gtt, key, &less);

    /* If key exists in tree, it must be in the path [root, ..., y] */

    if (generic_tree_table_item_is_nil(gtt, y)) {
        goto not_existed_label;
    }

    /* y != nil */

    if (less) { /* key < y->key */
        generic_tree_table_item_t *prev;
        /* The proposition, key exists in tree, is equivalent to,
         * key == previous->key
         *
         *      previous
         *          \
         *           \
         *           item_1
         *             /
         *           .
         *          .
         *         .
         *        /
         *      item_n
         *         /
         *        / 
         *       y
         *
         * 1 previous must be the ancestor of y because y has
         * no child.
         * 2 y must be in the righ-sub tree of previous
         * 3 Based on 1 & 2, we know that key >= previous->key.
         * Otherwise, we cannot arrive at y.
         *
         * For any item in the path [item_1, ..., item_n],
         * key < item->key (the definition of previous),
         *
         * So, if key exists in tree, it must be in the path [root, ..., previous]
         * If previous->key != key, key must be in the item which is the ancestor
         * of previous, we can deduce that previous->key > key. Otherwise,
         * we cannot arrive at previous. However, It contradicts with 3.
         * So,
         * previous->key == key.
         *
         * If previous->key == key, of course, key exists in tree.
         */

        prev = generic_tree_table_prev_item(gtt, y);
        if (generic_tree_table_item_is_nil(gtt, prev)) {
            goto not_existed_label;
        }
        if (gtt->gkm->less(generic_tree_table_item_key(gtt, prev), key)) {
            goto not_existed_label;
        }

        z = prev;
        goto existed_label;
    } else { /* !(key < y->key), i.e., key >= y->key */
        /* The proposition, key exists in tree, is equivalent to,
         * key == y->key
         *
         * proof:
         * If key == y->key, of course, key exists in tree.
         * If key exists in tree, y->key >= key. Otherwise, we cannot
         * arrive at y. Also, we know the fact that key >= y->key,
         * so key == y->key
         */
        if (gtt->gkm->less(generic_tree_table_item_key(gtt, y), key)) {
            goto not_existed_label;
        }

        z = y;
        goto existed_label;
    }

not_existed_label:
    z = generic_tree_table_insert_and_rebalance(gtt, y, less, key, value);
    if (z) {
        generic_tree_table_iterator_init(ret, gtt, z);
        return 0;
    }

    generic_tree_table_end(gtt, ret);
    return -1;

existed_label:
    generic_tree_table_iterator_init(ret, gtt, z);
    return 1;
}

static int
generic_tree_table_insert_multiple(generic_tree_table_t *gtt,
        const void *key, const void *value,
        generic_tree_table_iterator_t *ret) {
    int less;
    generic_tree_table_item_t *y; 
    generic_tree_table_item_t *z; 

    y = generic_tree_table_find_insert_position(gtt, key, &less);
    z = generic_tree_table_insert_and_rebalance(gtt, y, less, key, value);

    if (z) {
        generic_tree_table_iterator_init(ret, gtt, z);
        return 0;
    }

    generic_tree_table_end(gtt, ret);
    return -1;
}

/* x may be nil
 * invariant: x == root || p != nil
 */
static void
generic_tree_table_delete_fixup(generic_tree_table_t *gtt,
        generic_tree_table_item_t *x,
        generic_tree_table_item_t *p) {
    generic_tree_table_item_t *w;
    while (!generic_tree_table_item_is_root(gtt, x)
            && generic_tree_table_item_is_black(x)) {
        assert(!generic_tree_table_item_is_nil(gtt, p));
        /* x: double blackness */
        if (x == p->left) {
            w = p->right;
            /* w != nil
             * proof: if w == nil,
             * path (p, w] contains 1 blackness (black nil node)
             * path (p, x, ...] contains at least 2 blackness
             * That implies that, before deletion, red-black property 5 is violated.
             * It's impossible.
             */
            assert(!generic_tree_table_item_is_nil(gtt, w));
            if (w->color == RED) { /* case 1 */
                w->color = BLACK;
                p->color = RED;
                generic_tree_table_left_rotate(gtt, p);
                /* w->left != nil
                 * proof: if w->left == nil,
                 * path (p, w, w->left] contains 1 blackness
                 * path (p, x, ...] contains at least 2 blackness
                 * That implies that, before deletion, red-black property 5 is violated.
                 */
                w = p->right; /* w = w->left */
                /* w != nil */
            }
            assert(!generic_tree_table_item_is_nil(gtt, w));

            /* w->left and w->right may be nil */
            if (generic_tree_table_item_is_black(w->left)
                    && generic_tree_table_item_is_black(w->right)) { /* case 2 */
                w->color = RED;
                x = p;
                p = x->parent;
                /* invariant: x == root || p != nil */
            } else {
                if (generic_tree_table_item_is_black(w->right)) { /* case 3 */
                    /* w->left != nil because it's red */
                    assert(!generic_tree_table_item_is_nil(gtt, w->left));
                    w->left->color = BLACK;
                    w->color = RED;
                    generic_tree_table_right_rotate(gtt, w);
                    w = p->right; /* w = w->left */
                    /* w != nil */
                    /* now: w->right != nil because w->right is old w */
                    /* also: w->right->color == RED */
                }
                assert(!generic_tree_table_item_is_nil(gtt, w));
                assert(!generic_tree_table_item_is_nil(gtt, w->right));
                /* case 4 */
                w->color = p->color;
                p->color = BLACK;
                w->right->color = BLACK;
                generic_tree_table_left_rotate(gtt, p);
                x = generic_tree_table_root_item(gtt);
                /* done */
            }
        } else { /* symmetric: exchange left and right */
            w = p->left;
            assert(!generic_tree_table_item_is_nil(gtt, w));
            if (w->color == RED) {
                w->color = BLACK;
                p->color = RED;
                generic_tree_table_right_rotate(gtt, p);
                w = p->left;
            }
            assert(!generic_tree_table_item_is_nil(gtt, w));

            if (generic_tree_table_item_is_black(w->right)
                    && generic_tree_table_item_is_black(w->left)) {
                w->color = RED;
                x = p;
                p = x->parent;
            } else {
                if (generic_tree_table_item_is_black(w->left)) {
                    assert(!generic_tree_table_item_is_nil(gtt, w->right));
                    w->right->color = BLACK;
                    w->color = RED;
                    generic_tree_table_left_rotate(gtt, w);
                    w = p->left;
                }
                assert(!generic_tree_table_item_is_nil(gtt, w));
                assert(!generic_tree_table_item_is_nil(gtt, w->left));
                w->color = p->color;
                p->color = BLACK;
                w->left->color = BLACK;
                generic_tree_table_right_rotate(gtt, p);
                x = generic_tree_table_root_item(gtt);
            }
        }
    }
    /* x may be nil */
    generic_tree_table_item_set_color(gtt, x, BLACK);
}

static void
generic_tree_table_erase_without_rebalance(generic_tree_table_t *gtt,
        generic_tree_table_item_t *root) {
    while (!generic_tree_table_item_is_nil(gtt, root)) {
        generic_tree_table_item_t *left = root->left;
        generic_tree_table_erase_without_rebalance(gtt, root->right);
        generic_tree_table_destroy_item(gtt, root);
        root = left;
    }
}

#if defined(__cplusplus)
}
#endif

void generic_tree_table_iterator_next(generic_tree_table_iterator_t *iter) {
    iter->item = generic_tree_table_next_item(iter->gtt, iter->item);
}

void generic_tree_table_iterator_prev(generic_tree_table_iterator_t *iter) {
    iter->item = generic_tree_table_prev_item(iter->gtt, iter->item);
}

generic_tree_table_data_t *
generic_tree_table_iterator_deref(generic_tree_table_iterator_t *iter) {
    iter->data.key = generic_tree_table_item_key(iter->gtt, iter->item);
    iter->data.value = generic_tree_table_item_value(iter->gtt, iter->item);
    return &(iter->data);
}

int
generic_tree_table_iterator_equal(const generic_tree_table_iterator_t *lhs,
        const generic_tree_table_iterator_t *rhs) {
    return lhs->item == rhs->item;
}

generic_iterator_tag_t generic_tree_table_iterator_category(void) {
    return generic_bidirectional_iterator_tag;
}

int generic_tree_table_construct(generic_tree_table_t *gtt,
        generic_memory_manager_t *gmm, 
        const generic_data_manager_t *gkm, const generic_data_manager_t *gvm,
        int unique) {
    gtt->gmm = gmm;
    gtt->gkm = gkm;
    gtt->gvm = gvm;
    gtt->item_count = 0;
    gtt->unique = unique;
    generic_tree_table_init_invariant(gtt);
    gtt->sentinel.left = &gtt->sentinel;
    gtt->sentinel.right = &gtt->sentinel;
    generic_tree_table_config(gtt);
    return 0;
}

void generic_tree_table_destruct(generic_tree_table_t *gtt) {
    generic_tree_table_clear(gtt);
}

size_t generic_tree_table_size(const generic_tree_table_t *gtt) {
    return gtt->item_count;
}

int generic_tree_table_empty(const generic_tree_table_t *gtt) {
    return gtt->item_count == 0;
}

void generic_tree_table_begin(generic_tree_table_t *gtt,
        generic_tree_table_iterator_t *ret) {
    generic_tree_table_iterator_init(ret, gtt,
            generic_tree_table_leftmost_item(gtt));
}

void generic_tree_table_end(generic_tree_table_t *gtt,
        generic_tree_table_iterator_t *ret) {
    generic_tree_table_iterator_init(ret, gtt,
            generic_tree_table_nil_item(gtt));
}

int generic_tree_table_find(generic_tree_table_t *gtt, const void *key,
        generic_tree_table_iterator_t *ret) {
    generic_tree_table_item_t *lower_bound;
    lower_bound = generic_tree_table_lower_bound_item(gtt,
            generic_tree_table_root_item(gtt),
            generic_tree_table_nil_item(gtt), key);
    if (generic_tree_table_item_is_nil(gtt, lower_bound)
        || gtt->gkm->less(key, generic_tree_table_item_key(gtt, lower_bound))) {
        generic_tree_table_end(gtt, ret);
        return 0;
    }

    generic_tree_table_iterator_init(ret, gtt, lower_bound);
    return 1;
}

/* best time is logn comparision,
 * worst time is 2logn comparsion
 */
void generic_tree_table_equal_range(generic_tree_table_t *gtt,
        const void *key, generic_tree_table_iterator_t *first,
        generic_tree_table_iterator_t *last) {
    generic_tree_table_item_t *x = generic_tree_table_root_item(gtt);
    generic_tree_table_item_t *y = generic_tree_table_nil_item(gtt);
    while (!generic_tree_table_item_is_nil(gtt, x)) {
        const void *x_key = generic_tree_table_item_key(gtt, x);
        if (gtt->gkm->less(key, x_key)) {
            y = x;
            x = x->left;
        } else if (gtt->gkm->less(x_key, key)) {
            x = x->right;
        } else { /* This is the first item that is equal to key */
            generic_tree_table_iterator_init(first, gtt, x);
            generic_tree_table_iterator_init(last, gtt,
                    generic_tree_table_upper_bound_item(gtt,
                        x->right, y, key));
            return;
        }
    }
    
    generic_tree_table_end(gtt, first);
    generic_tree_table_end(gtt, last);
}

void generic_tree_table_lower_bound(generic_tree_table_t *gtt,
        const void *key, generic_tree_table_iterator_t *ret) {
    generic_tree_table_iterator_init(ret, gtt,
            generic_tree_table_lower_bound_item(gtt,
                generic_tree_table_root_item(gtt),
                generic_tree_table_nil_item(gtt),
                key));
}

void generic_tree_table_upper_bound(generic_tree_table_t *gtt,
        const void *key, generic_tree_table_iterator_t *ret) {
    generic_tree_table_iterator_init(ret, gtt,
            generic_tree_table_upper_bound_item(gtt,
                generic_tree_table_root_item(gtt),
                generic_tree_table_nil_item(gtt),
                key));
}

size_t generic_tree_table_count(const generic_tree_table_t *gtt,
        const void *key) {
    size_t count = 0;
    generic_tree_table_item_t *item;
    generic_tree_table_iterator_t first;
    generic_tree_table_iterator_t last;

    generic_tree_table_equal_range((generic_tree_table_t *)(gtt), key,
            &first, &last);

    item = first.item;
    while (item != last.item) {
        ++count;
        item = generic_tree_table_next_item((generic_tree_table_t *)(gtt),
                item);
    }

    return count;
}

int generic_tree_table_insert(generic_tree_table_t *gtt,
        const void *key, const void *value,
        generic_tree_table_iterator_t *ret) {
    int status;
    if (gtt->unique) {
        status = generic_tree_table_insert_unique(gtt, key, value, ret);
    } else {
        status = generic_tree_table_insert_multiple(gtt, key, value, ret);
    }
    generic_tree_table_check_invariant(gtt);
    return status;
}

/* Be careful: iter and ret may be same */
void generic_tree_table_erase(generic_tree_table_t *gtt,
        const generic_tree_table_iterator_t *iter,
        generic_tree_table_iterator_t *ret) {
    generic_tree_table_item_t *x;
    generic_tree_table_item_t *x_parent;
    generic_tree_table_item_t *y;
    generic_tree_table_item_t *z = iter->item;
    generic_tree_table_item_t *n = generic_tree_table_next_item(gtt, z);

    generic_tree_table_iterator_init(ret, gtt, n);
    
    /* do not use iter any more */

    if (generic_tree_table_item_is_nil(gtt, z->left)
            || generic_tree_table_item_is_nil(gtt, z->right)) {
        y = z;
    } else {
        y = n;
    }

    /* y != nil */
    assert(!generic_tree_table_item_is_nil(gtt, y));

    if (!generic_tree_table_item_is_nil(gtt, y->left)) {
        x = y->left;
    } else {
        x = y->right; /* x may be nil */
    }
    
    /* x may be nil */

    if (y != z) { /* relink: replace z with y, y is z's successor  */
        /* z->left != nil
         * z->right != nil
         * y->parent != nil
         */
        assert(!generic_tree_table_item_is_nil(gtt, z->left));
        assert(!generic_tree_table_item_is_nil(gtt, z->right));
        assert(!generic_tree_table_item_is_nil(gtt, y->parent));

        z->left->parent = y;
        y->left = z->left;
        if (y != z->right) {
            /* y == y->parent->left */
            assert(y == y->parent->left);
            x_parent = y->parent;
            /* x may be nil */
            generic_tree_table_item_set_parent(gtt, x, y->parent);
            y->parent->left = x;
            y->right = z->right;
            z->right->parent = y;
        } else {
            x_parent = y;
        }

        /* x_parent != nil */

        if (generic_tree_table_item_is_root(gtt, z)) {
            generic_tree_table_set_root(gtt, y);
        } else { /* z->parent != nil */
            assert(!generic_tree_table_item_is_nil(gtt, z->parent));
            if (z == z->parent->left) {
                z->parent->left = y;
            } else {
                z->parent->right = y;
            }
        }
        y->parent = z->parent;
        do {
            size_t color = z->color;
            z->color = y->color;
            y->color = color;
        } while (0);
        y = z;
        /* leftmost and rightmost remains unchanged
         * because z->left != nil and z->right != nil
         */
    } else { /* y == z */
        x_parent = y->parent;
        /* x_parent may be nil */
        /* x may be nil */
        generic_tree_table_item_set_parent(gtt, x, y->parent);
        if (generic_tree_table_item_is_root(gtt, z)) {
            generic_tree_table_set_root(gtt, x);
            /* x == root */
        } else { /* z->parent != nil */
            /* Also, x_parent != nil */
            assert(!generic_tree_table_item_is_nil(gtt, z->parent));
            if (z == z->parent->left) {
                z->parent->left = x;
            } else {
                z->parent->right = x;
            }
            /* x != root */
        }

        /* invariant: x == root || x_parent != nil */

        if (generic_tree_table_item_is_leftmost(gtt, z)) {
            if (generic_tree_table_item_is_nil(gtt, z->right)) {
                generic_tree_table_set_leftmost(gtt, z->parent);
            } else {
                generic_tree_table_item_t *min;
                /* x == z->right && x != nil */
                min = generic_tree_table_min_item(gtt, x);
                generic_tree_table_set_leftmost(gtt, min);
            }
        }
        if (generic_tree_table_item_is_rightmost(gtt, z)) {
            if (generic_tree_table_item_is_nil(gtt, z->left)) {
                generic_tree_table_set_rightmost(gtt, z->parent);
            } else {
                /* x == z->left && x != nil */
                generic_tree_table_item_t *max;
                max = generic_tree_table_max_item(gtt, x);
                generic_tree_table_set_rightmost(gtt, max);
            }
        }
    }

    /* invariant: x == root || x_parent != nil */
    if (y->color == BLACK) {
        generic_tree_table_delete_fixup(gtt, x, x_parent);
    }

    generic_tree_table_destroy_item(gtt, y);
    --gtt->item_count;

    generic_tree_table_check_invariant(gtt);
}

size_t generic_tree_table_remove(generic_tree_table_t *gtt,
        const void *key) {
    size_t old_item_count = gtt->item_count;
    generic_tree_table_iterator_t begin;
    generic_tree_table_iterator_t end;
    generic_tree_table_iterator_t first;
    generic_tree_table_iterator_t last;

    generic_tree_table_begin(gtt, &begin);
    generic_tree_table_end(gtt, &end);
    generic_tree_table_equal_range(gtt, key, &first, &last);

    if (generic_tree_table_iterator_equal(&begin, &first)
            && generic_tree_table_iterator_equal(&end, &last)) {
        generic_tree_table_clear(gtt); /* without rebalance */
    } else  {
        /* Be careful: key may come from [first, last) */
        while (!generic_tree_table_iterator_equal(&first, &last)) {
            generic_tree_table_erase(gtt, &first, &first);
        }
    }

    generic_tree_table_check_invariant(gtt);
    return old_item_count - gtt->item_count;
}

void generic_tree_table_clear(generic_tree_table_t *gtt) {
    generic_tree_table_erase_without_rebalance(gtt,
            generic_tree_table_root_item(gtt));
    generic_tree_table_init_invariant(gtt);
    gtt->sentinel.left = &gtt->sentinel;
    gtt->sentinel.right = &gtt->sentinel;
    gtt->item_count = 0;
}

generic_memory_manager_t *
generic_tree_table_memory_manager(const generic_tree_table_t *gtt) {
    return gtt->gmm;
}

const generic_data_manager_t *
generic_tree_table_key_manager(const generic_tree_table_t *gtt) {
    return gtt->gkm;
}

const generic_data_manager_t *
generic_tree_table_value_manager(const generic_tree_table_t *gtt) {
    return gtt->gvm;
}

