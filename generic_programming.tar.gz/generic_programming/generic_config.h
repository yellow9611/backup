/**
 * @file
 * @brief Configure forward list, list, hash table and tree table.
 * @internal
 */

#if !defined(GENERIC_CONFIG_H)
#define GENERIC_CONFIG_H

#include "generic_forward_list.h"
#include "generic_list.h"
#include "generic_hash_table.h"
#include "generic_tree_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

void generic_forward_list_config(generic_forward_list_t *);

void generic_list_config(generic_list_t *);

void generic_hash_table_config(generic_hash_table_t *);

void generic_tree_table_config(generic_tree_table_t *);

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_CONFIG_H */

