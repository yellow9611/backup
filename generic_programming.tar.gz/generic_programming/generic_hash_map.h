/** @addtogroup GenericContainer */

/**
 * @addtogroup GenericHashMap
 * @ingroup GenericContainer
 */

/** @{ */

/**
 * @file
 * @brief Hash map and hash multimap.
 * @details Key and value shall be copyable.
 * Equality test shall be applicable to key.
 * Elemenst of the container are unordered.
 */

/** @example test_generic_hash_map.c */

#if !defined(GENERIC_HASH_MAP_H)
#define GENERIC_HASH_MAP_H

#include <stddef.h>
#include "generic_utility.h"
#include "generic_hash_table.h"

#if defined(__cplusplus)
extern "C" {
#endif

typedef struct generic_hash_map_api_t generic_hash_map_api_t;
typedef struct generic_hash_map_t generic_hash_map_t;
typedef struct generic_hash_map_iterator_t generic_hash_map_iterator_t;
typedef struct generic_hash_map_iterator_api_t generic_hash_map_iterator_api_t;
typedef struct generic_hash_map_local_iterator_t generic_hash_map_local_iterator_t;
typedef struct generic_hash_map_local_iterator_api_t generic_hash_map_local_iterator_api_t;
typedef struct generic_hash_map_data_t generic_hash_map_data_t;

/** @brief Get API of generic hash map iterator. */
const generic_hash_map_iterator_api_t *generic_hash_map_iterator_api(void);

/** @brief Get API of generic hash map local iterator. */
const generic_hash_map_local_iterator_api_t *generic_hash_map_local_iterator_api(void);

/** @brief Get API of generic hash map. */
const generic_hash_map_api_t *generic_hash_map_api(void);

/** @brief Element of hash map. */
struct generic_hash_map_data_t {
    const void *key;
    void *value;
};

/** @brief API of generic hash map iterator. */
struct generic_hash_map_iterator_api_t {
    void (*next)(generic_hash_map_iterator_t *);
    void (*prev)(generic_hash_map_iterator_t *); /* 0 */
    void (*move)(generic_hash_map_iterator_t *, ptrdiff_t); /* 0 */
    generic_hash_map_data_t *(*deref)(generic_hash_map_iterator_t *);
    int (*equal)(const generic_hash_map_iterator_t *,
            const generic_hash_map_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_map_iterator_t *,
            const generic_hash_map_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash map iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_map_iterator_t {
    const generic_hash_map_iterator_api_t *api;
    generic_hash_table_iterator_t imp;
};

/** @brief API of generic hash map local iterator. */
struct generic_hash_map_local_iterator_api_t {
    void (*next)(generic_hash_map_local_iterator_t *);
    void (*prev)(generic_hash_map_local_iterator_t *); /* 0 */
    void (*move)(generic_hash_map_local_iterator_t *, ptrdiff_t); /* 0 */
    generic_hash_map_data_t *(*deref)(generic_hash_map_local_iterator_t *);
    int (*equal)(const generic_hash_map_local_iterator_t *,
            const generic_hash_map_local_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_map_local_iterator_t *,
            const generic_hash_map_local_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash map local iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_map_local_iterator_t {
    const generic_hash_map_local_iterator_api_t *api;
    generic_hash_table_local_iterator_t imp;
};

/**
 * @brief API of generic hash map.
 * @attention If rehash happens because of high load factor,
 * any previous iterator or local iterator shall be invalid.
 * @attention Multiple elements with the same key are not allowed.
 */
struct generic_hash_map_api_t {
    /**
     * @brief Construct one empty hash map.
     * @return Upon successful completion, It shall return 0.
     * @param bucket_hint Estimated required bucket count.
     * @param gkm Key manager.
     * @param gvm Value manager.
     */
    int (*construct)(generic_hash_map_t *, size_t bucket_hint,
            generic_memory_manager_t *, const generic_data_manager_t *gkm,
            const generic_data_manager_t *gvm, generic_hash_fp_t);

    /** @brief Destruct the hash map. */
    void (*destruct)(generic_hash_map_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_hash_map_t *);

    /** @brief Test if hash map is empty or not. */
    int (*empty)(const generic_hash_map_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_hash_map_iterator_t (*begin)(generic_hash_map_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_hash_map_iterator_t (*end)(generic_hash_map_t *);

    /**
     * @brief Find the element that has @a key.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of hash map.
     */
    generic_hash_map_iterator_t (*find)(generic_hash_map_t *,
            const void *key);

    /** @brief Get the number of elements that have @a key. */
    size_t (*count)(const generic_hash_map_t *, const void *key);

    /**
     * @brief Get the range of elements that have @a key.
     * @param[out] begin Points to the first element that has @a key.
     * @param[out] end Points after the last element that has @a key.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_hash_map_t *, const void *key,
            generic_hash_map_iterator_t *begin,
            generic_hash_map_iterator_t *end);

#if 0
    /* It's hard to emulate operator[] because it's hard to emulate
     * default constructor. */
    void *(*get)(generic_hash_map_t *, const void *);
#endif

    /**
     * @brief Get value address of the element that has @a key.
     * @return If no such element exists, it shall return 0.
     */
    void *(*at)(generic_hash_map_t *, const void *key);

    /** @brief Get the local iterator that points to first element of @a bucket. */
    generic_hash_map_local_iterator_t (*local_begin)(generic_hash_map_t *,
            size_t bucket);

    /** @brief Get the local iterator that points after last element of @a bucket. */
    generic_hash_map_local_iterator_t (*local_end)(generic_hash_map_t *,
            size_t bucket);

    /** @brief Get the number of buckets. */
    size_t (*bucket_count)(const generic_hash_map_t *);

    /** @brief Get the number of elements in @a bucket. */
    size_t (*bucket_size)(const generic_hash_map_t *, size_t bucket);

    /** @brief Get the bucket that @a key maps to. */
    size_t (*bucket)(const generic_hash_map_t *, const void *key);

    /** @brief Get load factor of hash map. */
    float (*load_factor)(const generic_hash_map_t *);

    /** @brief Get max load factor of hash map. */
    float (*get_max_load_factor)(const generic_hash_map_t *);

    /**
     * @brief Set max load factor of hash map.
     * @return Upon successful completion, It shall return 0.
     * @attention It may cause rehash.
     */
    int (*set_max_load_factor)(generic_hash_map_t *, float);

    /**
     * @brief Insert one element with @a key and @a value.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of hash map.
     * @attention It may cause rehash.
     */
    generic_hash_map_iterator_t (*insert)(generic_hash_map_t *,
            const void *key, const void *value);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_hash_map_iterator_t (*erase)(generic_hash_map_t *,
            const generic_hash_map_iterator_t *iter);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the local iterator that points after
     * the erased element.
     */
    generic_hash_map_local_iterator_t (*lerase)(generic_hash_map_t *,
            const generic_hash_map_local_iterator_t *iter);

    /**
     * @brief Erase all elements that have @a key.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_hash_map_t *, const void *key);

    /** @brief Erase all elements. */
    void (*clear)(generic_hash_map_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_hash_map_t *);

    /** @brief Get key manager. */
    const generic_data_manager_t *(*key_manager)(const generic_hash_map_t *);

    /** @brief Get value manager. */
    const generic_data_manager_t *(*value_manager)(const generic_hash_map_t *);

    /** @brief Get hash function. */
    generic_hash_fp_t (*hash)(const generic_hash_map_t *);
};

/**
 * @brief Representation of hash map.
 * @attention All members are private.
 */
struct generic_hash_map_t {
    generic_hash_table_t imp;
};

typedef struct generic_hash_multimap_api_t generic_hash_multimap_api_t;
typedef struct generic_hash_multimap_t generic_hash_multimap_t;
typedef struct generic_hash_multimap_iterator_t generic_hash_multimap_iterator_t;
typedef struct generic_hash_multimap_iterator_api_t generic_hash_multimap_iterator_api_t;
typedef struct generic_hash_multimap_local_iterator_t generic_hash_multimap_local_iterator_t;
typedef struct generic_hash_multimap_local_iterator_api_t generic_hash_multimap_local_iterator_api_t;
typedef struct generic_hash_multimap_data_t generic_hash_multimap_data_t;

/** @brief Get API of generic hash multimap iterator. */
const generic_hash_multimap_iterator_api_t *generic_hash_multimap_iterator_api(void);

/** @brief Get API of generic hash multimap local iterator. */
const generic_hash_multimap_local_iterator_api_t *generic_hash_multimap_local_iterator_api(void);

/** @brief Get API of generic hash multimap. */
const generic_hash_multimap_api_t *generic_hash_multimap_api(void);

/** @brief Element of hash multimap. */
struct generic_hash_multimap_data_t {
    const void *key;
    void *value;
};

/** @brief API of generic hash multimap iterator. */
struct generic_hash_multimap_iterator_api_t {
    void (*next)(generic_hash_multimap_iterator_t *);
    void (*prev)(generic_hash_multimap_iterator_t *); /* 0 */
    void (*move)(generic_hash_multimap_iterator_t *, ptrdiff_t); /* 0 */
    generic_hash_multimap_data_t *(*deref)(generic_hash_multimap_iterator_t *);
    int (*equal)(const generic_hash_multimap_iterator_t *,
            const generic_hash_multimap_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_multimap_iterator_t *,
            const generic_hash_multimap_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash multimap iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_multimap_iterator_t {
    const generic_hash_multimap_iterator_api_t *api;
    generic_hash_table_iterator_t imp;
};

/** @brief API of generic hash multimap local iterator. */
struct generic_hash_multimap_local_iterator_api_t {
    void (*next)(generic_hash_multimap_local_iterator_t *);
    void (*prev)(generic_hash_multimap_local_iterator_t *); /* 0 */
    void (*move)(generic_hash_multimap_local_iterator_t *, ptrdiff_t); /* 0 */
    generic_hash_multimap_data_t *(*deref)(generic_hash_multimap_local_iterator_t *);
    int (*equal)(const generic_hash_multimap_local_iterator_t *,
            const generic_hash_multimap_local_iterator_t *);
    ptrdiff_t (*sub)(const generic_hash_multimap_local_iterator_t *,
            const generic_hash_multimap_local_iterator_t *); /* 0 */
    generic_iterator_tag_t (*category)(void);
    size_t (*size)(void);
};

/**
 * @brief Representation of generic hash multimap local iterator.
 * @attention Only member @a api is public.
 */
struct generic_hash_multimap_local_iterator_t {
    const generic_hash_multimap_local_iterator_api_t *api;
    generic_hash_table_local_iterator_t imp;
};

/**
 * @brief API of generic hash multimap.
 * @attention If rehash happens because of high load factor,
 * any previous iterator or local iterator shall be invalid.
 * @attention Multiple elements with the same key are allowed.
 */
struct generic_hash_multimap_api_t {
    /**
     * @brief Construct one empty hash multimap.
     * @return Upon successful completion, It shall return 0.
     * @param bucket_hint Estimated required bucket count.
     * @param gkm Key manager.
     * @param gvm Value manager.
     */
    int (*construct)(generic_hash_multimap_t *, size_t bucket_hint,
            generic_memory_manager_t *, const generic_data_manager_t *gkm,
            const generic_data_manager_t *gvm, generic_hash_fp_t);

    /** @brief Destruct the hash multimap. */
    void (*destruct)(generic_hash_multimap_t *);

    /** @brief Get the number of elements. */
    size_t (*size)(const generic_hash_multimap_t *);

    /** @brief Test if hash multimap is empty or not. */
    int (*empty)(const generic_hash_multimap_t *);

    /** @brief Get the iterator that points to the first element. */
    generic_hash_multimap_iterator_t (*begin)(generic_hash_multimap_t *);

    /** @brief Get the iterator that points after the last element. */
    generic_hash_multimap_iterator_t (*end)(generic_hash_multimap_t *);

    /**
     * @brief Find one element that has @a key.
     * @return If such element exists, It shall return an iterator that
     * points to the element. Otherwsie, It shall be the end of hash multimap.
     */
    generic_hash_multimap_iterator_t (*find)(generic_hash_multimap_t *,
            const void *key);

    /** @brief Get the number of elements that have @a key. */
    size_t (*count)(const generic_hash_multimap_t *, const void *key);

    /**
     * @brief Get the range of elements that have @a key.
     * @param[out] begin Points to the first element that has @a key.
     * @param[out] end Points after the last element that has @a key.
     * @attention If @a begin is equal to @a end, it means no such
     * element.
     */
    void (*equal_range)(generic_hash_multimap_t *, const void *key,
            generic_hash_multimap_iterator_t *begin,
            generic_hash_multimap_iterator_t *end);

    /** @brief Get the local iterator that points to first element of @a bucket. */
    generic_hash_multimap_local_iterator_t (*local_begin)(generic_hash_multimap_t *,
            size_t bucket);

    /** @brief Get the local iterator that points after last element of @a bucket. */
    generic_hash_multimap_local_iterator_t (*local_end)(generic_hash_multimap_t *,
            size_t bucket);

    /** @brief Get the number of buckets. */
    size_t (*bucket_count)(const generic_hash_multimap_t *);

    /** @brief Get the number of elements in @a bucket. */
    size_t (*bucket_size)(const generic_hash_multimap_t *, size_t bucket);

    /** @brief Get the bucket that @a key maps to. */
    size_t (*bucket)(const generic_hash_multimap_t *, const void *key);

    /** @brief Get load factor of hash multimap. */
    float (*load_factor)(const generic_hash_multimap_t *);

    /** @brief Get max load factor of hash multimap. */
    float (*get_max_load_factor)(const generic_hash_multimap_t *);
    /**
     * @brief Set max load factor of hash multimap.
     * @return Upon successful completion, It shall return 0.
     * @attention It may cause rehash.
     */
    int (*set_max_load_factor)(generic_hash_multimap_t *, float);

    /**
     * @brief Insert one element with @a key and @a value.
     * @return Upon successful completion, It shall return an iterator that
     * points to the new element. Otherwise, It shall be the end of hash multimap.
     * @attention It may cause rehash.
     */
    generic_hash_multimap_iterator_t (*insert)(generic_hash_multimap_t *,
            const void *key, const void *value);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the iterator that points after the erased
     * element.
     */
    generic_hash_multimap_iterator_t (*erase)(generic_hash_multimap_t *,
            const generic_hash_multimap_iterator_t *iter);

    /**
     * @brief Erase the element designated by @a iter.
     * @return It shall return the local iterator that points after
     * the erased element.
     */
    generic_hash_multimap_local_iterator_t (*lerase)(generic_hash_multimap_t *,
            const generic_hash_multimap_local_iterator_t *iter);

    /**
     * @brief Erase all elements that have @a key.
     * @return It shall return the number of erased elements.
     */
    size_t (*remove)(generic_hash_multimap_t *, const void *key);

    /** @brief Erase all elements. */
    void (*clear)(generic_hash_multimap_t *);

    /** @brief Get memory manager. */
    generic_memory_manager_t *(*memory_manager)(const generic_hash_multimap_t *);

    /** @brief Get key manager. */
    const generic_data_manager_t *(*key_manager)(const generic_hash_multimap_t *);

    /** @brief Get value manager. */
    const generic_data_manager_t *(*value_manager)(const generic_hash_multimap_t *);

    /** @brief Get hash function. */
    generic_hash_fp_t (*hash)(const generic_hash_multimap_t *);
};

/**
 * @brief Representation of hash multimap.
 * @attention All members are private.
 */
struct generic_hash_multimap_t {
    generic_hash_table_t imp;
};

#if defined(__cplusplus)
}
#endif

#endif /* GENERIC_HASH_MAP_H */

/** @} */

